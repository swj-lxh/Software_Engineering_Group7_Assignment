package com.gk.study.entity;

public class VisitData {

    public String reIp;
    public int count;
}

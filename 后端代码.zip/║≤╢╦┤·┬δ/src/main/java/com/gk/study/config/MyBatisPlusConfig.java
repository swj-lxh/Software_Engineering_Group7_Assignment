// 路径：src/main/java/com/gk/study/config/MyBatisPlusConfig.java
package com.gk.study.config; // 必须与文件夹路径一致

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * MyBatis-Plus全局配置：适配数据库字段类型（LocalDateTime/BigDecimal）+ 分页插件
 * 存放位置：com.gk.study.config
 */
@Configuration // 标识为Spring配置类
@MapperScan("com.gk.study.mapper") // 扫描你的mapper包（与项目中mapper路径一致）
public class MyBatisPlusConfig {
    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        // 分页插件，适配MySQL数据库
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));
        return interceptor;
    }
}
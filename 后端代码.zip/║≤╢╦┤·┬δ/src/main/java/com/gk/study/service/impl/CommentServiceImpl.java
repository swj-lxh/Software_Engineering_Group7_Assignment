package com.gk.study.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gk.study.entity.Comment;
import com.gk.study.entity.LikeCount;
import com.gk.study.mapper.CommentMapper;
import com.gk.study.mapper.LikeCountMapper;
import com.gk.study.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

// 评论服务实现类：实现CommentService接口，处理评论相关业务逻辑
@Service
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment> implements CommentService {
    @Autowired
    CommentMapper commentMapper; // 注入评论数据访问层对象，操作数据库

    @Autowired
    LikeCountMapper likeCountMapper;
    /**
     * 获取所有评论列表
     * @return 评论列表
     */
    @Override
    public List<Comment> getCommentList() {
        return commentMapper.getList();
    }

    /**
     * 创建评论（自动填充评论时间）
     * @param comment 评论实体（需包含评论内容、关联商品ID、用户ID等）
     */
    @Override
    public void createComment(Comment comment) {
        System.out.println(comment);
        // 生成评论时间（毫秒级时间戳，确保唯一性）
        comment.setCommentTime(LocalDateTime.now());
        commentMapper.insert(comment); // 插入数据库
    }

    /**
     * 根据ID删除评论
     * @param id 评论ID
     */
    @Override
    public void deleteComment(String id) {
        commentMapper.deleteById(id);
    }

    /**
     * 更新评论信息
     * @param comment 包含更新内容的评论实体（需指定ID）
     */
    @Override
    public void updateComment(Comment comment) {
        commentMapper.updateById(comment);
    }

    /**
     * 获取评论详情
     * @param id 评论ID
     * @return 评论实体
     */
    @Override
    public Comment getCommentDetail(Long id) {
        return commentMapper.selectById(id);
    }

    /**
     * 获取指定商品的评论列表（支持排序）
     * @param thingId 商品ID
     * @param order 排序方式（"recent"：按时间倒序；"hot"：按点赞数倒序）
     * @return 商品评论列表
     */
    @Override
    public List<Comment> getThingCommentList(String thingId, String order) {
        return commentMapper.selectThingCommentList(thingId, order);
    }

    /**
     * 获取指定用户的评论列表
     * @param userId 用户ID
     * @return 用户评论列表
     */
    @Override
    public List<Comment> getUserCommentList(String userId) {
        return commentMapper.selectUserCommentList(userId);
    }

    @Override
    public boolean likeComment(Long commentId, Integer userId) {
        QueryWrapper<LikeCount> wrapper = new QueryWrapper<>();
        wrapper.eq("comment_id", commentId)
                .eq("user_id", userId);
        if (likeCountMapper.selectCount(wrapper) == 0){
            // 那么就要添加怎么一行数据
            LikeCount likeCount = new LikeCount();
            likeCount.setCommentId(commentId);
            likeCount.setUserId(userId);
            likeCountMapper.insert(likeCount);
            return false;
        }else {
            likeCountMapper.delete(wrapper);
            return true;
        }
    }

}
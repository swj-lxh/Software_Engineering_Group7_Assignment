package com.gk.study.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gk.study.entity.Classification;
import com.gk.study.entity.Thing;
import com.gk.study.entity.ThingTag;
import com.gk.study.mapper.ClassificationMapper;
import com.gk.study.mapper.ThingMapper;
import com.gk.study.mapper.ThingTagMapper;
import com.gk.study.service.ThingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ThingServiceImpl extends ServiceImpl<ThingMapper, Thing> implements ThingService {
    @Autowired
    ThingMapper mapper;

    @Autowired
    ThingTagMapper thingTagMapper;

    @Autowired
    ClassificationMapper classificationMapper;

    @Override
    public List<Thing> getThingList(String keyword, String sort, String category, String tag) {
        QueryWrapper<Thing> queryWrapper = new QueryWrapper<>();

        // 搜索要用到
        // LIKE 查询：当 keyword 不为空时，模糊匹配 title 字段
        // 第一个参数是条件判断
        // 第二个参数是要查询的数据库字段名
        // 第三个参数是匹配的值
        queryWrapper.like(StringUtils.isNotBlank(keyword), "title", keyword);
        // 分类筛选：当分类ID不为空且不等于"-1"时，精确匹配 classification_id 字段
        if (StringUtils.isNotBlank(category) && !category.equals("-1")) {
            queryWrapper.eq(true, "classification_id", category);
        }
        // 是不是最新、最热、推荐
        if (StringUtils.isNotBlank(sort)) {
            if (sort.equals("recent")) {
                // condition: 条件判断
                // isAsc: 是否升序(true为升序，false为降序)
                // column: 排序列名
                queryWrapper.orderBy(true, false, "create_time");
            } else if (sort.equals("hot")) {
                queryWrapper.orderBy(true, false, "collect_count");
            } else if (sort.equals("recommend")) {
                queryWrapper.orderBy(true, false, "collect_count");
                // 如果没有标签筛选
                if (tag == null) {
                    // 限制只返回前4个结果
                    queryWrapper.last("limit 4");
                }
            }
        } else {
            // 即正常查看
            queryWrapper.orderBy(true, false, "create_time");
        }


        // 拿到该种类的所有商品
        List<Thing> things = mapper.selectList(queryWrapper);

        // tag筛选
        if (StringUtils.isNotBlank(tag)) {
            List<Thing> tThings = new ArrayList<>();
            QueryWrapper<ThingTag> thingTagQueryWrapper = new QueryWrapper<>();
            thingTagQueryWrapper.eq("tag_id", tag);
            List<ThingTag> thingTagList = thingTagMapper.selectList(thingTagQueryWrapper);
            // 遍历所有商品
            for (Thing thing : things) {
                // 遍历有这个标签的所有ThingTag，里面有商品ID
                for (ThingTag thingTag : thingTagList) {
                    // 如果该商品拥有这个标签，则添加到结果中
                    if (thing.getId().equals(thingTag.getThingId())) {
                        tThings.add(thing);
                    }
                }
                // 如果是推荐，并且数量已经达到了4个，就不用添加了
                if (sort.equals("recommend") && tThings.size() >= 4) {
                    break;
                }
            }
            // 清空原来的
            things.clear();
            // 加入新的
            things.addAll(tThings);
            // 即给符合条件的商品附加tag

        }
        for (Thing thing : things) {
            QueryWrapper<ThingTag> tagQueryWrapper = new QueryWrapper<>();
            tagQueryWrapper.lambda().eq(ThingTag::getThingId, thing.getId());
            List<ThingTag> thingTags = thingTagMapper.selectList(tagQueryWrapper);
            List<Integer> tags = thingTags.stream().map(ThingTag::getTagId).collect(Collectors.toList());
            thing.setTags(tags);
        }

        return things;
    }

    @Override
    public void createThing(Thing thing) {
        System.out.println(thing);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentTime = sdf.format(new Date());
        thing.setCreateTime(currentTime);

        if (thing.getScore() == null) {
            thing.setScore("0");
        }
        if (thing.getWishCount() == null) {
            thing.setWishCount(0);
        }
        mapper.insert(thing);
        // 更新tag
        setThingTags(thing);
    }

    @Override
    public void deleteThing(String id) {
        mapper.deleteById(id);
    }

    @Override
    public void updateThing(Thing thing) {

        // 更新tag
        setThingTags(thing);

        mapper.updateById(thing);
    }

    @Override
    public Thing getThingById(String id) {
        Thing thing = mapper.selectById(id);
        // 添加下分类的名字
        if (thing.getClassificationId() != null) {
            Classification classification = classificationMapper.selectById(thing.getClassificationId());
            if (classification == null) {
                thing.setClassificationTitle("");
            } else {
                thing.setClassificationTitle(classification.getTitle());

            }

        }
        // 添加标签
        // 首先是查询这个商品的所有标签
        QueryWrapper<ThingTag> thingTagQueryWrapper = new QueryWrapper<>();
        thingTagQueryWrapper.eq("thing_id", id);
        List<ThingTag> thingTags = thingTagMapper.selectList(thingTagQueryWrapper);
        thing.setTags(thingTags.stream().map(ThingTag::getTagId).collect(Collectors.toList()));
        return thing;
    }

    // 心愿数加1
    @Override
    public void addWishCount(Integer thingId) {
        Thing thing = mapper.selectById(thingId);
        thing.setWishCount(thing.getWishCount() + 1);
        mapper.updateById(thing);
    }

    // 收藏数加1
    @Override
    public void addCollectCount(Integer thingId) {
        Thing thing = mapper.selectById(thingId);
        thing.setCollectCount(thing.getCollectCount() + 1);
        mapper.updateById(thing);
    }

    public void setThingTags(Thing thing) {
        // 删除tag
        Map<String, Object> map = new HashMap<>();
        map.put("thing_id", thing.getId());
        thingTagMapper.deleteByMap(map);
        // 新增tag
        if (thing.getTags() != null) {
            for (Integer tag : thing.getTags()) {
                ThingTag thingTag = new ThingTag();
                thingTag.setThingId(thing.getId());
                thingTag.setTagId(tag);
                thingTagMapper.insert(thingTag);
            }
        }
    }

}

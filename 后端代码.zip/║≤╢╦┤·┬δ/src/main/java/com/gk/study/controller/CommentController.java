package com.gk.study.controller;

import com.gk.study.common.APIResponse;
import com.gk.study.common.ResponeCode;
import com.gk.study.entity.Comment;
import com.gk.study.permission.Access;
import com.gk.study.permission.AccessLevel;
import com.gk.study.service.CommentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

// 评论控制器：负责处理商品评论的相关HTTP请求（查询、创建、删除、更新、点赞等）
@RestController
@RequestMapping("/comment") // 映射请求路径前缀：/comment
public class CommentController {

    private final static Logger logger = LoggerFactory.getLogger(CommentController.class);

    @Autowired
    CommentService service; // 注入评论服务层对象，处理业务逻辑

    /**
     * 查询所有评论列表
     * @return 统一响应对象，包含所有评论数据
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public APIResponse list(){
        List<Comment> list =  service.getCommentList();
        return new APIResponse(ResponeCode.SUCCESS, "查询成功", list);
    }


    /**
     * 查询指定商品的所有评论
     * @param thingId 商品ID（用于筛选该商品的评论）
     * @param order 排序方式（"recent"：按时间倒序；"hot"：按点赞数倒序）
     * @return 统一响应对象，包含该商品的评论列表
     */
    @RequestMapping(value = "/listThingComments", method = RequestMethod.GET)
    public APIResponse listThingComments(String thingId, String order){
        List<Comment> list =  service.getThingCommentList(thingId, order);
        return new APIResponse(ResponeCode.SUCCESS, "查询成功", list);
    }

    /**
     * 查询指定用户的所有评论
     * @param userId 用户ID（用于筛选该用户发布的评论）
     * @return 统一响应对象，包含该用户的评论列表
     */
    @RequestMapping(value = "/listUserComments", method = RequestMethod.GET)
    public APIResponse listUserComments(String userId){
        List<Comment> list =  service.getUserCommentList(userId);
        return new APIResponse(ResponeCode.SUCCESS, "查询成功", list);
    }

    /**
     * 创建评论
     * @param comment 评论实体（包含评论内容、关联商品ID、用户ID等）
     * @return 统一响应对象，提示创建结果
     * @throws IOException 可能的IO异常
     */
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @Transactional // 开启事务，确保数据一致性
    public APIResponse create(Comment comment) throws IOException {
        service.createComment(comment);
        return new APIResponse(ResponeCode.SUCCESS, "创建成功");
    }

    /**
     * 批量删除评论（仅管理员可操作）
     * @param ids 评论ID字符串，多个ID用逗号分隔
     * @return 统一响应对象，提示删除结果
     */
    @Access(level = AccessLevel.ADMIN) // 权限控制：仅管理员可访问
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public APIResponse delete(String ids){
        System.out.println("ids===" + ids);
        // 拆分ID数组，批量删除
        String[] arr = ids.split(",");
        for (String id : arr) {
            service.deleteComment(id);
        }
        return new APIResponse(ResponeCode.SUCCESS, "删除成功");
    }

    /**
     * 更新评论（仅管理员可操作）
     * @param comment 包含更新信息的评论实体（需指定ID）
     * @return 统一响应对象，提示更新结果
     * @throws IOException 可能的IO异常
     */
    @Access(level = AccessLevel.ADMIN) // 权限控制：仅管理员可访问
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @Transactional // 开启事务，确保数据一致性
    public APIResponse update(Comment comment) throws IOException {
        service.updateComment(comment);
        return new APIResponse(ResponeCode.SUCCESS, "更新成功");
    }

    /**
     * 评论点赞（点赞数+1）
     * @param commentId 评论ID
     * @return 统一响应对象，提示点赞结果
     * @throws IOException 可能的IO异常
     */
    @RequestMapping(value = "/like", method = RequestMethod.POST)
    @Transactional // 开启事务，确保点赞数更新准确
    public APIResponse like(Long commentId,Integer userId) throws IOException {
        Comment commentBean = service.getCommentDetail(commentId); // 获取评论详情
        if (service.likeComment(commentId,userId)){
            // 将推荐取消掉
            int likeCount = commentBean.getLikeCount() -1; // 点赞数+1
            commentBean.setLikeCount(likeCount);
            service.updateComment(commentBean); // 更新评论点赞数

        }else{
            int likeCount = commentBean.getLikeCount() +1;
            commentBean.setLikeCount(likeCount);
            service.updateComment(commentBean);
        }
        return new APIResponse(ResponeCode.SUCCESS, "更新成功");
    }

}
package com.gk.study.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gk.study.entity.LikeCount;

public interface LikeCountMapper extends BaseMapper<LikeCount> {
}

package com.gk.study.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gk.study.entity.ThingTag;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ThingTagMapper extends BaseMapper<ThingTag> {

}

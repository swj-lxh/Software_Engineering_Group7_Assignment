package com.gk.study.controller;

import com.gk.study.common.APIResponse;
import com.gk.study.common.ResponeCode;
import com.gk.study.entity.OpLog;
import com.gk.study.service.OpLogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

// 操作日志控制器：负责处理操作日志和登录日志的相关HTTP请求（查询、创建、删除、更新）
@RestController
@RequestMapping("/opLog") // 映射请求路径前缀：/opLog
public class OpLogController {

    private final static Logger logger = LoggerFactory.getLogger(OpLogController.class);

    @Autowired
    OpLogService service; // 注入操作日志服务层对象，处理业务逻辑

    /**
     * 查询所有操作日志列表
     * @return 统一响应对象，包含操作日志列表数据
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public APIResponse list(){
        List<OpLog> list =  service.getOpLogList();
        return new APIResponse(ResponeCode.SUCCESS, "查询成功", list);
    }

    /**
     * 查询所有登录日志列表
     * @return 统一响应对象，包含登录日志列表数据
     */
    @RequestMapping(value = "/loginLogList", method = RequestMethod.GET)
    public APIResponse loginLogList(){
        List<OpLog> list =  service.getLoginLogList();
        return new APIResponse(ResponeCode.SUCCESS, "查询成功", list);
    }

    /**
     * 创建操作日志
     * @param opLog 操作日志实体对象（包含日志详情）
     * @return 统一响应对象，提示创建结果
     * @throws IOException 可能的IO异常
     */
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @Transactional // 开启事务，确保数据一致性
    public APIResponse create(OpLog opLog) throws IOException {
        service.createOpLog(opLog);
        return new APIResponse(ResponeCode.SUCCESS, "创建成功");
    }

    /**
     * 批量删除操作日志
     * @param ids 日志ID字符串，多个ID用逗号分隔（如"1,2,3"）
     * @return 统一响应对象，提示删除结果
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public APIResponse delete(String ids){
        System.out.println("ids===" + ids);
        // 拆分ID字符串为数组，实现批量删除
        String[] arr = ids.split(",");
        for (String id : arr) {
            service.deleteOpLog(id);
        }
        return new APIResponse(ResponeCode.SUCCESS, "删除成功");
    }

    /**
     * 更新操作日志
     * @param opLog 包含更新信息的操作日志实体（需指定ID）
     * @return 统一响应对象，提示更新结果
     * @throws IOException 可能的IO异常
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @Transactional // 开启事务，确保数据一致性
    public APIResponse update(OpLog opLog) throws IOException {
        service.updateOpLog(opLog);
        return new APIResponse(ResponeCode.SUCCESS, "更新成功");
    }

}
package com.gk.study.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gk.study.entity.Order;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

// 订单数据访问接口：继承BaseMapper，提供订单表的CRUD操作
@Mapper
public interface OrderMapper extends BaseMapper<Order> {

    /**
     * 查询所有订单列表
     * @return 订单列表
     */
    List<Order> getList();

    /**
     * 查询指定用户的订单列表（支持按状态筛选）
     * @param userId 用户ID
     * @param status 订单状态
     * @return 用户订单列表
     */
    List<Order> getUserOrderList(String userId, String status);
}
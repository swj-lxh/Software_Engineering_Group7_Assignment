package com.gk.study.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gk.study.mapper.ThingCollectMapper;
import com.gk.study.mapper.ThingMapper;
import com.gk.study.service.ThingCollectService;
import com.gk.study.entity.ThingCollect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
class ThingCollectServiceImpl extends ServiceImpl<ThingCollectMapper, ThingCollect> implements ThingCollectService {
    @Autowired
    ThingCollectMapper thingCollectMapper;
    @Autowired
    ThingMapper thingMapper ;

    @Override
    public List<Map> getThingCollectList(String userId) {
        return thingCollectMapper.getThingCollectList(userId);
    }

    @Override
    public void createThingCollect(ThingCollect thingCollect) {
        thingCollectMapper.insert(thingCollect);;
    }

    @Override
    public void deleteThingCollect(String id) {
        ThingCollect thingCollect = thingCollectMapper.selectById(id);
        if (thingCollect != null) {
            thingCollectMapper.deleteById(id);
            Integer thingId = thingCollect.getThingId();// 安全转换
            thingMapper.collectCountDecrement(thingId);
        }
    }

    @Override
    public ThingCollect getThingCollect(Integer userId, Integer thingId) {
        QueryWrapper<ThingCollect> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("thing_id", thingId)
                .eq("user_id", userId);
        return thingCollectMapper.selectOne(queryWrapper);
    }
}

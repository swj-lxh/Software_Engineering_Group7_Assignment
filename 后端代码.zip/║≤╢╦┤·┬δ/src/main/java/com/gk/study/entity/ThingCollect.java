package com.gk.study.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;


@Data
@TableName("thing_collect")
public class ThingCollect implements Serializable {
    @TableId(value = "id",type = IdType.AUTO)
    public Integer id;
    @TableField
    public Integer thingId;
    @TableField
    public Integer userId;

}

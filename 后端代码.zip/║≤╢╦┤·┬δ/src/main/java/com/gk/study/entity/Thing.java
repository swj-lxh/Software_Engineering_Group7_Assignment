package com.gk.study.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.util.List;

@Data
@TableName("thing")
public class Thing implements Serializable {
    @TableId(value = "id",type = IdType.AUTO)
    public Integer id;
    @TableField
    public String title;
    @TableField
    public String cover;
    @TableField
    public String description;
    @TableField
    public String price;
    @TableField
    public String status;
    @TableField
    public String createTime;
    @TableField
    public String repertory;
    @TableField
    public String score;
    @TableField
    public Integer wishCount;
    @TableField
    public Integer collectCount;
    @TableField
    public Integer classificationId;
    @TableField(exist = false)
    public String classificationTitle;
    @TableField(exist = false)
    public List<Integer> tags; // 标签

    @TableField(exist = false)
    public MultipartFile imageFile;

}

package com.gk.study.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gk.study.entity.Thing;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ThingMapper extends BaseMapper<Thing> {
    void wichCountDecrement(Integer thingId);

    void collectCountDecrement(Integer thingId);
//    List<Thing> getList();
//    boolean update(Thing thing);
}

package com.gk.study.service;


import com.gk.study.entity.ShoppingCart;

import java.util.List;
import java.util.Map;

public interface ShoppingCartService {
    List<Map> getThingWishList(String userId);
    void createThingWish(ShoppingCart shoppingCart);
    void deleteThingWish(String id);

    ShoppingCart getThingWish(Integer userId, Integer thingId);
}

package com.gk.study.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gk.study.entity.Comment;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

// 评论数据访问接口：继承BaseMapper，提供评论表（b_comment）的CRUD操作
@Mapper
public interface CommentMapper extends BaseMapper<Comment> {

    /**
     * 查询所有评论（关联用户表和商品表，获取用户名和商品标题）
     * @return 评论列表（包含关联信息）
     */
    List<Comment> getList();

    /**
     * 查询指定商品的评论列表（支持排序）
     * @param thingId 商品ID
     * @param order 排序方式（"recent"：按时间倒序；"hot"：按点赞数倒序）
     * @return 商品评论列表
     */
    List<Comment> selectThingCommentList(String thingId, String order);

    /**
     * 查询指定用户的评论列表
     * @param userId 用户ID
     * @return 用户评论列表
     */
    List<Comment> selectUserCommentList(String userId);
}
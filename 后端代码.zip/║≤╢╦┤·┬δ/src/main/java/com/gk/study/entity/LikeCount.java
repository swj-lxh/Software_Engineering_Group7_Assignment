package com.gk.study.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("like_count")
public class LikeCount {
    @TableId(value = "id",type = IdType.AUTO)
    public Long id;
    @TableField
    public Long commentId;
    @TableField
    public Integer userId;
}

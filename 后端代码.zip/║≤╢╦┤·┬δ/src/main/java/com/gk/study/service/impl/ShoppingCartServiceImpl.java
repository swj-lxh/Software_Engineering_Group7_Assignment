package com.gk.study.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gk.study.mapper.ThingMapper;
import com.gk.study.mapper.ShoppingCartMapper;
import com.gk.study.service.ShoppingCartService;
import com.gk.study.entity.ShoppingCart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
class ShoppingCartServiceImpl extends ServiceImpl<ShoppingCartMapper, ShoppingCart> implements ShoppingCartService {
    @Autowired
    ShoppingCartMapper mapper;
    @Autowired
    ThingMapper thingMapper;

    @Override
    public List<Map> getThingWishList(String userId) {
        return mapper.getThingWishList(userId);
    }

    @Override
    public void createThingWish(ShoppingCart shoppingCart) {
        mapper.insert(shoppingCart);;
    }
    @Transactional
    @Override
    public void deleteThingWish(String id) {
        ShoppingCart shoppingCart = mapper.selectById(id);
        if (shoppingCart != null) {
            mapper.deleteById(id);
            // 若 thingId 应该用于删除操作，则补全逻辑
            Integer thingId = shoppingCart.getThingId();// 安全转换
            thingMapper.wichCountDecrement(thingId);
        }
    }


    @Override
    public ShoppingCart getThingWish(Integer userId, Integer thingId) {
        QueryWrapper<ShoppingCart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("thing_id", thingId)
                .eq("user_id", userId);
        return mapper.selectOne(queryWrapper);
    }
}

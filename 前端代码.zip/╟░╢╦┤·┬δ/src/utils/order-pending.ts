// 获取待处理订单数的工具函数
import { userOrderListApi } from '/@/api/order'
import { useUserStore } from '/@/store'

export async function fetchPendingOrderCount() {
  const userStore = useUserStore()
  const userId = userStore.user_id
  if (!userId) return 0
  // 假设 status: 1 表示待处理订单
  try {
    const res = await userOrderListApi({ userId, status: 1 })
    return Array.isArray(res.data) ? res.data.length : 0
  } catch {
    return 0
  }
}

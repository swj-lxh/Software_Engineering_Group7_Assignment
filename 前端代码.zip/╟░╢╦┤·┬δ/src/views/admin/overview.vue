<template>
  <div class="main" v-loading="showSpin" element-loading-text="加载中...">
    <!-- 指标卡片区域 -->
    <el-row :gutter="[20, 20]">
      <el-col :sm="24" :md="12" :lg="6">
        <el-card shadow="hover" class="stat-card">
          <template #header>
            <div class="card-header">
              <span>商品总数</span>
              <el-tag type="primary" size="small">总</el-tag>
            </div>
          </template>
          <div class="box">
            <div class="box-top">
              <span class="box-value">{{ tdata.data.spzs }}<span class="v-e">种</span></span>
            </div>
            <div class="box-bottom">
              <span>本周新增 {{ tdata.data.qrxz }} 种</span>
            </div>
          </div>
        </el-card>
      </el-col>

      <el-col :sm="24" :md="12" :lg="6">
        <el-card shadow="hover" class="stat-card">
          <template #header>
            <div class="card-header">
              <span>未付订单</span>
              <el-tag type="success" size="small">未付</el-tag>
            </div>
          </template>
          <div class="box">
            <div class="box-top">
              <span class="box-value">{{ tdata.data.wfdd }}<span class="v-e">单</span></span>
            </div>
            <div class="box-bottom">
              <span>共 {{ tdata.data.wfddrs }} 人</span>
            </div>
          </div>
        </el-card>
      </el-col>

      <el-col :sm="24" :md="12" :lg="6">
        <el-card shadow="hover" class="stat-card">
          <template #header>
            <div class="card-header">
              <span>已付订单</span>
              <el-tag type="primary" size="small">已付</el-tag>
            </div>
          </template>
          <div class="box">
            <div class="box-top">
              <span class="box-value">{{ tdata.data.yfdd }}<span class="v-e">单</span></span>
            </div>
            <div class="box-bottom">
              <span>共 {{ tdata.data.yfddrs }} 人</span>
            </div>
          </div>
        </el-card>
      </el-col>

      <el-col :sm="24" :md="12" :lg="6">
        <el-card shadow="hover" class="stat-card">
          <template #header>
            <div class="card-header">
              <span>取消订单</span>
              <el-tag type="success" size="small">取消</el-tag>
            </div>
          </template>
          <div class="box">
            <div class="box-top">
              <span class="box-value">{{ tdata.data.qxdd }}<span class="v-e">单</span></span>
            </div>
            <div class="box-bottom">
              <span>共 {{ tdata.data.qxddrs }} 人</span>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 访问量图表 -->
    <el-card shadow="hover" class="chart-card">
      <template #header>最近一周访问量</template>
      <div style="height: 300px;" ref="visitChartDiv"></div>
    </el-card>

    <!-- 双图表区域 -->
    <el-row :gutter="[20, 20]">
      <el-col :sm="24" :md="24" :lg="12">
        <el-card shadow="hover" class="chart-card">
          <template #header>热门商品排名</template>
          <div style="height: 300px;" ref="barChartDiv"></div>
        </el-card>
      </el-col>
      <el-col :sm="24" :md="24" :lg="12">
        <el-card shadow="hover" class="chart-card">
          <template #header>热门分类比例</template>
          <div style="height: 300px;" ref="pieChartDiv"></div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import * as echarts from 'echarts'
import { listApi } from '/@/api/overview'

const showSpin = ref(true)

const visitChartDiv = ref<HTMLDivElement | null>(null)
const barChartDiv = ref<HTMLDivElement | null>(null)
const pieChartDiv = ref<HTMLDivElement | null>(null)

let visitChart: echarts.ECharts | null = null
let barChart: echarts.ECharts | null = null
let pieChart: echarts.ECharts | null = null

const tdata = reactive({
  data: {} as Record<string, any>
})

onMounted(() => {
  list()
  window.addEventListener('resize', () => {
    visitChart?.resize()
    barChart?.resize()
    pieChart?.resize()
  })
})

const list = () => {
  listApi({}).then(res => {
    tdata.data = res.data
    initCharts()
    initBarChart()
    initPieChart()
    showSpin.value = false
  }).catch(() => {
    showSpin.value = false
  })
}

// === 图表初始化函数（保持不变）===
const initCharts = () => {
  const xData: string[] = []
  const uvData: number[] = []
  const pvData: number[] = []
  tdata.data.visitList?.forEach((item: any) => {
    xData.push(item.day)
    uvData.push(item.uv)
    pvData.push(item.pv)
  })
  if (visitChartDiv.value) {
    visitChart = echarts.init(visitChartDiv.value)
    visitChart.setOption({
      tooltip: { trigger: 'axis' },
      legend: { data: ['IP', 'visit'], top: '90%', left: 'center' },
      grid: { top: '30px', left: '20px', right: '20px', bottom: '40px', containLabel: true },
      xAxis: {
        type: 'category',
        data: xData,
        axisLabel: { color: '#2F4F4F' },
        axisLine: { lineStyle: { color: '#2F4F4F' } }
      },
      yAxis: {
        type: 'value',
        axisLine: { show: false },
        axisTick: { show: false },
        splitLine: {
          show: true,
          lineStyle: { color: 'rgba(10, 10, 10, 0.1)', width: 1 }
        }
      },
      series: [
        { name: 'IP', type: 'line', stack: 'Total', data: uvData },
        { name: 'visit', type: 'line', stack: 'Total', data: pvData }
      ]
    })
  }
}

const initBarChart = () => {
  const xData: string[] = []
  const yData: number[] = []
  tdata.data.popularThings?.forEach((item: any) => {
    xData.push(item.title)
    yData.push(item.count)
  })
  if (barChartDiv.value) {
    barChart = echarts.init(barChartDiv.value)
    barChart.setOption({
      grid: { top: '40px', left: '40px', right: '40px', bottom: '40px' },
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
      xAxis: {
        type: 'category',
        data: xData,
        axisLabel: { rotate: 30, color: '#2F4F4F' },
        axisLine: { lineStyle: { color: '#2F4F4F' } }
      },
      yAxis: {
        type: 'value',
        axisLine: { show: false },
        axisTick: { show: false },
        splitLine: {
          show: true,
          lineStyle: { color: 'rgba(10, 10, 10, 0.1)', width: 1 }
        }
      },
      series: [{
        type: 'bar',
        data: yData,
        itemStyle: { color: '#70B0EA' }
      }]
    })
  }
}

const initPieChart = () => {
  const pieData: { name: string; value: number }[] = []
  tdata.data.popularClassification?.forEach((item: any) => {
    pieData.push({ name: item.title, value: item.count })
  })
  if (pieChartDiv.value) {
    pieChart = echarts.init(pieChartDiv.value)
    pieChart.setOption({
      tooltip: { trigger: 'item' },
      legend: { top: '90%', left: 'center' },
      series: [{
        name: '分类',
        type: 'pie',
        radius: ['40%', '70%'],
        avoidLabelOverlap: false,
        label: { show: false },
        emphasis: { label: { show: true, fontSize: 20, fontWeight: 'bold' } },
        labelLine: { show: false },
        data: pieData,
        itemStyle: {
          color: (params: any) => {
            const colorList = ['#70B0EA', '#B3A3DA', '#88DEE2', '#62C4C8', '#58A3A1']
            return colorList[params.dataIndex % colorList.length]
          }
        }
      }]
    })
  }
}
</script>

<style lang="less" scoped>
.main {
  height: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px;
  padding: 20px;

  .stat-card {
    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .box {
      padding: 12px 0 0 0;
      display: flex;
      flex-direction: column;

      .box-top {
        display: flex;
        align-items: center;
      }

      .box-value {
        color: #000;
        font-size: 32px;
        margin-right: 12px;

        .v-e {
          font-size: 14px;
        }
      }

      .box-bottom {
        margin-top: 24px;
        color: #000000d9;
      }
    }
  }

  .chart-card {
    flex: 1;
  }
}
</style>
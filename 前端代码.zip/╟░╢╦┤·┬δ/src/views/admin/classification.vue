<template>
  <div>
    <!-- 页面区域 -->
    <div class="page-view">
      <div class="table-operations">
        <el-space>
          <el-button type="primary" @click="handleAdd">新增</el-button>
          <el-button @click="handleBatchDelete">批量删除</el-button>
        </el-space>
      </div>

      <el-table
        ref="tableRef"
        v-loading="data.loading"
        :data="data.userList"
        row-key="id"
        @selection-change="handleSelectionChange"
        style="width: 100%"
      >
        <!-- 自定义全选列（无序号，只有 checkbox） -->
        <el-table-column width="60" align="center">
          <template #header>
            <el-checkbox
              :model-value="isAllSelected"
              :indeterminate="isIndeterminate"
              @change="handleSelectAll"
            />
          </template>
          <template #default="{ row }">
            <el-checkbox
              :model-value="isChecked(row)"
              @change="(val) => handleCheckboxChange(val, row)"
            />
          </template>
        </el-table-column>

        <!-- 分类名称 -->
        <el-table-column prop="title" label="分类名称" />

        <!-- 操作列 -->
        <el-table-column label="操作" width="170" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="handleEdit(row)">编辑</el-button>
            <el-popconfirm
              title="确定删除?"
              confirm-button-text="是"
              cancel-button-text="否"
              @confirm="confirmDelete(row)"
            >
              <template #reference>
                <el-button size="small" type="danger">删除</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>

      <!-- 简化分页（居中） -->
      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="data.page"
          :page-size="data.pageSize"
          :total="data.total"
          layout="total, prev, pager, next"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>

    <!-- 弹窗区域 -->
    <el-dialog
      v-model="modal.visible"
      :title="modal.title"
      width="500px"
      @close="handleCancel"
    >
      <el-form ref="myform" :model="modal.form" :rules="modal.rules" label-width="80px">
        <el-form-item label="分类名称" prop="title">
          <el-input v-model="modal.form.title" placeholder="请输入" />
        </el-form-item>
      </el-form>

      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleCancel">取消</el-button>
          <el-button type="primary" @click="handleOk">确认</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import type { TableInstance } from 'element-plus';
import { createApi, listApi, updateApi, deleteApi } from '/@/api/classification';

interface DataType {
  id: number;
  title: string;
  [key: string]: any;
}

// refs
const myform = ref();
const tableRef = ref<TableInstance>();

// 页面数据
const data = reactive({
  userList: [] as DataType[],
  loading: false,
  selectedRowKeys: [] as number[],
  pageSize: 10,
  page: 1,
  total: 0, // 新增 total 字段用于分页
});

// 弹窗数据源
const modal = reactive({
  visible: false,
  editFlag: false,
  title: '',
  form: {
    id: undefined as number | undefined,
    title: undefined as string | undefined,
  },
  rules: {
    title: [{ required: true, message: '请输入分类名称', trigger: 'change' }],
  },
});

onMounted(() => {
  getDataList();
});

const getDataList = () => {
  data.loading = true;
  listApi({
    keyword: '',
    pageNum: data.page,
    pageSize: data.pageSize,
  })
    .then((res) => {
      data.loading = false;
      const result = res.data || res;
      // 兼容两种返回格式
      if (Array.isArray(result)) {
        data.userList = result;
        data.total = result.length;
      } else {
        data.userList = Array.isArray(result.list) ? result.list : [];
        data.total = result.total ?? data.userList.length;
      }
    })
    .catch((err) => {
      data.loading = false;
      console.error('获取列表失败:', err);
    });
};

// 行是否选中
const isChecked = (row: DataType) => {
  return data.selectedRowKeys.includes(row.id);
};

// 手动处理行 checkbox
const handleCheckboxChange = (checked: boolean, row: DataType) => {
  let keys = [...data.selectedRowKeys];
  if (checked) {
    if (!keys.includes(row.id)) keys.push(row.id);
  } else {
    keys = keys.filter(id => id !== row.id);
  }
  data.selectedRowKeys = keys;
  tableRef.value?.toggleRowSelection(row, checked);
};

// 全选状态
const isAllSelected = computed(() => {
  return data.userList.length > 0 && data.selectedRowKeys.length === data.userList.length;
});

const isIndeterminate = computed(() => {
  return data.selectedRowKeys.length > 0 && data.selectedRowKeys.length < data.userList.length;
});

// 表头全选
const handleSelectAll = (checked: boolean) => {
  const keys = checked ? data.userList.map(item => item.id) : [];
  data.selectedRowKeys = keys;
  data.userList.forEach(row => {
    tableRef.value?.toggleRowSelection(row, checked);
  });
};

// selection-change（用于外部同步）
const handleSelectionChange = (selection: DataType[]) => {
  data.selectedRowKeys = selection.map(item => item.id);
};

// 分页变化
const handleCurrentChange = (page: number) => {
  data.page = page;
  getDataList();
};

// 新增
const handleAdd = () => {
  modal.visible = true;
  modal.editFlag = false;
  modal.title = '新增';
  modal.form = { id: undefined, title: undefined };
  myform.value?.resetFields();
};

// 编辑
const handleEdit = (record: DataType) => {
  modal.visible = true;
  modal.editFlag = true;
  modal.title = '编辑';
  modal.form = { id: record.id, title: record.title };
};

// 单删
const confirmDelete = (record: DataType) => {
  deleteApi({ ids: String(record.id) })
    .then(() => {
      ElMessage.success('删除成功');
      getDataList();
    })
    .catch((err) => {
      ElMessage.error(err.msg || '删除失败');
    });
};

// 批量删除
const handleBatchDelete = () => {
  if (data.selectedRowKeys.length === 0) {
    ElMessage.warning('请勾选要删除的项');
    return;
  }

  ElMessageBox.confirm('确定删除选中的项目?', '确认删除', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  }).then(() => {
    deleteApi({ ids: data.selectedRowKeys.join(',') })
      .then(() => {
        ElMessage.success('删除成功');
        data.selectedRowKeys = [];
        getDataList();
      })
      .catch((err) => {
        ElMessage.error(err.msg || '操作失败');
      });
  });
};

// 提交
const handleOk = () => {
  myform.value?.validate().then(() => {
    const api = modal.editFlag ? updateApi : createApi;
    const params = modal.editFlag ? { id: modal.form.id } : {};
    api(params, modal.form)
      .then(() => {
        ElMessage.success(modal.editFlag ? '更新成功' : '创建成功');
        modal.visible = false;
        getDataList();
      })
      .catch((err) => {
        ElMessage.error(err.msg || '操作失败');
      });
  });
};

// 取消
const handleCancel = () => {
  modal.visible = false;
  myform.value?.resetFields();
};
</script>

<style scoped lang="less">
.page-view {
  min-height: 100%;
  background: #fff;
  padding: 24px;
  display: flex;
  flex-direction: column;
}

.table-operations {
  margin-bottom: 16px;
  text-align: right;
}

.dialog-footer {
  button {
    margin-left: 10px;
  }
}

// 表头深灰色 + 白色文字（覆盖原浅灰）
:deep(.el-table__header th) {
  background-color: #f4f3f3 !important;
  color: #020202 !important;
  font-weight: bold;
}

// 分页居中
.pagination-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}
</style>
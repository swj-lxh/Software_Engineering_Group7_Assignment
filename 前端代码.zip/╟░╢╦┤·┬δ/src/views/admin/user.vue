<template>
  <div>
    <!--页面区域-->
    <div class="page-view">
      <div class="table-operations">
        <el-space>
          <el-button type="primary" @click="handleAdd">新增</el-button>
          <el-button @click="handleBatchDelete">批量删除</el-button>
          <el-input v-model="data.keyword" placeholder="请输入用户名" style="width: 300px" clearable>
            <template #prepend>用户名</template>
            <template #append>
              <el-button @click="onSearch">
                <el-icon>
                  <Search />
                </el-icon>
              </el-button>
            </template>
          </el-input>
        </el-space>
      </div>

      <el-table ref="tableRef" :data="paginatedData" :loading="data.loading" row-key="id" style="width: 100%"
        @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55" />
        <el-table-column prop="index" label="序号" width="60" align="center" />
        <el-table-column prop="username" label="用户名" align="center" />
        <el-table-column prop="nickname" label="昵称" align="center" />
        <el-table-column prop="role" label="角色" align="center">
          <template #default="{ row }">
            <span v-if="row.role === '1'">普通用户</span>
            <span v-else-if="row.role === '2'">演示帐号</span>
            <span v-else-if="row.role === '3'">管理员</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" align="center">
          <template #default="{ row }">
            <el-tag :type="row.status === '0' ? 'success' : 'danger'">
              {{ row.status === '0' ? '正常' : '封号' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="email" label="邮箱" align="center" />
        <el-table-column prop="mobile" label="手机号" align="center" />
        <el-table-column prop="createTime" label="创建时间" align="center">
          <template #default="{ row }">
            {{ getFormatTime(row.createTime, true) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" fixed="right" width="160">
          <template #default="{ row }">
            <el-button link type="primary" @click="handleEdit(row)">编辑</el-button>
            <el-divider direction="vertical" />
            <el-popconfirm title="确定删除该用户吗？" @confirm="confirmDelete(row)">
              <template #reference>
                <el-button link type="danger">删除</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :total="filteredData.length"
        layout="total, prev, pager, next" background style="margin-top: 16px; text-align: center " />
    </div>

    <!--弹窗区域-->
    <el-dialog v-model="modal.visible" :title="modal.title" width="500px" @close="handleCancel">
      <el-form ref="formRef" :model="modal.form" :rules="modal.rules" label-width="80px" size="default">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="modal.form.username" :disabled="modal.editFlag" placeholder="请输入用户名" clearable />
        </el-form-item>

        <el-form-item v-if="!modal.editFlag" label="密码" prop="password">
          <el-input v-model="modal.form.password" type="password" placeholder="请输入密码" show-password clearable />
        </el-form-item>

        <el-form-item label="昵称" prop="nickname">
          <el-input v-model="modal.form.nickname" placeholder="请输入昵称" clearable />
        </el-form-item>

        <el-form-item label="角色" prop="role">
          <el-select v-model="modal.form.role" placeholder="请选择角色" clearable style="width: 100%">
            <el-option v-for="item in modal.roleData" :key="item.id" :label="item.title" :value="item.id" />
          </el-select>
        </el-form-item>

        <el-form-item label="状态" prop="status">
          <el-select v-model="modal.form.status" placeholder="请选择状态" clearable style="width: 100%">
            <el-option label="正常" value="0" />
            <el-option label="封号" value="1" />
          </el-select>
        </el-form-item>

        <el-form-item label="邮箱" prop="email">
          <el-input v-model="modal.form.email" placeholder="请输入邮箱" clearable />
        </el-form-item>

        <el-form-item label="手机号" prop="mobile">
          <el-input v-model="modal.form.mobile" placeholder="请输入手机号" clearable />
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="handleCancel">取消</el-button>
        <el-button type="primary" @click="handleOk" :loading="submitLoading">
          确认
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search } from '@element-plus/icons-vue'
import { createApi, listApi, updateApi, deleteApi } from '/@/api/user'
import { getFormatTime } from '/@/utils'

// 角色映射
const roleMap = {
  '1': '普通用户',
  '2': '演示帐号',
  '3': '管理员',
}

// 分页相关
const currentPage = ref(1)
const pageSize = ref(10)

// 搜索关键词
const searchKeyword = ref('')

// 表格引用
const tableRef = ref()

// 表单引用
const formRef = ref()
const submitLoading = ref(false)

// 选中的行
const selectedRowKeys = ref<string[]>([])

// 页面数据
const data = reactive({
  loading: false,
  userList: [] as any[],
  keyword: ''
})

// 弹窗数据
const modal = reactive({
  visible: false,
  editFlag: false,
  title: '',
  roleData: [
    { id: '1', title: '普通用户' },
    { id: '2', title: '演示帐号' },
    { id: '3', title: '管理员' },
  ],
  form: {
    id: undefined as string | undefined,
    username: undefined as string | undefined,
    password: undefined as string | undefined,
    nickname: undefined as string | undefined,
    role: undefined as string | undefined,
    status: undefined as string | undefined,
    email: undefined as string | undefined,
    mobile: undefined as string | undefined,
  },
  rules: {
    username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
    password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
    nickname: [{ required: true, message: '请输入昵称', trigger: 'blur' }],
    role: [{ required: true, message: '请选择角色', trigger: 'change' }],
    status: [{ required: true, message: '请选择状态', trigger: 'change' }],
  },
})

// 过滤后的数据（根据搜索关键词）
const filteredData = computed(() => {
  const keyword = searchKeyword.value.trim().toLowerCase()
  if (!keyword) return data.userList
  return data.userList.filter(
    (item) =>
      item.username?.toLowerCase().includes(keyword) ||
      item.nickname?.toLowerCase().includes(keyword)
  )
})

// 当前页数据（分页）
const paginatedData = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value
  const end = start + pageSize.value
  return filteredData.value.slice(start, end).map((item, index) => ({
    ...item,
    index: start + index + 1,
  }))
})

// 处理选择变化
const handleSelectionChange = (selection: any[]) => {
  selectedRowKeys.value = selection.map(item => item.id)
}

// 获取用户列表
const getUserList = () => {
  data.loading = true
  listApi({
    keyword: data.keyword,
  })
    .then((res) => {
      data.loading = false
      data.userList = Array.isArray(res.data) ? res.data : []
      currentPage.value = 1
    })
    .catch((err) => {
      data.loading = false
      ElMessage.error(err.msg || '获取用户列表失败')
    })
}

// 搜索处理
const onSearch = () => {
  searchKeyword.value = data.keyword
  currentPage.value = 1
}

// 新增用户
const handleAdd = () => {
  resetModal()
  modal.visible = true
  modal.editFlag = false
  modal.title = '新增用户'

  // 重置表单
  Object.keys(modal.form).forEach(key => {
    modal.form[key as keyof typeof modal.form] = undefined
  })
}

// 编辑用户
const handleEdit = (record: any) => {
  resetModal()
  modal.visible = true
  modal.editFlag = true
  modal.title = '编辑用户'

  // 填充表单数据
  Object.keys(modal.form).forEach(key => {
    modal.form[key as keyof typeof modal.form] = record[key]
  })
}

// 确认删除
const confirmDelete = (record: any) => {
  deleteApi({ ids: record.id })
    .then(() => {
      ElMessage.success('删除成功')
      getUserList()
    })
    .catch((err) => {
      ElMessage.error(err.msg || '删除失败')
    })
}

// 批量删除
const handleBatchDelete = () => {
  if (selectedRowKeys.value.length <= 0) {
    ElMessage.warning('请勾选要删除的用户')
    return
  }

  ElMessageBox.confirm(
    `确定要删除选中的 ${selectedRowKeys.value.length} 个用户吗？`,
    '确认删除',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
    }
  )
    .then(() => {
      deleteApi({ ids: selectedRowKeys.value.join(',') })
        .then(() => {
          ElMessage.success('删除成功')
          selectedRowKeys.value = []
          getUserList()
        })
        .catch((err) => {
          ElMessage.error(err.msg || '删除失败')
        })
    })
    .catch(() => {
      // 取消删除
    })
}

// 提交表单
const handleOk = () => {
  formRef.value?.validate((valid: boolean) => {
    if (valid) {
      submitLoading.value = true

      const formData = new FormData()
      if (modal.form.id) formData.append('id', modal.form.id)
      if (modal.form.username) formData.append('username', modal.form.username)
      if (modal.form.password) formData.append('password', modal.form.password)
      if (modal.form.nickname) formData.append('nickname', modal.form.nickname)
      if (modal.form.role) formData.append('role', modal.form.role)
      if (modal.form.status) formData.append('status', modal.form.status)
      if (modal.form.email) formData.append('email', modal.form.email)
      if (modal.form.mobile) formData.append('mobile', modal.form.mobile)

      const api = modal.editFlag ? updateApi : createApi

      api(formData)
        .then(() => {
          ElMessage.success(`${modal.editFlag ? '更新' : '创建'}成功`)
          hideModal()
          getUserList()
        })
        .catch((err) => {
          ElMessage.error(err.msg || `${modal.editFlag ? '更新' : '创建'}失败`)
        })
        .finally(() => {
          submitLoading.value = false
        })
    }
  })
}

// 取消操作
const handleCancel = () => {
  hideModal()
}

// 重置表单
const resetModal = () => {
  formRef.value?.resetFields()
}

// 关闭弹窗
const hideModal = () => {
  modal.visible = false
}

onMounted(() => {
  getUserList()
})
</script>

<style scoped lang="less">
.page-view {
  min-height: 100%;
  background: #fff;
  padding: 24px;
  display: flex;
  flex-direction: column;
}

.table-operations {
  margin-bottom: 16px;
  text-align: right;
}

.table-operations>.el-button {
  margin-right: 8px;
}

/* 添加这个样式来使分页条居中 */
:deep(.el-pagination) {
  margin-top: 16px;
  text-align: center;
}
</style>
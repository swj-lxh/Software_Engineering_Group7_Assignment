<template>
  <el-container id="components-layout-demo-custom-trigger" class="admin-layout">
    <!-- 头部区域 -->
    <el-header class="header-container">
      <!-- 波浪背景容器 -->
      <div class="wave-container"></div>

      <div class="header">
        <!-- 中国海洋大学校徽 -->
        <img class="header-logo" :src="logo" alt="中国海洋大学校徽">
        <span class="header-title">商城后端管理系统</span>
        <div class="empty"></div>
        <el-button style="margin-right: 24px;" @click="handlePreview">前台预览</el-button>
        <span>管理员[{{ userStore.admin_user_name }}]</span>
        <a class="header-quit" @click="handleLogout">退出</a>
      </div>
    </el-header>

    <!-- 主体区域 -->
    <el-container>
      <!-- 侧边栏 -->
      <el-aside :width="collapsed ? '64px' : '200px'" class="sider">
        <div class="sidebar-toggle" @click="toggleCollapse">
          <el-icon v-if="collapsed">
            <Expand />
          </el-icon>
          <el-icon v-else>
            <Fold />
          </el-icon>
        </div>
        <el-scrollbar class="menu-scrollbar">
          <el-menu :default-active="activeMenu" :collapse="collapsed" background-color="#fff" text-color="#303133"
            active-text-color="#409EFF" class="sidebar-menu" @select="handleSelect">
            <el-menu-item index="overview">
              <el-icon>
                <HomeFilled />
              </el-icon>
              <template #title>总览</template>
            </el-menu-item>
            <el-menu-item index="user">
              <el-icon>
                <User />
              </el-icon>
              <template #title>用户管理</template>
            </el-menu-item>
            <el-sub-menu index="product">
              <template #title>
                <el-icon>
                  <Memo />
                </el-icon>
                <span>产品管理</span>
              </template>
              <el-menu-item index="classification">
                <el-icon>
                  <Grid />
                </el-icon>
                <template #title>分类管理</template>
              </el-menu-item>
              <el-menu-item index="tag">
                <el-icon>
                  <PriceTag />
                </el-icon>
                <template #title>标签管理</template>
              </el-menu-item>
              <el-menu-item index="thing">
                <el-icon>
                  <Goods />
                </el-icon>
                <template #title>商品管理</template>
              </el-menu-item>
            </el-sub-menu>
            <el-menu-item index="order">
              <el-icon>
                <Document />
              </el-icon>
              <template #title>订单管理</template>
            </el-menu-item>

            <el-menu-item index="comment">
              <el-icon>
                <ChatLineSquare />
              </el-icon>
              <template #title>评论管理</template>
            </el-menu-item>

            <el-menu-item index="notice">
              <el-icon>
                <Notification />
              </el-icon>
              <template #title>通知管理</template>
            </el-menu-item>
            <el-sub-menu index="logs">
              <template #title>
                <el-icon>
                  <Memo />
                </el-icon>
                <span>日志管理</span>
              </template>
              <el-menu-item index="loginLog">
                <el-icon>
                  <User />
                </el-icon>
                <template #title>登录日志</template>
              </el-menu-item>
              <el-menu-item index="opLog">
                <el-icon>
                  <Operation />
                </el-icon>
                <template #title>操作日志</template>
              </el-menu-item>
              <el-menu-item index="errorLog">
                <el-icon>
                  <Warning />
                </el-icon>
                <template #title>错误日志</template>
              </el-menu-item>
            </el-sub-menu>
            <el-menu-item index="sysInfo">
              <el-icon>
                <InfoFilled />
              </el-icon>
              <template #title>系统信息</template>
            </el-menu-item>
          </el-menu>
        </el-scrollbar>
      </el-aside>

      <!-- 主要内容区域 -->
      <el-main class="main-content">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup lang="ts">
import { useRouter, useRoute } from 'vue-router'
import logo from '/@/assets/images/ouc.png'  // 注意：这里使用了第二段代码的路径，请确保图片存在
import { ref, computed, onMounted } from 'vue'
import { useUserStore } from "/@/store"

// Element Plus Icons
import {
  HomeFilled,
  User,
  Grid,
  PriceTag,
  Document,
  Goods,
  ChatLineSquare,
  FolderOpened,
  Management,
  Notification,
  Memo,
  Operation,
  Warning,
  InfoFilled,
  Expand,
  Fold
} from '@element-plus/icons-vue'

const userStore = useUserStore()

const collapsed = ref<boolean>(false)
const router = useRouter()
const route = useRoute()

// 计算当前激活的菜单项
const activeMenu = computed(() => route.name as string)

const toggleCollapse = () => {
  collapsed.value = !collapsed.value
}

const handleSelect = (key: string) => {
  console.log('点击路由===>', key)
  router.push({
    name: key,
  })
}

const handlePreview = () => {
  let text = router.resolve({ name: 'index' })
  window.open(text.href, '_blank')
}

onMounted(() => {
  console.log('当前路由===>', route.name)
})

const handleLogout = () => {
  userStore.adminLogout().then(res => {
    router.push({ name: 'adminLogin' })
  })
}
</script>

<style scoped lang="less">
.admin-layout {
  height: 100vh;

  .header-container {
    background: linear-gradient(to right, #f0f7ff, #e6f0ff);
    /* 浅蓝色渐变背景 */
    padding: 0;
    box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
    z-index: 9;
    position: relative;
    /* 为波浪绝对定位提供参考 */
    overflow: hidden;
    /* 隐藏超出容器的波浪部分 */
  }

  /* 波浪动画样式 */
  .wave-container {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 20px;
    /* 波浪高度 */
    z-index: 1;
    /* 确保在标题下方 */

    &::before,
    &::after {
      content: "";
      position: absolute;
      width: 200%;
      height: 100%;
      background-repeat: repeat-x;
      animation: waveMove 8s linear infinite;
    }

    &::before {
      background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320'%3E%3Cpath fill='%230066b2' fill-opacity='0.1' d='M0,192L48,181.3C96,171,192,149,288,149.3C384,149,480,171,576,181.3C672,192,768,192,864,181.3C960,171,1056,149,1152,144C1248,139,1344,149,1392,154.7L1440,160L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z'%3E%3C/path%3E%3C/svg%3E");
      bottom: 0;
      animation-delay: 0s;
    }

    &::after {
      background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320'%3E%3Cpath fill='%230095d9' fill-opacity='0.1' d='M0,224L48,213.3C96,203,192,181,288,181.3C384,181,480,203,576,213.3C672,224,768,224,864,213.3C960,203,1056,181,1152,181.3C1248,181,1344,203,1392,213.3L1440,224L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z'%3E%3C/path%3E%3C/svg%3E");
      bottom: 5px;
      animation-delay: -4s;
    }
  }

  /* 波浪动画关键帧 */
  @keyframes waveMove {
    0% {
      transform: translateX(0);
    }

    100% {
      transform: translateX(-50%);
    }
  }

  /* header样式 */
  .header {
    position: relative;
    /* 确保标题在波浪上方 */
    z-index: 2;
    display: flex;
    flex-direction: row;
    align-items: center; // 垂直居中
    padding-left: 24px;
    padding-right: 24px;
    height: 100%;

    .header-logo {
      width: 36px;
      height: 36px;
      object-fit: contain;
      cursor: pointer;
    }

    .header-title {
      margin-left: 16px;
      font-size: 20px;
      font-weight: bold;
      text-align: center;
      color: #0066b2;
      /* 校色文字 */
    }

    .empty {
      flex: 1;
    }

    .header-quit {
      margin-left: 12px;
      cursor: pointer;
      color: #0095d9;
      /* 辅助色按钮 */

      &:hover {
        color: #0066b2;
        text-decoration: underline;
      }
    }
  }

  /* 侧边栏样式 */
  .sider {
    background-color: #fff;
    border-right: 1px solid #e6e6e6;
    transition: width 0.3s ease;
    position: relative;

    .sidebar-toggle {
      position: absolute;
      top: 16px;
      right: 16px;
      z-index: 10;
      width: 24px;
      height: 24px;
      text-align: center;
      line-height: 24px;
      cursor: pointer;
      color: #909399;
    }

    .menu-scrollbar {
      height: calc(100% - 40px);
      margin-top: 40px;

      :deep(.el-menu) {
        border-right: none;

        &.el-menu--collapse {
          :deep(.el-sub-menu__title) {
            text-align: center;
          }
        }
      }
    }
  }

  /* 主要内容区域 */
  .main-content {
    margin: 16px;
    min-height: 200px;
    background: #fff;
    border-radius: 4px;
    padding: 20px;
  }
}

#components-layout-demo-custom-trigger {
  height: 100%;
}

:deep(.el-header) {
  height: 64px !important;
  line-height: 64px;
  padding: 0;
}
</style>
<!-- eslint-disable prettier/prettier -->
<template>
  <div id="userLayout">
    <div class="user-layout-header">
      <img class="logo" :src="logoImage" alt="" />
      <span>商城后台管理系统</span>
    </div>

    <div class="main-container">
      <div class="main">
        <div class="main_right">
          <h2 class="sys_title">管理员登录</h2>

          <el-form
            ref="loginFormRef"
            :model="loginForm"
            :rules="rules"
            label-position="top"
            size="large"
            @submit.prevent
          >
            <el-form-item prop="username" label="账号">
              <el-input
                v-model="loginForm.username"
                placeholder="请输入登录账号"
                @keyup.enter="handleSubmit"
              >
                <template #prefix>
                  <User />
                </template>
              </el-input>
            </el-form-item>

            <el-form-item prop="password" label="密码">
              <el-input
                v-model="loginForm.password"
                type="password"
                placeholder="请输入登录密码"
                show-password
                @keyup.enter="handleSubmit"
              >
                <template #prefix>
                  <Lock />
                </template>
              </el-input>
            </el-form-item>

            <el-form-item style="padding-top: 24px">
              <el-button
                class="login-button"
                type="primary"
                :loading="loginBtn"
                size="large"
                style="width: 100%"
                @click="handleSubmit"
              >
                登录
              </el-button>
            </el-form-item>
          </el-form>

          <div class="error-tip"></div>
        </div>
      </div>
    </div>

    <footer class="footer">
      <div class="copyright">
        <span></span>
      </div>
    </footer>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '/@/store'
import logoImage from '/@/assets/images/ouc.png'

// 图标
import { User, Lock } from '@element-plus/icons-vue'

const router = useRouter()
const userStore = useUserStore()

const loginFormRef = ref()
const loginBtn = ref(false)

const loginForm = reactive({
  username: '',
  password: ''
})

const rules = reactive({
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }]
})

const handleSubmit = () => {
  loginFormRef.value?.validate((valid: boolean) => {
    if (valid) {
      handleLogin()
    } else {
      ElMessage.warning('不能为空')
    }
  })
}

const handleLogin = () => {
  loginBtn.value = true
  userStore
    .adminLogin({
      username: loginForm.username,
      password: loginForm.password
    })
    .then(() => {
      loginSuccess()
    })
    .catch((err: any) => {
      ElMessage.warning(err.msg || '登录失败')
    })
    .finally(() => {
      loginBtn.value = false
    })
}

const loginSuccess = () => {
  ElMessage.success('登录成功！')
  router.push({ path: '/admin' })
}
</script>

<style lang="less" scoped>
#userLayout {
  position: relative;
  height: 100vh;

  .user-layout-header {
    height: 80px;
    padding: 0 24px;
    color: fade(#000, 85%);
    font-size: 28px;
    font-weight: bold;
    line-height: 80px;

    .logo {
      width: 36px;
      height: 36px;
      margin-right: 16px;
      margin-top: -4px;
      vertical-align: middle;
    }
  }

  .main-container {
    width: 100%;
    height: calc(100vh - 160px);
    background-image: url('../images/login.png');
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;

    .main {
      position: absolute;
      right: 80px;
      top: 50%;
      transform: translate(0, -50%);
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 2px 2px 6px #aaa;

      .main_right {
        background: #ffffff;
        padding: 24px;
        width: 420px;
        user-select: none;

        .sys_title {
          font-size: 24px;
          color: fade(#000, 85%);
          font-weight: bold;
          padding-bottom: 8px;
        }

        // 覆盖 Element Plus label 样式
        :deep(.el-form-item__label) {
          font-weight: bold;
          color: rgba(0, 0, 0, 0.85);
        }

        .login-button {
          background: linear-gradient(128deg, #00aaeb, #00c1cd 59%, #0ac2b0 100%);
          border: none;
        }

        .login-button:hover {
          opacity: 0.9;
        }
      }
    }
  }

  .footer {
    height: 80px;
  }
}
</style>
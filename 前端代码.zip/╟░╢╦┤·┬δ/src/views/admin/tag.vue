<template>
  <div class="page-view">
    <!-- 操作区域 -->
    <div class="table-operations">
      <el-button type="primary" @click="handleAdd">新增</el-button>
      <el-button @click="handleBatchDelete">批量删除</el-button>
    </div>

    <!-- 表格 -->
    <el-table ref="tableRef" :data="data.tagList" :loading="data.loading" border style="width: 100%" row-key="id"
      @selection-change="handleSelectionChange">
      <!-- 自定义：全选列（无序号，只有 checkbox） -->
      <el-table-column width="60" align="center">
        <template #header>
          <!-- 表头：全选 checkbox -->
          <el-checkbox :model-value="isAllSelected" :indeterminate="isIndeterminate" @change="handleSelectAll" />
        </template>
        <template #default="{ row }">
          <!-- 行：单选 checkbox -->
          <el-checkbox :model-value="isChecked(row)" @change="(val) => handleCheckboxChange(val, row)" />
        </template>
      </el-table-column>

      <!-- 标签名称 -->
      <el-table-column prop="title" label="标签名称" align="center" />

      <!-- 操作列 -->
      <el-table-column label="操作" width="140" align="center" fixed="right">
        <template #default="{ row }">
          <el-link type="primary" @click="handleEdit(row)">编辑</el-link>
          <el-divider direction="vertical" />
          <el-popconfirm title="确定删除?" confirmButtonText="是" cancelButtonText="否" @confirm="confirmDelete(row)">
            <template #reference>
              <el-link type="danger">删除</el-link>
            </template>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页（居中） -->
    <div class="pagination-wrapper">
      <el-pagination v-model:current-page="data.page" :page-size="data.pageSize" :total="data.total"
        layout="total, prev, pager, next" @current-change="handlePageChange" />
    </div>

    <!-- 弹窗 -->
    <el-dialog v-model="modal.visible" :title="modal.title" width="400px" @close="handleCancel">
      <el-form ref="myformRef" :model="modal.form" :rules="modal.rules" label-width="80px" label-position="left">
        <el-form-item label="标签名称" prop="title">
          <el-input v-model="modal.form.title" placeholder="请输入" clearable />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="handleCancel">取消</el-button>
        <el-button type="primary" @click="handleOk">确认</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import type { FormInstance, TableInstance } from 'element-plus'
import { createApi, listApi, updateApi, deleteApi } from '/@/api/tag'

// refs
const myformRef = ref<FormInstance>()
const tableRef = ref<TableInstance>()

// 页面数据
const data = reactive({
  tagList: [] as any[],
  loading: false,
  selectedRowKeys: [] as (string | number)[],
  pageSize: 10,
  page: 1,
  total: 0,
})

// 弹窗数据
const modal = reactive({
  visible: false,
  editFlag: false,
  title: '',
  form: {
    id: undefined as number | undefined,
    title: '' as string | undefined,
  },
  rules: {
    title: [{ required: true, message: '请输入标签名称', trigger: 'blur' }],
  },
})

// 获取列表
const getDataList = () => {
  data.loading = true
  listApi({
    keyword: '',
    pageNum: data.page,
    pageSize: data.pageSize,
  })
    .then((res) => {
      data.loading = false
      const result = res.data || res
      data.tagList = Array.isArray(result.list) ? result.list : (Array.isArray(result) ? result : [])
      data.total = result.total ?? data.tagList.length
    })
    .catch((err) => {
      data.loading = false
      console.error('获取列表失败:', err)
    })
}

onMounted(() => {
  getDataList()
})

// 分页
const handlePageChange = (page: number) => {
  data.page = page
  getDataList()
}

// 判断某行是否选中
const isChecked = (row: any) => {
  return data.selectedRowKeys.includes(row.id)
}

// 手动处理行 checkbox 变更
const handleCheckboxChange = (checked: boolean, row: any) => {
  let keys = [...data.selectedRowKeys]
  if (checked) {
    if (!keys.includes(row.id)) keys.push(row.id)
  } else {
    keys = keys.filter(id => id !== row.id)
  }
  data.selectedRowKeys = keys
  tableRef.value?.toggleRowSelection(row, checked)
}

// 全选状态计算
const isAllSelected = computed(() => {
  return data.tagList.length > 0 && data.selectedRowKeys.length === data.tagList.length
})

const isIndeterminate = computed(() => {
  return data.selectedRowKeys.length > 0 && data.selectedRowKeys.length < data.tagList.length
})

// 表头全选/取消
const handleSelectAll = (checked: boolean) => {
  const keys = checked ? data.tagList.map((item: any) => item.id) : []
  data.selectedRowKeys = keys
  // 同步表格 UI
  data.tagList.forEach((row: any) => {
    tableRef.value?.toggleRowSelection(row, checked)
  })
}

// selection-change（用于外部触发全选时同步）
const handleSelectionChange = (selection: any[]) => {
  data.selectedRowKeys = selection.map(item => item.id)
}

// 新增
const handleAdd = () => {
  modal.editFlag = false
  modal.title = '新增'
  modal.form = { id: undefined, title: '' }
  modal.visible = true
}

// 编辑
const handleEdit = (record: any) => {
  modal.editFlag = true
  modal.title = '编辑'
  modal.form = { id: record.id, title: record.title }
  modal.visible = true
}

// 单删
const confirmDelete = (record: any) => {
  deleteApi({ ids: String(record.id) })
    .then(() => {
      ElMessage.success('删除成功')
      getDataList()
    })
    .catch((err) => {
      ElMessage.error(err.msg || '删除失败')
    })
}

// 批量删除
const handleBatchDelete = () => {
  if (data.selectedRowKeys.length === 0) {
    ElMessage.warning('请勾选要删除的项')
    return
  }
  deleteApi({ ids: data.selectedRowKeys.join(',') })
    .then(() => {
      ElMessage.success('删除成功')
      data.selectedRowKeys = []
      getDataList()
    })
    .catch((err) => {
      ElMessage.error(err.msg || '操作失败')
    })
}

// 确认提交
const handleOk = () => {
  myformRef.value?.validate((valid) => {
    if (!valid) return

    const api = modal.editFlag ? updateApi : createApi
    const params = modal.editFlag ? { id: modal.form.id } : {}
    api(params, modal.form)
      .then(() => {
        ElMessage.success(modal.editFlag ? '更新成功' : '新增成功')
        modal.visible = false
        getDataList()
      })
      .catch((err) => {
        ElMessage.error(err.msg || '操作失败')
      })
  })
}

// 取消弹窗
const handleCancel = () => {
  modal.visible = false
  myformRef.value?.resetFields()
}
</script>

<style scoped lang="less">
.page-view {
  min-height: 100%;
  background: #fff;
  padding: 24px;
  display: flex;
  flex-direction: column;
}

.table-operations {
  margin-bottom: 16px;
  text-align: right;

  &>* {
    margin-right: 8px;
  }
}

.pagination-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 16px;
}

/* 表头深灰色 */
:deep(.el-table__header th) {
  background-color: #f4f3f3 !important;

  color: #0a0a0a !important;
  font-weight: bold;
  border: 0;
}

/* 可选：让 checkbox 更居中（Element Plus 默认已居中，一般无需调整） */
:deep(.el-table .cell) {
  padding: 0 !important;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
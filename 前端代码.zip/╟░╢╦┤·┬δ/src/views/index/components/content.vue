<template>
  <div class="home-page">
    <!-- 轮播图 - 位于顶部导航栏下方 -->
    <div class="banner-section">
      <el-carousel 
        height="420px" 
        :interval="5000" 
        arrow="always" 
        trigger="click"
        :indicator-position="'outside'"
      >
        <el-carousel-item v-for="item in bannerList" :key="item.id">
            <img :src="item.image" class="banner-img" alt="轮播图">
            <div class="banner-click-area" @click.stop="goBannerProduct(item)"></div>
            <div class="banner-overlay"></div>
            <div class="banner-text">
              <h2>{{ item.title }}</h2>
              <p>{{ item.description }}</p>
              <el-button type="danger" size="large" class="buy-now" @click.stop="goBuyNow(item)">立即购买</el-button>
            </div>
          </el-carousel-item>
      </el-carousel>
    </div>

    <!-- 分类菜单 - 商品分类和热门标签 -->
    <div class="filter-section">
      <div class="filter-card">
        <h3 class="filter-title">
          <i class="el-icon-menu"></i>
          商品分类
        </h3>
        <div class="filter-content">
          <span 
            v-for="item in categoryList" 
            :key="item.id"
            class="filter-btn tag"
            :class="{ 
              'active': currentCategory === item.id,
              'primary': currentCategory === item.id
            }"
            @click="selectCategory(item.id)"
          >
            <i v-if="currentCategory === item.id" class="el-icon-check"></i>
            {{ item.title }}
          </span>
        </div>
      </div>
      
      <div class="filter-card">
        <h3 class="filter-title">
          <i class="el-icon-collection-tag"></i>
          热门标签
        </h3>
        <div class="filter-content">
          <span 
            v-for="item in tagList" 
            :key="item.id"
            class="filter-btn tag"
            :class="{ 
              'active': currentTag === item.id,
              'secondary': currentTag === item.id
            }"
            @click="selectTag(item.id)"
          >
            <i v-if="currentTag === item.id" class="el-icon-check"></i>
            {{ item.title }}
          </span>
        </div>
      </div>
    </div>

    <!-- 商品列表 -->
    <div class="product-section">
      <div class="product-header">
        <h2 class="section-title">
          <i class="el-icon-goods"></i>
          精选商品
          <span class="product-count" v-if="total > 0">
            共 {{ total }} 件商品
          </span>
        </h2>
        <div class="sort-controls">
          <span 
            class="sort-btn"
            :class="{ 'active': currentSort === 'recent' }"
            @click="selectSort('recent')"
          >
            <i class="el-icon-time"></i>
            最新
          </span>
          <span 
            class="sort-btn"
            :class="{ 'active': currentSort === 'hot' }"
            @click="selectSort('hot')"
          >
            <i class="el-icon-fire"></i>
            最热
          </span>
        </div>
      </div>
      
      <el-skeleton :loading="loading" animated :count="8">
        <template #template>
          <div class="skeleton-item">
            <el-skeleton-item variant="image" style="height: 300px; border-radius: 12px;" />
            <div style="padding: 12px;">
              <el-skeleton-item variant="text" style="width: 80%; margin-bottom: 8px;" />
              <el-skeleton-item variant="text" style="width: 60%;" />
            </div>
          </div>
        </template>
        
        <div class="product-grid">
          <div 
            v-for="item in productList" 
            :key="item.id" 
            @click="handleDetail(item)"
            class="product-card"
          >
            <div class="product-image">
              <img :src="item.cover" alt="商品图片">
              <div class="image-overlay">
                <el-button type="primary" size="small" circle @click.stop="viewProduct(item)">
                  <i class="el-icon-view"></i>
                </el-button>
              </div>
            </div>
            <div class="product-info">
              <h3 class="product-title">{{ item.title }}</h3>
              <div class="product-price">
                <span class="price-symbol">¥</span>
                <span class="price-value">{{ item.price }}</span>
              </div>
              <div class="product-tags">
                <span class="product-tag" v-if="item.tag">热门</span>
                <span class="product-tag new" v-if="currentSort === 'recent'">新品</span>
              </div>
            </div>
          </div>
          
          <div v-if="productList.length <= 0 && !loading" class="empty-state">
            <div class="empty-icon">
              <i class="el-icon-search"></i>
            </div>
            <p class="empty-text">暂无商品数据</p>
            <p class="empty-subtext">尝试调整筛选条件或稍后再来</p>
          </div>
        </div>
      </el-skeleton>
      
      <div class="pagination-container" v-if="total > 0">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[12, 24, 36]"
          layout="total, sizes, prev, pager, next, jumper"
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
</div>
  <!-- 购物车图标（固定右下角） -->
  <div class="cart-icon" @click="goToCart">
    <el-badge :value="cartItemCount" :max="99" :hidden="cartItemCount === 0">
      <el-icon class="cart-icon-svg"><ShoppingCart /></el-icon>
    </el-badge>
    <span class="cart-text">购物车</span>
  </div>
  </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { listApi as listClassificationList } from '/@/api/classification'
import { listApi as listTagList } from '/@/api/tag'
import { listApi as listThingList } from '/@/api/thing'
import { BASE_URL } from "/@/store/constants"
import { useUserStore, useCartStore } from "/@/store"
import { useRouter } from 'vue-router'
import { ElBadge, ElIcon } from 'element-plus'
import { ShoppingCart } from '@element-plus/icons-vue'
import banner1 from '/@/assets/images/1.png'
import banner2 from '/@/assets/images/2.png'
import banner3 from '/@/assets/images/3.png'

const userStore = useUserStore()
const router = useRouter()

const cartStore = useCartStore()
const cartItemCount = computed(() => cartStore.totalCount)

const goToCart = () => {
  // 后面的参数1表示进入购物车页面，但是是所有商品的
  router.push({ name: 'confirm', query: { cart: '1' } })
}

// 轮播图数据 - 联想电脑主题
const bannerList = ref([
  { 
    id: 1,
    // 请将 productId 替换为对应商品的 id（后端中已创建的商品）
    productId: 9,
    image: banner1,
    title: '联想拯救者 Y9000P 2025',
    description: '旗舰级游戏本，性能怪兽，畅玩大型游戏'
  },
  { 
    id: 2,
    productId: 8,
    image: banner2,
    title: '联想小新 Pro 16 2025',
    description: '高性能轻薄本，办公娱乐两不误'
  },
  { 
    id: 3,
    productId: 11,
    image: banner3,
    title: '联想 ThinkBook 14+ 2025',
    description: '商务办公首选，轻薄便携，高效生产力'
  }
])

// 商品分类数据
const categoryList = ref([])
const currentCategory = ref(-1)

// 标签数据
const tagList = ref([])
const currentTag = ref(-1)

// 排序方式
const currentSort = ref('recent')

// 商品列表
const productList = ref([])
const loading = ref(false)
const currentPage = ref(1)
const pageSize = ref(12)
const total = ref(0)

// 初始化分类数据
const initCategories = () => {
  listClassificationList().then(res => {
    categoryList.value = [{ id: -1, title: '全部' }, ...res.data]
    currentCategory.value = -1
  })
  
  listTagList().then(res => {
    tagList.value = [{ id: -1, title: '全部' }, ...res.data]
    currentTag.value = -1
  })
}

// 选择分类
const selectCategory = (id) => {
  currentCategory.value = id
  currentPage.value = 1
  getProductsList()
}

// 选择标签
const selectTag = (id) => {
  currentTag.value = id
  currentPage.value = 1
  getProductsList()
}

// 选择排序方式
const selectSort = (sort) => {
  currentSort.value = sort
  currentPage.value = 1
  getProductsList()
}

// 获取商品列表
const getProductsList = () => {
  loading.value = true
  
  const params = {
    category: currentCategory.value !== -1 ? currentCategory.value : undefined,
    tag: currentTag.value !== -1 ? currentTag.value : undefined,
    sort: currentSort.value,
    page: currentPage.value,
    page_size: pageSize.value
  }

  listThingList(params).then(res => {
    productList.value = res.data.map(item => {
      if (item.cover) {
        item.cover = BASE_URL + '/api/staticfiles/image/' + item.cover
      }
      return item
    })
    
    total.value = res.total
    loading.value = false
  }).catch(err => {
    console.error('获取商品失败:', err)
    loading.value = false
  })
}

// 分页变化
const handleSizeChange = (size) => {
  pageSize.value = size
  getProductsList()
}

const handleCurrentChange = (page) => {
  currentPage.value = page
  getProductsList()
}

// 商品详情
const handleDetail = (item) => {
  router.push({ name: 'detail', query: { id: item.id } })
}

// 查看商品详情
const viewProduct = (item) => {
  handleDetail(item)
}

// 跳转到商品列表
const goToProducts = () => {
  router.push({ name: 'products' })
}

// 轮播图项点击跳转到对应商品详情（使用 bannerList 中的 productId）
const goBannerProduct = (item) => {
  if (!item || !item.productId) return
  router.push({ name: 'detail', query: { id: item.productId } })
}

// 立即购买：跳转到确认/购买页，携带 productId 和 buyNow 标识
const goBuyNow = (item) => {
  if (!item || !item.productId) return
  router.push({ name: 'confirm', query: { productId: item.productId, buyNow: '1' } })
}

// 初始化
onMounted(() => {
  initCategories()
  getProductsList()
})
</script>

<style scoped lang="less">
:root {
  --primary-color: #409eff;
  --primary-color-light: rgba(64, 158, 255, 0.1);
  --secondary-color: #ff6b6b;
  --secondary-color-light: rgba(255, 107, 107, 0.1);
  --success-color: #67c23a;
  --warning-color: #e6a23c;
  --info-color: #909399;
  --text-primary: #1a1a1a;
  --text-secondary: #666;
  --border-color: #e8e8e8;
  --bg-light: #f8f9fa;
  --bg-card: #ffffff;
}

.home-page {
  width: 85%;
  max-width: 1400px;
  margin: 0 auto;
  padding: 100px 0 60px;
  background: linear-gradient(135deg, #f5f7fa 0%, #e4edf9 100%);
}

// Banner 区域
.banner-section {
  height: 420px;
  margin-bottom: 48px;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
  position: relative;
  
  .banner-img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.8s cubic-bezier(0.4, 0, 0.2, 1);
  }
  .banner-click-area {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 3;
    cursor: pointer;
    background: transparent;
  }
  
  .banner-overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 100%;
    background: linear-gradient(to top, rgba(0,0,0,0.7), transparent 60%);
  }
  
  .banner-text {
    position: absolute;
    bottom: 60px;
    left: 60px;
    color: white;
    z-index: 2;
    max-width: 500px;
    
    h2 {
      font-size: 32px;
      font-weight: 800;
      margin-bottom: 12px;
      color: white;
      text-shadow: 0 2px 10px rgba(0, 0, 0, 0.8);
      animation: slideInLeft 0.8s ease-out;
    }
    
    p {
      font-size: 18px;
      margin-bottom: 24px;
      color: white;
      text-shadow: 0 1px 6px rgba(0, 0, 0, 0.7);
      animation: slideInLeft 0.8s ease-out 0.2s both;
    }
    .buy-now {
      display: inline-block;
      margin-top: 6px;
      border-radius: 28px;
      padding: 10px 20px;
      font-weight: 700;
      box-shadow: 0 8px 20px rgba(255, 107, 107, 0.18);
    }
  }
  
  &:hover .banner-img {
    transform: scale(1.05);
  }
}

// 筛选区域
.filter-section {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 32px;
  margin-bottom: 48px;
  
  .filter-card {
    background: var(--bg-card);
    border-radius: 16px;
    padding: 28px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    border: 1px solid rgba(0, 0, 0, 0.05);
    
    &:hover {
      transform: translateY(-6px);
      box-shadow: 0 16px 48px rgba(0, 0, 0, 0.12);
    }
  }
  
  .filter-title {
    font-size: 18px;
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 24px;
    padding-bottom: 16px;
    border-bottom: 2px solid #f0f2f5;
    display: flex;
    align-items: center;
    gap: 8px;
    
    i {
      color: var(--primary-color);
      font-size: 20px;
    }
  }
  
  .filter-content {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
  }
  
  .filter-btn {
    padding: 10px 22px;
    border-radius: 24px;
    font-size: 14px;
    color: var(--text-secondary);
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    background: var(--bg-light);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    font-weight: 500;
    user-select: none;
    
    &.tag {
      border: 2px solid transparent;
      position: relative;
      overflow: hidden;
      
      // 未选中状态的渐变背景
      &:not(.active) {
        background: linear-gradient(135deg, #f8f9fa, #ffffff);
        border: 2px solid #e8e8e8;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
        
        &:hover {
          border-color: #d9d9d9;
          color: var(--primary-color);
          transform: translateY(-2px);
          box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
        }
      }
      
      // 选中状态 - 分类（蓝色主题）
      &.active.primary {
        background: linear-gradient(135deg, #409eff, #66b1ff);
        color: white;
        border-color: transparent;
        box-shadow: 0 4px 20px rgba(64, 158, 255, 0.4);
        
        &:hover {
          background: linear-gradient(135deg, #66b1ff, #409eff);
          transform: translateY(-2px);
          box-shadow: 0 6px 24px rgba(64, 158, 255, 0.5);
        }
        
        i {
          color: white;
        }
      }
      
      // 选中状态 - 标签（红色主题）
      &.active.secondary {
        background: linear-gradient(135deg, #ff6b6b, #ff8e8e);
        color: white;
        border-color: transparent;
        box-shadow: 0 4px 20px rgba(255, 107, 107, 0.4);
        
        &:hover {
          background: linear-gradient(135deg, #ff8e8e, #ff6b6b);
          transform: translateY(-2px);
          box-shadow: 0 6px 24px rgba(255, 107, 107, 0.5);
        }
        
        i {
          color: white;
        }
      }
      
      i {
        font-size: 12px;
        transition: all 0.3s ease;
      }
    }
  }
}

// 商品区域
.product-section {
  .product-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 32px;
    animation: fadeInUp 0.6s ease-out;
  }
  
  .section-title {
    font-size: 24px;
    font-weight: 700;
    color: var(--text-primary);
    display: flex;
    align-items: center;
    gap: 12px;
    
    i {
      color: var(--primary-color);
      font-size: 28px;
    }
    
    .product-count {
      font-size: 14px;
      font-weight: 500;
      color: var(--text-secondary);
      background: var(--bg-light);
      padding: 4px 12px;
      border-radius: 20px;
      margin-left: 12px;
    }
  }
  
  .sort-controls {
    display: flex;
    gap: 16px;
    background: var(--bg-light);
    padding: 8px;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  }
  
  .sort-btn {
    padding: 10px 20px;
    border-radius: 8px;
    font-size: 14px;
    color: var(--text-secondary);
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 6px;
    font-weight: 500;
    
    &.active {
      background: white;
      color: var(--primary-color);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      font-weight: 600;
      
      i {
        color: var(--primary-color);
      }
    }
    
    &:hover:not(.active) {
      color: var(--primary-color);
      background: rgba(var(--primary-color), 0.1);
    }
  }
  
  .skeleton-item {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
  }
}

// 商品网格
.product-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 24px;
  
  .product-card {
    background: white;
    border-radius: 16px;
    overflow: hidden;
    cursor: pointer;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
    position: relative;
    
    &::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
      opacity: 0;
      transition: opacity 0.3s ease;
      z-index: 1;
    }
    
    &:hover {
      transform: translateY(-10px);
      box-shadow: 0 20px 56px rgba(0, 0, 0, 0.18);
      
      &::before {
        opacity: 1;
      }
      
      .product-image img {
        transform: scale(1.1);
      }
      
      .image-overlay {
        opacity: 1;
      }
    }
  }
  
  .product-image {
    position: relative;
    height: 300px;
    overflow: hidden;
    
    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .image-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
  }
  
  .product-info {
    padding: 24px;
  }
  
  .product-title {
    font-size: 16px;
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 12px;
    line-height: 1.5;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    overflow: hidden;
    transition: color 0.3s ease;
    
    .product-card:hover & {
      color: var(--primary-color);
    }
  }
  
  .product-price {
    display: flex;
    align-items: baseline;
    gap: 4px;
    margin-bottom: 16px;
  }
  
  .price-symbol {
    font-size: 16px;
    color: var(--secondary-color);
    font-weight: 600;
  }
  
  .price-value {
    font-size: 24px;
    color: var(--secondary-color);
    font-weight: 700;
  }
  
  .product-tags {
    display: flex;
    gap: 8px;
  }
  
  .product-tag {
    padding: 6px 14px;
    background: var(--primary-color-light);
    color: var(--primary-color);
    border-radius: 12px;
    font-size: 12px;
    font-weight: 500;
    
    &.new {
      background: rgba(255, 107, 107, 0.1);
      color: var(--secondary-color);
    }
  }
}

// 空状态
.empty-state {
  grid-column: 1 / -1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 80px 20px;
  text-align: center;
  animation: fadeIn 0.8s ease-out;
  
  .empty-icon {
    width: 100px;
    height: 100px;
    background: var(--bg-light);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 24px;
    transition: transform 0.3s ease;
    
    &:hover {
      transform: scale(1.1);
    }
    
    i {
      font-size: 40px;
      color: #adb5bd;
    }
  }
  
  .empty-text {
    font-size: 20px;
    font-weight: 600;
    color: #495057;
    margin-bottom: 8px;
  }
  
  .empty-subtext {
    font-size: 14px;
    color: #868e96;
  }
}

// 分页
.pagination-container {
  margin-top: 60px;
  display: flex;
  justify-content: center;
  
  :deep(.el-pagination) {
    .btn-prev,
    .btn-next,
    .el-pager li {
      border-radius: 8px;
      transition: all 0.3s ease;
    }
    
    .el-pager li:not(.is-disabled):hover {
      color: var(--primary-color);
    }
    
    .el-pager li.is-active {
      background-color: var(--primary-color);
    }
  }
}

// 动画效果
@keyframes slideInLeft {
  from {
    opacity: 0;
    transform: translateX(-30px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

// 响应式设计
@media (max-width: 1200px) {
  .home-page {
    width: 90%;
    padding: 90px 0 40px;
  }
  
  .filter-section {
    gap: 24px;
  }
}

@media (max-width: 992px) {
  .filter-section {
    grid-template-columns: 1fr;
  }
  
  .product-grid {
    grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
    gap: 20px;
  }
}

@media (max-width: 768px) {
  .home-page {
    width: 94%;
    padding: 80px 0 30px;
  }
  
  .banner-section {
    height: 320px;
    border-radius: 12px;
    margin-bottom: 32px;
  }
  
  .banner-text {
    left: 20px;
    bottom: 40px;
    max-width: 400px;
    
    h2 {
      font-size: 24px;
    }
    
    p {
      font-size: 16px;
    }
  }
  
  .filter-card {
    padding: 20px;
  }
  
  .product-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 16px;
  }
  
  .sort-controls {
    width: 100%;
    justify-content: center;
  }
  
  .product-grid {
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 16px;
  }
  
  .product-image {
    height: 240px;
  }
  
  .filter-btn.tag {
    padding: 8px 16px;
    font-size: 13px;
  }
}

@media (max-width: 480px) {
  .home-page {
    padding: 70px 0 20px;
  }
  
  .banner-section {
    height: 240px;
    border-radius: 8px;
  }
  
  .banner-text {
    left: 15px;
    bottom: 20px;
    max-width: 300px;
    
    h2 {
      font-size: 20px;
      margin-bottom: 8px;
    }
    
    p {
      font-size: 14px;
      margin-bottom: 16px;
    }
  }
  
  .filter-card {
    padding: 16px;
  }
  
  .product-grid {
    grid-template-columns: 1fr;
  }
  
  .product-image {
    height: 280px;
  }
  
  .product-info {
    padding: 16px;
  }
  
  .filter-btn.tag {
    padding: 6px 12px;
    font-size: 12px;
  }
}

/* 右下角购物车图标样式 */
.cart-icon {
  position: fixed;
  top: 50%;
  right: 20px;
  transform: translateY(-50%);
  width: 70px;
  height: 70px;
  background: linear-gradient(135deg, #4684e2, #0066b2);
  border-radius: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: white;
  box-shadow: 0 8px 20px rgba(70, 132, 226, 0.4);
  transition: all 0.3s;
  z-index: 1000;
}

.cart-icon:hover {
  transform: translateY(-6px) scale(1.05);
  box-shadow: 0 12px 24px rgba(70,132,226,0.5);
}

.cart-icon-svg {
  font-size: 28px;
  margin-bottom: 2px;
}

.cart-text {
  font-size: 12px;
  font-weight: 500;
}
</style>




<template>
  <el-footer class="footer-view">
    <div class="footer-container">
      <nav class="footer-nav">
        <a href="/#/index/system-doc" class="footer-link">
          <i class="el-icon-document"></i> 系统文档
        </a>
        <a href="/#/admin" class="footer-link" target="_blank">
          <i class="el-icon-monitor"></i> 后台管理
        </a>
        <a href="/#/index/about" class="footer-link">
          <i class="el-icon-info"></i> 关于我们
        </a>
      </nav>

      <div class="footer-meta">
        <div class="meta-section copyright">
          <i class="el-icon-copyright"></i>
          <span>2022–2025 代码演示平台</span>
          <span class="divider">|</span>
          <span>All Rights Reserved</span>
        </div>

        <div class="meta-section legal">
          <span>
            <i class="el-icon-document-checked"></i>
            备案号：备12345678号
          </span>
          <span class="divider">|</span>
          <span>
            <i class="el-icon-tickets"></i>
            统一社会信用代码：123456789
          </span>
        </div>

        <div class="footer-credit">
          <div class="heart-beat">
            <i class="el-icon-heart"></i>
          </div>
          <span>Made with passion for better experience</span>
          <el-link type="info" :underline="false" href="https://beian.miit.gov.cn" target="_blank">
            公安备案
          </el-link>
        </div>
      </div>
    </div>
  </el-footer>
</template>
<script setup>
// 无逻辑，仅展示
</script>

<style scoped lang="less">
.footer-view {
  backdrop-filter: blur(10px);
  border-top: 1px solid rgba(230, 236, 242, 0.8);
  padding: 0;
  position: relative;
  flex-shrink: 0; /* 如果外层是 flex 布局 */
   min-height: fit-content; /* 确保至少包裹内容 */
   background-color: #fdf9ea; /* 👈 浅黄色背景 */
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 1px;
    background: linear-gradient(
      90deg,
      transparent,
      var(--primary-color-light),
      transparent
    );
  }
}

.footer-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px 20px 30px;
  text-align: center; /* 👈 全局文字居中 */
}

/* ============ 导航链接 ============ */
.footer-nav {
  display: flex;
  justify-content: center;
  gap: 60px; /* 👈 间隔加大：原来是 40px，现在 60px */
  flex-wrap: wrap;
  margin-bottom: 16px;
}

.footer-link {
  display: flex;
  align-items: center;
  gap: 10px;
  color: #5d6d7e;
  text-decoration: none;
  font-size: 15px;
  padding: 10px 16px;
  border-radius: 8px;
  transition: all 0.3s ease;
  position: relative;

  i {
    font-size: 18px;
    color: var(--primary-color-light);
    width: 20px;
    text-align: center;
    transition: all 0.3s ease;
  }

  &::before {
    content: '';
    position: absolute;
    left: -10px;
    top: 50%;
    transform: translateY(-50%);
    width: 4px;
    height: 0;
    background: var(--primary-color);
    border-radius: 2px;
    transition: height 0.3s ease;
  }

  &:hover {
    color: var(--primary-color);
    background: rgba(var(--primary-color-rgb), 0.05);
    padding-left: 20px;

    i {
      color: var(--primary-color);
      transform: scale(1.15);
    }

    &::before {
      height: 20px;
    }
  }
}

/* ============ 底部元信息 ============ */
.footer-meta {
  display: inline-block; /* 让宽度由内容决定，便于居中 */
  text-align: center;
}

.meta-section {
  display: inline-flex;
  align-items: center;
  gap: 16px;
  color: #7f8c8d;
  font-size: 14px;
  flex-wrap: wrap;
  justify-content: center;
  margin: 0px 0;

  span {
    display: flex;
    align-items: center;
    gap: 6px;
  }

  i {
    font-size: 16px;
    color: var(--primary-color-light);
  }

  .divider {
    color: #ddd;
  }
}

.footer-credit {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  color: #95a5a6;
  font-size: 15px;
  margin-top: 10px;
  padding-top: 12px;
  border-top: 1px solid rgba(230, 236, 242, 0.6);

  .heart-beat {
    width: 26px;
    height: 26px;
    display: flex;
    align-items: center;
    justify-content: center;
    animation: heartbeat 1.5s ease-in-out infinite;

    i {
      color: #e74c3c;
      font-size: 18px;
    }
  }

  .el-link {
    font-size: 14px;
  }
}

@keyframes heartbeat {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.15); }
}

/* ============ 响应式 ============ */
@media (max-width: 768px) {
  .footer-container {
    padding: 36px 18px 28px;
  }

  .footer-nav {
    gap: 24px; /* 小屏适当缩小间距 */
    margin-bottom: 28px;
  }

  .footer-link {
    flex-direction: column;
    gap: 6px;
    padding: 12px 10px;
    font-size: 14px;

    &:hover {
      padding-left: 10px; /* 避免偏移 */
    }
  }

  .meta-section {
    flex-direction: column;
    gap: 8px !important;

    .divider {
      display: none;
    }
  }

  .footer-credit {
    flex-direction: column;
    gap: 8px;
  }
}

@media (max-width: 480px) {
  .footer-nav {
    gap: 18px;
  }

  .footer-link {
    font-size: 14px;
  }

  .meta-section,
  .footer-credit {
    font-size: 13px;
  }
}
</style>
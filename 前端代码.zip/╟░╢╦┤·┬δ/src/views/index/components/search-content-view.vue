<template>
  <div class="content-margin">
    <!-- 搜索标题区域增强 -->
    <div class="search-header">
      <div class="search-title-wrapper">
        <span class="search-prefix">搜索到</span>
        <div class="search-keyword animated-gradient">
          <span class="keyword-text">{{ tData.keyword }}</span>
          <span class="keyword-highlight"></span>
        </div>
        <span class="search-suffix">相关的内容</span>
      </div>
      <div class="search-count">
        <span class="count-number">{{ tData.total }}</span>
        <span class="count-text">个结果</span>
      </div>
    </div>

    <div class="search-tab-nav animated-fade-in">
      <div class="search-tabs">
        <span class="tab-item active">商品</span>
      </div>
    </div>

    <!-- 商品列表增强 -->
    <div class="thing-list animated-fade-in">
      <el-skeleton :loading="tData.loading" animated :count="12">
        <template #template>
          <div class="skeleton-items">
            <div v-for="i in 12" :key="i" class="skeleton-item">
              <el-skeleton-item variant="image" style="width: 255px; height: 200px;" />
              <div style="padding: 12px;">
                <el-skeleton-item variant="text" style="width: 80%" />
                <el-skeleton-item variant="text" style="width: 60%; margin-top: 8px;" />
              </div>
            </div>
          </div>
        </template>
        
        <div class="things">
          <div 
            class="thing-item" 
            v-for="(item, index) in tData.pageData" 
            :key="item.id" 
            @click="handleDetail(item)"
            :style="{ 'animation-delay': `${index * 0.05}s` }"
          >
            <!-- 商品图片容器 -->
            <div class="img-view">
              <img :src="item.cover" :alt="item.title" loading="lazy">
              <div class="item-overlay">
                <div class="overlay-content">
                  <el-button class="quick-view-btn" type="primary" size="small" round>
                    快速预览
                  </el-button>
                </div>
              </div>
              <!-- 浮动标签 -->
              <div v-if="index % 4 === 0" class="item-tag hot">
                HOT
              </div>
              <div v-else-if="index % 5 === 0" class="item-tag new">
                NEW
              </div>
            </div>
            
            <!-- 商品信息 -->
            <div class="info-view">
              <h3 class="item-title" :title="item.title">
                {{ item.title.length > 12 ? item.title.substring(0, 12) + '...' : item.title }}
              </h3>
              <div class="item-price">
                <span class="price-symbol">¥</span>
                <span class="price-number">{{ item.price }}</span>
                <span class="price-original" v-if="Math.random() > 0.5">
                  ¥{{ Math.floor(item.price * 1.2) }}
                </span>
              </div>
              <div class="item-actions">
                <el-button class="add-cart-btn" size="small" round @click.stop="addToCart(item, $event)">
                  <el-icon><ShoppingCart /></el-icon>
                  加入购物车
                </el-button>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 分页增强 -->
        <div class="page-view">
          <div class="pagination-wrapper">
            <el-pagination
              v-model:current-page="tData.page"
              :page-size="tData.pageSize"
              :total="tData.total"
              :pager-count="7"
              layout="prev, pager, next, jumper, ->, total"
              background
              @current-change="changePage"
              class="animated-pagination"
            />
          </div>
          
          <!-- 回到顶部 -->
          <div v-show="tData.page > 2" class="back-to-top" @click="scrollToTop">
            <el-icon><Top /></el-icon>
          </div>
        </div>
      </el-skeleton>
      
      <!-- 空状态 -->
      <div v-if="!tData.loading && tData.total === 0" class="empty-state">
        <div class="empty-illustration">
          <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 150'%3E%3Cpath fill='%23f0f7ff' d='M100 25a75 75 0 100 150 75 75 0 000-150z'/%3E%3Cpath fill='%234684e2' d='M100 35a65 65 0 100 130 65 65 0 000-130z'/%3E%3Cpath fill='white' d='M80 65h40v40H80z'/%3E%3Cpath fill='%234684e2' d='M85 70h30v30H85z'/%3E%3Ccircle cx='100' cy='100' r='5' fill='white'/%3E%3C/svg%3E" alt="暂无结果">
        </div>
        <h3 class="empty-title">未找到相关商品</h3>
        <p class="empty-desc">换个关键词试试吧~</p>
        <div class="empty-actions">
          <el-button type="primary" @click="$router.push({ name: 'portal' })">
            返回首页
          </el-button>
          <el-button @click="search">重新搜索</el-button>
        </div>
      </div>
    </div>
    
    <!-- 购物车图标 -->
    <div class="cart-icon" @click="goToCart">
      <el-badge :value="cartItemCount" :max="99" :hidden="cartItemCount === 0">
        <el-icon class="cart-icon-svg"><ShoppingCart /></el-icon>
      </el-badge>
      <span class="cart-text">购物车</span>
    </div>
  </div>
</template>

<script setup>
import { reactive, onMounted, watch, computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElSkeleton, ElPagination, ElButton, ElIcon, ElBadge, ElMessage } from 'element-plus'
import { Star, ShoppingCart, Top } from '@element-plus/icons-vue'
import { listApi as listThingList } from '/@/api/thing'
import { BASE_URL } from "/@/store/constants"
import { useCartStore } from '/@/store'

const router = useRouter()
const route = useRoute()

const tData = reactive({
  loading: false,
  keyword: '',
  thingData: [],
  pageData: [],
  page: 1,
  total: 0,
  pageSize: 20,
})

const cartStore = useCartStore()
// 计算购物车商品数量
const cartItemCount = computed(() => cartStore.totalCount)
const cartItems = computed(() => cartStore.cartItems)

onMounted(() => {
  search()
  addScrollEffects()
})

watch(() => route.query, () => search(), { immediate: false })

// 购物车由 Pinia 管理并持久化，无需在组件中手动读写 localStorage

// 添加滚动效果
const addScrollEffects = () => {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-in')
      }
    })
  }, { threshold: 0.1 })

  document.querySelectorAll('.thing-item').forEach(item => {
    observer.observe(item)
  })
}

const search = () => {
  tData.keyword = route.query.keyword?.trim() || ''
  getThingList({ keyword: tData.keyword })
  scrollToTop()
}

const changePage = (page) => {
  tData.page = page
  const start = (page - 1) * tData.pageSize
  tData.pageData = tData.thingData.slice(start, start + tData.pageSize)
  
  // 平滑滚动到顶部
  setTimeout(() => {
    scrollToTop()
  }, 100)
}

const scrollToTop = () => {
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

const handleDetail = (item) => {
  const url = router.resolve({ name: 'detail', query: { id: item.id } })
  window.open(url.href, '_blank')
}

const addToCart = (item, e) => {
  // 使用统一的 cart store，避免未定义引用
  cartStore.addItem({ id: item.id, title: item.title, price: item.price, cover: item.cover, quantity: 1 })

  // 模拟加入购物车动画
  const button = e?.target?.closest?.('.add-cart-btn')
  if (button) {
    button.classList.add('animate-bounce')
    setTimeout(() => button.classList.remove('animate-bounce'), 300)
  }

  ElMessage.success(`已加入购物车，当前购物车共有 ${cartItemCount.value} 件商品`)
}

const goToCart = () => {
  // 跳转到结算页并使用 cart=1 标识展示购物车内容
  router.push({ name: 'confirm', query: { cart: '1' } })
}

const getThingList = (data) => {
  tData.loading = true
  listThingList(data).then(res => {
    tData.thingData = res.data.map(item => ({
      ...item,
      cover: item.cover ? `${BASE_URL}/api/staticfiles/image/${item.cover}` : ''
    }))
    tData.total = tData.thingData.length
    changePage(1)
    
    // 延迟加载动画
    setTimeout(() => {
      tData.loading = false
      addScrollEffects()
    }, 500)
  }).catch(err => {
    console.error(err)
    tData.loading = false
  })
}
</script>

<style scoped lang="less">
.content-margin {
  margin: 56px 0 100px;
  animation: fadeIn 0.6s ease-out;
}

// 搜索头部样式
.search-header {
  background: linear-gradient(135deg, #f0f7ff 0%, #e6f0ff 100%);
  padding: 40px 0;
  text-align: center;
  margin-bottom: 40px;
  border-radius: 12px;
  position: relative;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #4684e2, #0066b2);
  }

  .search-title-wrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    margin-bottom: 16px;

    .search-prefix,
    .search-suffix {
      font-size: 18px;
      color: #666;
      animation: fadeInUp 0.5s ease-out;
    }

    .search-keyword {
      position: relative;
      display: inline-block;
      padding: 12px 32px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(70, 132, 226, 0.15);
      animation: slideInUp 0.6s ease-out;

      .keyword-text {
        font-size: 28px;
        font-weight: bold;
        color: #4684e2;
        position: relative;
        z-index: 2;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      }

      .keyword-highlight {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 4px;
        background: linear-gradient(90deg, #4684e2, #0095d9);
        border-radius: 2px;
        animation: highlightSlide 2s ease-in-out infinite;
      }
    }
  }

  .search-count {
    animation: fadeInUp 0.7s ease-out;
    
    .count-number {
      font-size: 36px;
      font-weight: bold;
      color: #4684e2;
      margin-right: 8px;
      text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .count-text {
      font-size: 18px;
      color: #666;
    }
  }
}

.search-tab-nav {
  margin-bottom: 40px;

  .search-tabs {
    display: flex;
    justify-content: center;
    gap: 24px;

    .tab-item {
      padding: 10px 32px;
      border-radius: 30px;
      cursor: pointer;
      transition: all 0.3s;
      background: #f5f9ff;
      color: #666;
      border: 1px solid #e6f0ff;
      font-weight: 500;
      position: relative;
      overflow: hidden;

      &.active {
        background: linear-gradient(135deg, #4684e2, #0066b2);
        color: white;
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(70, 132, 226, 0.3);
        z-index: 1;
        
        &::after {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
          transition: 0.5s;
        }
        
        &:hover::after {
          left: 100%;
        }
      }

      &:hover:not(.active) {
        background: #e6f0ff;
        color: #4684e2;
        transform: translateY(-2px);
      }
    }
  }
}

// 骨架屏样式
.skeleton-items {
  display: flex;
  flex-wrap: wrap;
  gap: 24px;
  justify-content: center;

  .skeleton-item {
    width: 255px;
    border-radius: 12px;
    overflow: hidden;
    background: white;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    animation: fadeIn 0.5s ease-out;
  }
}

.things {
  display: flex;
  flex-wrap: wrap;
  gap: 24px;
  justify-content: center;
  padding: 0 10px;
}

.thing-item {
  width: 255px;
  background: white;
  border-radius: 16px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
  opacity: 0;
  transform: translateY(20px);
  animation: itemSlideIn 0.6s ease-out forwards;
  position: relative;
  z-index: 1;

  &.animate-in {
    animation: itemSlideIn 0.6s ease-out forwards;
  }

  &:hover {
    transform: translateY(-10px) scale(1.03);
    box-shadow: 0 16px 32px rgba(70, 132, 226, 0.18);
    z-index: 10;
  }

  .img-view {
    height: 200px;
    position: relative;
    overflow: hidden;
    transition: all 0.4s ease;

    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.6s ease;
    }

    &:hover img {
      transform: scale(1.15);
    }

    .item-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 102, 178, 0.85);
      opacity: 0;
      transition: opacity 0.4s ease;
      display: flex;
      align-items: center;
      justify-content: center;

      .overlay-content {
        transform: translateY(30px);
        transition: transform 0.4s ease;
      }

      .quick-view-btn {
        opacity: 0;
        animation: fadeInUp 0.4s ease-out 0.2s forwards;
        background: linear-gradient(135deg, #4684e2, #0066b2);
        border: none;
      }
    }

    &:hover .item-overlay {
      opacity: 1;

      .overlay-content {
        transform: translateY(0);
      }
    }

    .item-tag {
      position: absolute;
      top: 12px;
      right: 12px;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: bold;
      color: white;
      z-index: 2;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      text-transform: uppercase;
      letter-spacing: 0.5px;

      &.hot {
        background: linear-gradient(45deg, #ff6b6b, #ff8e53);
      }

      &.new {
        background: linear-gradient(45deg, #36d1dc, #5b86e5);
      }
    }
  }

  .info-view {
    padding: 20px;

    .item-title {
      margin: 0 0 12px 0;
      font-size: 16px;
      line-height: 1.5;
      color: #152844;
      height: 45px;
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-box-orient: vertical;
      font-weight: 500;
    }

      .item-meta {
      display: flex;
      align-items: center;
      margin-bottom: 14px;
      color: #666;
      font-size: 13px;

      .rating {
        display: flex;
        align-items: center;
        gap: 4px;

        .el-icon {
          color: #ffd700;
        }
      }
    }

    .item-price {
      margin-bottom: 16px;

      .price-symbol {
        font-size: 15px;
        color: #ff6b6b;
      }

      .price-number {
        font-size: 24px;
        font-weight: bold;
        color: #ff6b6b;
        margin: 0 4px;
      }

      .price-original {
        font-size: 14px;
        color: #999;
        text-decoration: line-through;
        margin-left: 8px;
      }
    }

    .item-actions {
      .add-cart-btn {
        width: 100%;
        background: linear-gradient(135deg, #4684e2, #0066b2);
        border: none;
        color: white;
        transition: all 0.3s;
        font-weight: 500;
        padding: 10px 0;

        &:hover {
          background: linear-gradient(135deg, #0066b2, #0095d9);
          transform: translateY(-3px);
          box-shadow: 0 8px 20px rgba(70, 132, 226, 0.4);
        }

        &.animate-bounce {
          animation: bounce 0.3s ease;
        }

        .el-icon {
          margin-right: 6px;
        }
      }
    }
  }
}

.page-view {
  margin-top: 48px;
  position: relative;

  .pagination-wrapper {
    display: flex;
    justify-content: center;

    .animated-pagination {
      transition: all 0.3s;

      :deep(.el-pager li) {
        transition: all 0.3s;
        border-radius: 8px;
        margin: 0 4px;

        &:hover {
          transform: scale(1.1);
          background: #e6f0ff;
        }
        
        &.active {
          background: linear-gradient(135deg, #4684e2, #0066b2);
          color: white;
        }
      }
    }
  }

  .back-to-top {
    position: fixed;
    bottom: 40px;
    right: 40px;
    width: 56px;
    height: 56px;
    background: linear-gradient(135deg, #4684e2, #0066b2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    color: white;
    box-shadow: 0 8px 20px rgba(70, 132, 226, 0.4);
    transition: all 0.3s;
    z-index: 100;
    animation: float 3s ease-in-out infinite;

    &:hover {
      transform: translateY(-6px) scale(1.1);
      box-shadow: 0 12px 24px rgba(70, 132, 226, 0.5);
    }

    .el-icon {
      font-size: 24px;
    }
  }
}

// 空状态样式
.empty-state {
  text-align: center;
  padding: 80px 20px;

  .empty-illustration {
    width: 220px;
    height: 160px;
    margin: 0 auto 24px;
    animation: float 3s ease-in-out infinite;

    img {
      width: 100%;
      height: 100%;
      object-fit: contain;
    }
  }

  .empty-title {
    font-size: 28px;
    color: #152844;
    margin-bottom: 12px;
    font-weight: 600;
  }

  .empty-desc {
    color: #666;
    margin-bottom: 24px;
    font-size: 16px;
  }

  .empty-actions {
    display: flex;
    gap: 16px;
    justify-content: center;
    
    .el-button {
      padding: 12px 24px;
      border-radius: 8px;
      font-weight: 500;
    }
  }
}


// 购物车图标样式
.cart-icon {
  position: fixed;
  top: 50%;
  right: 20px;
  transform: translateY(-50%);
  width: 70px;
  height: 70px;
  background: linear-gradient(135deg, #4684e2, #0066b2);
  border-radius: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: white;
  box-shadow: 0 8px 20px rgba(70, 132, 226, 0.4);
  transition: all 0.3s;
  z-index: 1000;
  animation: float 3s ease-in-out infinite;

  &:hover {
    transform: translateY(-6px) scale(1.1);
    box-shadow: 0 12px 24px rgba(70, 132, 226, 0.5);
  }

  .cart-icon-svg {
    font-size: 28px;
    margin-bottom: 2px;
  }

  .cart-text {
    font-size: 12px;
    font-weight: 500;
  }
}

// 购物车徽章样式
:deep(.el-badge__content) {
  background: #ff4d4f;
  border: none;
  font-size: 12px;
  height: 20px;
  width: 20px;
  line-height: 20px;
  border-radius: 10px;
  top: -10px;
  right: -10px;
}

// 动画关键帧
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes slideInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes itemSlideIn {
  from {
    opacity: 0;
    transform: translateY(30px) scale(0.95);
  }
  to {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
}

@keyframes highlightSlide {
  0%, 100% { transform: translateX(0); }
  50% { transform: translateX(15px); }
}

@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-12px); }
}

@keyframes float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-15px); }
}

// 响应式调整
@media (max-width: 1200px) {
  .things {
    justify-content: center;
  }
  
  .search-header {
    .search-title-wrapper {
      flex-direction: column;
      gap: 12px;
      
      .search-keyword {
        padding: 10px 24px;
      }
    }
  }
}

@media (max-width: 768px) {
  .search-header {
    padding: 30px 0;
    margin-bottom: 30px;

    .search-title-wrapper {
      flex-direction: column;
      gap: 10px;

      .search-keyword {
        padding: 8px 20px;
      }
    }
    
    .search-count {
      .count-number {
        font-size: 32px;
      }
      
      .count-text {
        font-size: 16px;
      }
    }
  }

  .things {
    justify-content: center;
  }

  .thing-item {
    width: calc(50% - 12px);
  }
  
  .page-view .back-to-top {
    width: 50px;
    height: 50px;
    bottom: 30px;
    right: 30px;
  }
  
  .cart-icon {
    width: 60px;
    height: 60px;
    bottom: 15px;
    right: 15px;
    
    .cart-icon-svg {
      font-size: 24px;
    }
    
    .cart-text {
      font-size: 10px;
    }
  }
}

@media (max-width: 480px) {
  .thing-item {
    width: 100%;
    margin: 0 8px 24px;
  }
  
  .search-header {
    .search-title-wrapper {
      .search-keyword {
        padding: 8px 16px;
        width: 100%;
      }
    }
  }
  
  .page-view .back-to-top {
    bottom: 20px;
    right: 20px;
  }
  
  .empty-state {
    padding: 60px 15px;
  }
  
  .cart-icon {
    width: 55px;
    height: 55px;
    bottom: 10px;
    right: 10px;
  }
}
</style>
<template>
  <el-header class="main-bar-view">
    <!-- Logo 区域 -->
    <div class="logo" @click="$router.push({ name: 'portal' })">
      <img :src="logoImage" class="logo-img" alt="Logo" />
    </div>

    <!-- 搜索框 -->
    <div class="search-entry">
      <img :src="SearchIcon" class="search-icon" alt="搜索" />
      <input
        ref="keywordRef"
        v-model="keyword"
        placeholder="输入关键词"
        @keyup.enter="search"
        class="search-input"
        @focus="isFocused = true"
        @blur="isFocused = false"
      />
    </div>

    <!-- 右侧操作区 -->
    <div class="right-view">
      <!-- 已登录状态 -->
      <template v-if="userStore.user_token">
        <el-dropdown @command="handleUserCommand" trigger="click">
          <span class="el-dropdown-link user-avatar-wrapper">
            <img :src="avatarSrc" class="user-avatar" alt="头像" />
          </span>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="orderView">订单中心</el-dropdown-item>
              <el-dropdown-item command="userInfoEditView">个人设置</el-dropdown-item>
              <el-dropdown-item command="quit" divided>退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </template>
      <!-- 未登录状态 -->
      <template v-else>
        <el-button class="login-btn" @click="goLogin()" type="primary" round>
          登录
        </el-button>
      </template>

      <!-- 消息通知 -->
      <div 
        class="message-icon" 
        @click="openMessageDrawer"
        :class="{ 'pulse': hasUnread }"
      >
        <img :src="MessageIcon" alt="消息" />
        <span v-if="hasUnread" class="msg-badge"></span>
      </div>
    </div>

    <!-- 消息抽屉 -->
    <a-drawer
      title="我的消息"
      placement="right"
      :closable="true"
      :maskClosable="true"
      :visible="msgVisible"
      @close="onClose"
      width="400px"
    >
      <el-skeleton :loading="loading" animated :rows="8">
        <div class="notification-list">
          <div
            v-for="(item, index) in msgData"
            :key="item.id"
            class="notification-item animated-fade-in"
            :style="{ 'animation-delay': `${index * 0.05}s` }"
          >
            <div class="notification-content">
              <div class="notification-header">
                <span class="notification-title">{{ item.title }}</span>
                <span class="notification-time">{{ formatTime(item.create_time) }}</span>
              </div>
              <p class="notification-desc">{{ item.content }}</p>
            </div>
          </div>
          <div v-if="msgData.length === 0" class="empty-message">
            <div class="empty-icon">✉️</div>
            <p>暂无消息</p>
          </div>
        </div>
      </el-skeleton>
    </a-drawer>
  </el-header>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '/@/store'
import logoImage from '/@/assets/images/ouc.png'
import SearchIcon from '/@/assets/images/search-icon.svg'
import AvatarIcon from '/@/assets/images/avatar.jpg'
import MessageIcon from '/@/assets/images/message-icon.svg'
import { listApi as fetchNotices } from '/@/api/notice'

const router = useRouter()
const userStore = useUserStore()

const avatarSrc = computed(() => userStore.user_avatar || AvatarIcon)

// 搜索相关
const keyword = ref('')
const keywordRef = ref<HTMLInputElement | null>(null)
const isFocused = ref(false)

// 消息相关
const msgVisible = ref(false)
const loading = ref(false)
const msgData = ref<any[]>([])
const hasUnread = computed(() => msgData.value.length > 0)

// 初始化
onMounted(() => {
  getMessageList()
})

// 获取消息列表
const getMessageList = () => {
  loading.value = true
  fetchNotices({})
    .then((res) => {
      msgData.value = res.data || []
    })
    .catch(console.error)
    .finally(() => {
      loading.value = false
    })
}

// 格式化时间（简化）
const formatTime = (timeStr: string) => {
  return timeStr?.split('T')[0] || timeStr
}

// 搜索
const search = () => {
  if (!keyword.value.trim()) return
  const target = router.resolve({
    name: 'search',
    query: { keyword: keyword.value.trim() }
  })
  window.open(target.href, '_blank')
}

// 跳转登录
const goLogin = () => {
  router.push({ name: 'login' })
}

// 用户操作
const handleUserCommand = (command: string) => {
  if (command === 'quit') {
    userStore.logout().then(() => {
      router.push({ name: 'portal' })
    })
  } else {
    router.push({ name: command })
  }
}

// 打开/关闭消息抽屉
const openMessageDrawer = () => {
  msgVisible.value = true
}
const onClose = () => {
  msgVisible.value = false
}
</script>

<style scoped lang="less">
.main-bar-view {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 60px;
  background: linear-gradient(135deg, rgba(255,255,255,0.95), rgba(248,250,252,0.95));
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(224, 230, 237, 0.5);
  display: flex;
  align-items: center;
  padding: 0 5%;
  z-index: 1000;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

  &:hover {
    box-shadow: 0 6px 25px rgba(0, 0, 0, 0.12);
    background: linear-gradient(135deg, rgba(255,255,255,0.98), rgba(248,250,252,0.98));
  }
}

.logo {
  margin-right: 32px;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  transform: translateZ(0);
  border-radius: 50%;
  overflow: hidden;
  
  &:hover {
    transform: scale(1.1) rotate(5deg) translateZ(0);
    box-shadow: 0 8px 20px rgba(70, 132, 226, 0.2);
  }
  
  &:active {
    transform: scale(0.95) rotate(0deg) translateZ(0);
  }
  
  .logo-img {
    width: 36px;
    height: 36px;
    transition: all 0.3s ease;
    border-radius: 8px;
  }
}

.search-entry {
  position: relative;
  width: 420px;
  min-width: 220px;
  height: 40px;
  background: linear-gradient(135deg, #f8fbff, #ffffff);
  border-radius: 20px;
  padding: 0 16px;
  display: flex;
  align-items: center;
  box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.06);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  border: 1px solid rgba(224, 230, 237, 0.3);

  &:hover {
    box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.08);
    transform: translateY(-1px);
  }

  &:focus-within {
    box-shadow: 0 0 0 2px rgba(70, 132, 226, 0.3), inset 0 2px 8px rgba(0, 0, 0, 0.06);
    transform: translateY(-2px);
    background: linear-gradient(135deg, #ffffff, #f8fbff);
  }

  .search-icon {
    width: 18px;
    margin-right: 10px;
    opacity: 0.7;
    transition: all 0.3s ease;
  }

  .search-input {
    flex: 1;
    height: 100%;
    border: none;
    outline: none;
    background: transparent;
    font-size: 14px;
    color: #333;
    transition: all 0.3s ease;
    
    &::placeholder {
      color: #aaa;
      transition: all 0.3s ease;
    }
    
    &:focus {
      &::placeholder {
        color: #999;
      }
    }
  }
}

.right-view {
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: 24px;

  .login-btn {
    background: linear-gradient(135deg, #4684e2, #0066b2);
    border: none;
    font-size: 14px;
    padding: 0 24px;
    height: 36px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 0 4px 12px rgba(70, 132, 226, 0.3);
    
    &:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(70, 132, 226, 0.4);
    }
    
    &:active {
      transform: translateY(0);
    }
  }

  .user-avatar-wrapper {
    display: block;
    cursor: pointer;
    transition: all 0.3s ease;
    
    &:hover {
      transform: scale(1.1);
    }
  }

  .user-avatar {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #e6f0ff;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    
    &:hover {
      transform: scale(1.1) rotate(5deg);
      box-shadow: 0 6px 16px rgba(70, 132, 226, 0.3);
    }
  }

  .message-icon {
    position: relative;
    width: 28px;
    cursor: pointer;
    transition: all 0.3s ease;
    border-radius: 50%;
    padding: 4px;
    
    &:hover {
      background: rgba(70, 132, 226, 0.1);
      transform: scale(1.1);
    }
    
    &.pulse {
      animation: pulse 2s infinite;
    }
    
    img {
      width: 100%;
      transition: all 0.3s ease;
    }
    
    .msg-badge {
      position: absolute;
      top: -4px;
      right: -4px;
      width: 10px;
      height: 10px;
      background: #ff6b6b;
      border: 2px solid white;
      border-radius: 50%;
      animation: bounce 1.5s infinite;
    }
  }
}

.notification-list {
  padding: 12px 0;
  max-height: calc(100vh - 120px);
  overflow-y: auto;
  
  .notification-item {
    padding: 16px 20px;
    border-bottom: 1px solid #f0f4f8;
    cursor: default;
    transition: all 0.3s ease;
    border-radius: 8px;
    margin: 0 8px;
    
    &:hover {
      background: #f8fbff;
      transform: translateX(4px);
    }
    
    .notification-header {
      display: flex;
      justify-content: space-between;
      margin-bottom: 8px;
      
      .notification-title {
        font-weight: 600;
        color: #152844;
        font-size: 14px;
        transition: all 0.3s ease;
      }
      
      .notification-time {
        font-size: 12px;
        color: #999;
        transition: all 0.3s ease;
      }
    }
    
    .notification-desc {
      font-size: 14px;
      color: #555;
      line-height: 1.5;
      transition: all 0.3s ease;
    }
  }
  
  .empty-message {
    text-align: center;
    color: #999;
    padding: 40px 0;
    opacity: 0.7;
    
    .empty-icon {
      font-size: 48px;
      margin-bottom: 12px;
      animation: float 3s ease-in-out infinite;
    }
    
    p {
      margin: 0;
    }
  }
}

// 动画
.animated-fade-in {
  animation: fadeInUp 0.4s ease-out forwards;
  opacity: 0;
}

@keyframes fadeInUp {
  to {
    opacity: 1;
    transform: translateY(0);
  }
  from {
    opacity: 0;
    transform: translateY(10px);
  }
}

@keyframes pulse {
  0% {
    box-shadow: 0 0 0 0 rgba(255, 107, 107, 0.4);
  }
  70% {
    box-shadow: 0 0 0 10px rgba(255, 107, 107, 0);
  }
  100% {
    box-shadow: 0 0 0 0 rgba(255, 107, 107, 0);
  }
}

@keyframes bounce {
  0%, 100% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.2);
  }
}

@keyframes float {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

// 响应式
@media (max-width: 992px) {
  .search-entry {
    width: 300px;
  }
}

@media (max-width: 768px) {
  .search-entry {
    display: none;
  }
  .right-view {
    gap: 16px;
  }
  .main-bar-view {
    padding: 0 20px;
  }
}

</style>
<template>
  <div class="content-list">
    <div class="list-title">系统文档</div>
    <div class="doc-content">
        <div class="doc-card">
          <div class="card-header">
            <div class="header-icon">📘</div>
            <div class="header-text">
              <div class="header-title">系统介绍</div>
              <div class="header-sub">联想（Lenovo）官方综合电子商务与服务平台</div>
            </div>
          </div>

          <div class="card-body">
            <div class="doc-section intro">
              <p>本系统是联想（Lenovo）官方的综合性电子商务与服务平台，集产品展示、在线销售、正品保证、售后评价于一体，旨在为用户提供从选购、购买到使用支持的全流程优质体验。</p>
            </div>

            <div class="doc-section">
              <h4 class="section-title">功能说明</h4>
              <ul class="function-list">
                <li>
                  <span class="function-name">账户注册</span>
                  <p>用户可以通过电子邮箱进行账号注册，注册后请妥善保管好您设置的登录密码。</p>
                </li>
                <li>
                  <span class="function-name">个人账户管理</span>
                  <p>管理个人信息、收货地址，查看收藏的产品、订单记录及评论历史。</p>
                </li>
                <li>
                  <span class="function-name">产品浏览与购买</span>
                  <p>提供商品搜索、筛选、详情查看、加入购物车、在线支付及订单追踪的完整购物流程。</p>
                </li>
                <li>
                  <span class="function-name">服务与支持</span>
                  <p>通过智能 AI 交互帮助用户筛选产品类型；查看商品评价与评分，支持发表评论以辅助他人决策。</p>
                </li>
              </ul>
            </div>

            <div class="doc-section">
              <h4 class="section-title">使用须知</h4>
              <p>用户账户、订单及售后信息将根据相关法律法规及隐私政策进行严格保护。请妥善保管您的登录密码。</p>
            </div>
          </div>
        </div>
    </div>
  </div>
</template>

<script setup>
// 系统文档页面以静态内容为主，无需额外逻辑
</script>

<style scoped lang="less">
.content-list {
  flex: 1;
  padding: 20px;

  .list-title {
    color: #152844;
    font-weight: 600;
    font-size: 18px;
    height: 48px;
    margin-bottom: 20px;
    border-bottom: 1px solid #cedce4;
  }
}

.doc-content {
  color: #484848;
  line-height: 1.8;

  .doc-card {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 8px 20px rgba(21,40,68,0.08);
    overflow: hidden;
    animation: fadeInUp .45s ease both;
  }

  .card-header {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 18px 22px;
    background: linear-gradient(90deg,#1565c0 0%, #1e88e5 100%);
    color: #fff;
  }

  .header-icon{
    width:48px;
    height:48px;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:22px;
    background: rgba(255,255,255,0.12);
    border-radius:8px;
  }

  .header-title{ font-weight:700; font-size:16px }
  .header-sub{ font-size:12px; opacity:.95 }

  .card-body{ padding:18px 22px }

  .doc-section{ margin-bottom:20px }
  .doc-section.intro{ margin-top:6px }

  .section-title{
    color:#152844; font-size:15px; font-weight:700; margin-bottom:10px
  }

  .function-list{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:12px 24px;
    list-style:none;
    padding:0;
    margin:0;
  }

  .function-list li{ display:flex; gap:12px; align-items:flex-start }

  .function-name{
    min-width:120px; background:#f3f8ff; color:#1565c0; padding:6px 10px; border-radius:6px; font-weight:700; font-size:13px
  }

  p{ margin:6px 0; color:#495057 }

  @keyframes fadeInUp{ from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:none} }

  @media (max-width:720px){
    .function-list{ grid-template-columns:1fr }
    .card-body{ padding:14px }
  }
}
</style>
<template>
  <div class="checkout-container">
    <section class="cart-page">
      <div class="content-wrapper">
        <div class="left-section">
          <div class="section-header">
            <h3>订单明细</h3>
          </div>
          <div class="cart-list-view">
            <div class="list-header">
              <span class="product-col">商品名称</span>
              <span class="price-col">价格</span>
              <span class="quantity-col">数量</span>
              <span class="action-col">操作</span>
            </div>
            <div v-if="route.query.cart === '1'">
              <div class="cart-item" v-for="it in cartItems" :key="it.id">
                <div class="product-info">
                  <img :src="it.cover" alt="商品图片" class="product-image" />
                  <div class="product-details">
                    <h2 class="product-title">{{ it.title }}</h2>
                  </div>
                </div>
                <div class="price">¥{{ it.price || 0 }}</div>
                <a-input-number v-model:value="it.quantity" :min="1" :max="999"
                  @change="(val) => handleQuantityChange(it.id, val)" class="quantity-input" />
                <img :src="DeleteIcon" class="delete-icon" @click="() => { cartStore.removeItem(it.id); }" />
              </div>
            </div>
            <div v-else>
              <div class="cart-item">
                <div class="product-info">
                  <img :src="thing.cover" alt="商品图片" class="product-image" />
                  <div class="product-details">
                    <h2 class="product-title">{{ thing.title }}</h2>
                  </div>
                </div>
                <div class="price">¥{{ thing.price || 0 }}</div>
                <a-input-number v-model:value="thing.count" :min="1" :max="10" @change="onCountChange"
                  class="quantity-input" />
                <img :src="DeleteIcon" class="delete-icon" @click="handleDelete" />
              </div>
            </div>
          </div>

          <div class="section-header">
            <h3>备注</h3>
          </div>
          <textarea v-model="thing.remark" placeholder="输入备注信息，100字以内" class="remark-textarea"></textarea>
        </div>

        <div class="right-section">
          <div class="section-header">
            <h3>收货地址</h3>
          </div>
          <div class="address-card">
            <div v-if="thing.receiverAddress" class="address-info">
              <div class="address-header">
                <span class="receiver-name">{{ thing.receiverName }}</span>
                <span class="receiver-phone">{{ thing.receiverPhone }}</span>
              </div>
              <p class="address-detail">{{ thing.receiverAddress }}</p>
            </div>
            <div v-else class="no-address">
              <p>目前暂无地址信息，请<a @click="handleAdd" class="add-address-link">新建地址</a></p>
            </div>
          </div>

          <div class="section-header">
            <h3>结算</h3>
            <span class="price-toggle">价格明细</span>
          </div>
          <div class="price-breakdown">
            <div class="price-item">
              <span class="item-label">商品总价</span>
              <span class="item-value">¥{{ route.query.cart === '1' ? cartTotal : thing.amount }}</span>
            </div>
            <!-- 商品优惠/折扣已移除，仅显示金额 -->
            <div class="total-price">
              <span class="total-label">合计</span>
              <span class="total-amount">¥{{ route.query.cart === '1' ? cartTotal : thing.amount }}</span>
            </div>
          </div>

          <div class="action-buttons">
            <button class="btn btn-secondary" @click="handleBack()">返回</button>
            <button class="btn btn-primary" @click="handleJiesuan()" :disabled="!canCheckout">结算</button>
          </div>
        </div>
      </div>
    </section>

    <!-- 地址编辑弹窗 -->
    <a-modal v-model:visible="modal.visible" :title="modal.title" :footer="null" @cancel="handleCancel"
      class="address-modal">
      <a-form ref="myform" :model="modal.form" :rules="modal.rules" layout="vertical">
        <a-form-item label="收件人姓名" name="name">
          <a-input placeholder="请输入收件人姓名" v-model:value="modal.form.name" />
        </a-form-item>
        <a-form-item label="联系电话" name="mobile">
          <a-input placeholder="请输入联系电话" v-model:value="modal.form.mobile" />
        </a-form-item>
        <a-form-item label="详细地址" name="desc">
          <a-input type="textarea" placeholder="请输入详细地址" v-model:value="modal.form.desc" :rows="3" />
        </a-form-item>
        <a-form-item>
          <a-checkbox v-model:checked="modal.form.default">设为默认地址</a-checkbox>
        </a-form-item>
        <div class="modal-actions">
          <a-button @click="handleCancel">取消</a-button>
          <a-button type="primary" @click="handleOk">确认</a-button>
        </div>
      </a-form>
    </a-modal>
  </div>
</template>

<script setup lang="ts">
import { message, Button as AButton } from 'ant-design-vue';
import DeleteIcon from '/@/assets/images/delete-icon.svg';
import { createApi } from '/@/api/order';
import { listApi as listAddressListApi, createApi as createAddressApi } from '/@/api/address';
import { useUserStore, useCartStore } from '/@/store';

const router = useRouter();
const route = useRoute();
const userStore = useUserStore();

// 定义明确的类型
interface thing {
  id?: string;
  title?: string;
  cover?: string;
  price?: number;
  remark?: string;
  count: number;
  amount?: number;
  receiverName?: string;
  receiverPhone?: string;
  receiverAddress?: string;
}

interface ModalForm {
  name?: string;
  mobile?: string;
  desc?: string;
  default: boolean;
}

const thing = reactive<thing>({
  id: undefined,
  title: undefined,
  cover: undefined,
  price: undefined,
  remark: undefined,
  count: 1,
  amount: undefined,
  receiverName: undefined,
  receiverPhone: undefined,
  receiverAddress: undefined,
});

const cartStore = useCartStore()
const cartItems = computed(() => cartStore.cartItems)
const cartTotal = computed(() => cartStore.totalAmount)

// 弹窗数据
const modal = reactive({
  visible: false,
  editFlag: false,
  title: '',
  form: {
    name: undefined,
    mobile: undefined,
    desc: undefined,
    default: false,
  } as ModalForm,
  rules: {
    name: [{ required: true, message: '请输入收件人姓名', trigger: 'blur' }],
    mobile: [{ required: true, message: '请输入联系电话', trigger: 'blur' }],
    desc: [{ required: true, message: '请输入详细地址', trigger: 'blur' }],
  },
});

const myform = ref();

const canCheckout = computed(() => {
  return !!(userStore.user_id && thing.receiverName);
});

onMounted(() => {
  // 使用类型转换处理路由参数
  thing.id = route.query.id as string || undefined;
  thing.title = route.query.title as string || undefined;
  thing.cover = route.query.cover as string || undefined;

  // 转换价格字段
  const priceParam = route.query.price;
  if (typeof priceParam === 'string') {
    thing.price = parseFloat(priceParam) || 0;
  } else if (typeof priceParam === 'number') {
    thing.price = priceParam;
  } else {
    thing.price = 0;
  }
  // 读取路由传入的数量（用于从购物车单项结算）
  const countParam = route.query.count;
  if (typeof countParam === 'string') {
    const c = parseInt(countParam, 10);
    thing.count = isNaN(c) || c <= 0 ? 1 : c;
  }

  thing.amount = (thing.price || 0) * (thing.count || 1);

  listAddressData();
});

const handleAdd = () => {
  resetModal();
  modal.visible = true;
  modal.editFlag = false;
  modal.title = '新增收货地址';
  // 重置
  modal.form = {
    name: undefined,
    mobile: undefined,
    desc: undefined,
    default: false,
  };
};

const handleOk = async () => {
  if (!userStore.user_id) {
    message.warn('请先登录');
    return;
  }

  try {
    await myform.value.validate();
    const formData = new FormData();
    formData.append('userId', userStore.user_id.toString());
    formData.append('def', modal.form.default ? '1' : '0');

    if (modal.form.name) formData.append('name', modal.form.name);
    if (modal.form.mobile) formData.append('mobile', modal.form.mobile);
    if (modal.form.desc) formData.append('description', modal.form.desc);

    const res = await createAddressApi(formData);
    console.log(res);
    hideModal();
    thing.receiverName = modal.form.name;
    thing.receiverAddress = modal.form.desc;
    thing.receiverPhone = modal.form.mobile;
    message.success('地址添加成功');
  } catch (err: any) {
    console.log('验证失败', err);
    message.error(err.msg || '地址添加失败');
  }
};

const handleCancel = () => {
  hideModal();
};

// 恢复表单初始状态
const resetModal = () => {
  myform.value?.resetFields();
};

// 关闭弹窗
const hideModal = () => {
  modal.visible = false;
};

const onCountChange = (value: number) => {
  const price = thing.price || 0;
  thing.amount = price * value;
};

// 将 InputNumber 的回调值转换为 number 后再传给 store，避免类型不匹配
const handleQuantityChange = (id: string | number, val: unknown) => {
  const num = typeof val === 'number' ? val : parseInt(String(val || '0'), 10) || 0;
  cartStore.setQuantity(id, num);
};

const listAddressData = async () => {
  try {
    const userId = userStore.user_id;
    if (!userId) return;

    const res = await listAddressListApi({ userId });
    if (res.data.length > 0) {
      // 先设置第一个地址
      thing.receiverName = res.data[0].name;
      thing.receiverPhone = res.data[0].mobile;
      thing.receiverAddress = res.data[0].description;

      // 如果有默认地址，则使用默认地址
      const defaultAddress = res.data.find((item: any) => item.default);
      if (defaultAddress) {
        thing.receiverName = defaultAddress.name;
        thing.receiverPhone = defaultAddress.mobile;
        thing.receiverAddress = defaultAddress.description;
      }
    }
  } catch (err) {
    console.log(err);
  }
};

const handleBack = () => {
  router.back();
};

const handleJiesuan = async () => {
  const formData = new FormData();
  const userId = userStore.user_id;

  if (!userId) {
    message.warn('请先登录！');
    return;
  }

  if (!thing.receiverName) {
    message.warn('请选择地址！');
    return;
  }

  formData.append('userId', userId.toString());
  if (thing.id) formData.append('thingId', thing.id);
  formData.append('count', thing.count.toString());
  // 如果从购物车结算，使用购物车总价；否则使用单品金额
  const isCartCheckout = route.query.cart === '1'
  const isCartSingle = route.query.cartSingle === '1'
  const finalAmount = isCartCheckout ? cartTotal.value : (thing.amount || 0)
  formData.append('amount', finalAmount.toString())
  const time = new Date().getTime();
  formData.append('orderNumber', time.toString());

  if (thing.remark) {
    formData.append('remark', thing.remark);
  }

  if (thing.receiverName) {
    formData.append('receiverName', thing.receiverName);
  }
  if (thing.receiverPhone) {
    formData.append('receiverPhone', thing.receiverPhone);
  }
  if (thing.receiverAddress) {
    formData.append('receiverAddress', thing.receiverAddress);
  }
  // 如果是从购物车结算（整体或单项），附带购物车项数组给后端
  if (isCartCheckout || isCartSingle) {
    try {
      let items: any[] = []
      if (isCartCheckout) {
        items = cartItems.value.map((it: any) => ({
          thingId: it.id,
          count: it.quantity || 1,
          price: it.price || 0,
          title: it.title || ''
        }))
      } else if (isCartSingle) {
        // 单项结算：使用 thing 与路由中的 cartItemId
        const thingId = (route.query.cartItemId as string) || thing.id
        items = [{
          thingId: thingId,
          count: thing.count || 1,
          price: thing.price || 0,
          title: thing.title || ''
        }]
      }
      const itemsJson = JSON.stringify(items)
      // 附加多种可能的字段名以兼容后端实现差异
      formData.append('items', itemsJson)
      formData.append('orderItems', itemsJson)
      formData.append('cartItems', itemsJson)
      // 操作者/买家 id（部分后端字段名不同）
      formData.append('operatorId', userId.toString())
    } catch (e) {
      console.warn('序列化购物车项失败', e)
    }
  }

  try {
    const res = await createApi(formData);
    message.success('订单提交成功，请支付');
    const queryObj: Record<string, string> = {
      amount: finalAmount?.toString() || '0',
      orderNum: time.toString(),
    };
    if (route.query.cart === '1') {
      queryObj.cart = '1';
    }
    if (route.query.cartSingle === '1') {
      queryObj.cartSingle = '1';
      // 传递购物车商品ID
      if (route.query.cartItemId) {
        queryObj.cartItemId = String(route.query.cartItemId);
      }
    }
    router.push({
      name: 'pay',
      query: queryObj,
    });
  } catch (err: any) {
    message.error(err.msg || '订单提交失败');
  }
};

const handleDelete = () => {
  message.info('商品已删除');
};
</script>

<style scoped lang="less">
.checkout-container {
  padding: 20px 0;
  background: linear-gradient(135deg, #f5f7fa 0%, #e4edf5 100%);
  min-height: 100vh;
}

.cart-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.content-wrapper {
  display: flex;
  gap: 40px;
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
  overflow: hidden;
}

.left-section {
  flex: 1;
  padding: 30px;
  border-right: 1px solid #f0f0f0;
}

.right-section {
  width: 380px;
  padding: 30px;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding-bottom: 12px;
  border-bottom: 2px solid #f0f5ff;

  h3 {
    color: #1d3557;
    font-weight: 600;
    font-size: 18px;
    margin: 0;
  }

  .price-toggle {
    color: #4dabf7;
    font-size: 14px;
    cursor: pointer;
    transition: color 0.3s;

    &:hover {
      color: #339af0;
    }
  }
}

.cart-list-view {
  margin-bottom: 30px;
}

.list-header {
  display: flex;
  align-items: center;
  padding: 12px 0;
  border-bottom: 2px solid #e9ecef;
  color: #495057;
  font-weight: 600;

  .product-col {
    flex: 1;
    margin-right: 20px;
  }

  .price-col {
    width: 80px;
    margin-right: 20px;
  }

  .quantity-col {
    width: 100px;
    margin-right: 40px;
  }

  .action-col {
    width: 40px;
  }
}

.cart-item {
  display: flex;
  align-items: center;
  padding: 20px 0;
  border-bottom: 1px solid #f8f9fa;

  &:last-child {
    border-bottom: none;
  }

  .product-info {
    display: flex;
    align-items: center;
    flex: 1;
    margin-right: 20px;

    .product-image {
      width: 60px;
      height: 60px;
      border-radius: 6px;
      object-fit: cover;
      margin-right: 16px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .product-details {
      flex: 1;

      .product-title {
        color: #212529;
        font-size: 15px;
        font-weight: 500;
        margin: 0;
        line-height: 1.4;
      }
    }
  }

  .price {
    color: #e63946;
    font-weight: 700;
    font-size: 16px;
    width: 80px;
    margin-right: 20px;
  }

  .quantity-input {
    width: 100px;
    margin-right: 40px;
  }

  .delete-icon {
    width: 24px;
    height: 24px;
    cursor: pointer;
    transition: transform 0.2s;

    &:hover {
      transform: scale(1.1);
    }
  }
}

.remark-textarea {
  width: 100%;
  height: 100px;
  padding: 12px;
  border: 1px solid #e9ecef;
  border-radius: 8px;
  resize: vertical;
  font-size: 14px;
  color: #495057;
  background-color: #f8f9fa;
  transition: border-color 0.3s;

  &:focus {
    outline: none;
    border-color: #4dabf7;
    background-color: white;
    box-shadow: 0 0 0 2px rgba(77, 171, 247, 0.1);
  }
}

.address-card {
  background: #f8f9fa;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 30px;

  .address-info {
    .address-header {
      display: flex;
      justify-content: space-between;
      margin-bottom: 8px;

      .receiver-name {
        font-weight: 600;
        color: #212529;
      }

      .receiver-phone {
        color: #495057;
      }
    }

    .address-detail {
      color: #6c757d;
      margin: 0;
      line-height: 1.5;
    }
  }

  .no-address {
    color: #6c757d;
    text-align: center;
    padding: 20px 0;

    .add-address-link {
      color: #4dabf7;
      cursor: pointer;
      font-weight: 500;

      &:hover {
        color: #339af0;
      }
    }
  }
}

.price-breakdown {
  .price-item {
    display: flex;
    justify-content: space-between;
    padding: 8px 0;

    .item-label {
      color: #6c757d;
    }

    .item-value {
      color: #212529;
      font-weight: 500;
    }

    .discount {
      color: #20c997;
    }
  }

  .total-price {
    display: flex;
    justify-content: space-between;
    padding: 15px 0 10px;
    border-top: 2px solid #e9ecef;
    margin-top: 10px;
    font-weight: 600;

    .total-label {
      color: #212529;
      font-size: 16px;
    }

    .total-amount {
      color: #e63946;
      font-size: 18px;
      font-weight: 700;
    }
  }
}

.action-buttons {
  display: flex;
  justify-content: space-between;
  margin-top: 30px;
  gap: 15px;

  .btn {
    flex: 1;
    padding: 12px 20px;
    border-radius: 8px;
    font-size: 16px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s;
    border: none;

    &.btn-secondary {
      background: #f8f9fa;
      color: #495057;

      &:hover {
        background: #e9ecef;
      }
    }

    &.btn-primary {
      background: linear-gradient(135deg, #4dabf7 0%, #339af0 100%);
      color: white;

      &:hover:not(:disabled) {
        background: linear-gradient(135deg, #339af0 0%, #228be6 100%);
      }

      &:disabled {
        background: #adb5bd;
        cursor: not-allowed;
      }
    }
  }
}

.address-modal {
  :deep(.ant-modal-content) {
    border-radius: 12px;
  }

  :deep(.ant-modal-header) {
    border-radius: 12px 12px 0 0;
    border-bottom: 1px solid #f0f0f0;
  }

  :deep(.ant-modal-body) {
    padding: 24px;
  }
}

.modal-actions {
  display: flex;
  gap: 12px;
  justify-content: flex-end;
  margin-top: 20px;

  :deep(.ant-btn) {
    border-radius: 6px;
    padding: 6px 16px;
  }
}

// 响应式设计
@media (max-width: 768px) {
  .content-wrapper {
    flex-direction: column;
  }

  .right-section {
    width: 100%;
  }

  .cart-item {
    flex-wrap: wrap;

    .product-info {
      min-width: 100%;
      margin-bottom: 10px;
    }
  }
}
</style>

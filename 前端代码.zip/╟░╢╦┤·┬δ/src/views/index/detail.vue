<template>
  <div class="detail-page">
    <!-- 装饰元素 -->
    <div class="decoration-element top-left">
      <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
        <path d="M20,20 Q40,5 60,20 T100,20" stroke="#4684e2" fill="none" stroke-width="1.5" opacity="0.1" />
      </svg>
    </div>
    <div class="decoration-element top-right">
      <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
        <circle cx="80" cy="20" r="8" fill="#f56c6c" opacity="0.1" />
      </svg>
    </div>
    <div class="decoration-element bottom-left">
      <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
        <rect x="10" y="80" width="15" height="15" fill="#67c23a" opacity="0.1" transform="rotate(-45 17.5 87.5)" />
      </svg>
    </div>

    <div class="container">
      <!-- 主要内容区域 -->
      <div class="main-content">
        <!-- 左侧商品详情 -->
        <div class="product-detail-section">
          <!-- 商品展示卡片 -->
          <el-card shadow="hover" class="product-display-card animated-fade-in">
            <div class="product-display">
              <!-- 商品主图 -->
              <div class="product-image-container">
                <el-image :src="detailData.cover" :preview-src-list="[detailData.cover]" fit="contain"
                  class="product-main-image" :class="{ 'image-loading': !detailData.cover }">
                  <template #placeholder>
                    <div class="image-skeleton">
                      <div class="skeleton-animation"></div>
                    </div>
                  </template>
                  <template #error>
                    <div class="image-error">
                      <el-icon>
                        <Picture />
                      </el-icon>
                      <span>图片加载失败</span>
                    </div>
                  </template>
                </el-image>

                <!-- 商品标签 -->
                <div v-if="detailData.repertory > 0" class="product-badge in-stock">
                  <el-icon>
                    <Check />
                  </el-icon>
                  有货
                </div>
                <div v-else class="product-badge out-of-stock">
                  <el-icon>
                    <Close />
                  </el-icon>
                  缺货
                </div>
              </div>

              <!-- 商品信息 -->
              <div class="product-info-wrapper">
                <div class="product-header">
                  <h1 class="product-title">{{ detailData.title }}</h1>
                  <p class="product-subtitle">{{ detailData.description?.substring(0, 60) || '优质商品' }}</p>
                </div>

                <!-- 价格区域 -->
                <div class="price-section">
                  <div class="current-price">
                    <span class="price-symbol">¥</span>
                    <span class="price-value">{{ detailData.price }}</span>
                    <span class="price-unit">起</span>
                  </div>
                  <!-- 原价/折扣信息已移除，仅显示当前价格 -->
                </div>

                <!-- 商品属性 -->
                <div class="product-attributes">
                  <div class="attribute-item">
                    <el-icon>
                      <PriceTag />
                    </el-icon>
                    <span class="attribute-label">分类：</span>
                    <span class="attribute-value">{{ detailData.classificationTitle }}</span>
                  </div>
                  <div class="attribute-item">
                    <el-icon>
                      <Box />
                    </el-icon>
                    <span class="attribute-label">库存：</span>
                    <span class="attribute-value" :class="{ 'low-stock': detailData.repertory < 10 }">
                      {{ detailData.repertory }} 件
                    </span>
                  </div>
                  <div class="attribute-item">
                    <el-icon>
                      <Star />
                    </el-icon>
                    <span class="attribute-label">收藏：</span>
                    <span class="attribute-value">{{ detailData.collectCount || 0 }} 人</span>
                  </div>
                </div>

                <!-- 主要操作按钮 -->
                <div class="action-buttons">
                  <el-button type="primary" size="large" @click="handleOrder(detailData)"
                    class="buy-now-btn animated-pulse" :disabled="detailData.repertory <= 0">
                    <el-icon>
                      <ShoppingCart />
                    </el-icon>
                    {{ detailData.repertory > 0 ? '立即购买' : '暂时缺货' }}
                  </el-button>

                  <el-button type="info" size="large" plain @click="addToWish" class="wish-btn">
                    <el-icon>
                      <ShoppingCart />
                    </el-icon>
                    加入购物车
                  </el-button>
                </div>

                <!-- 快捷操作 -->
                <div class="quick-actions">
                  <div class="quick-action-item" @click="toggleCollect" :class="{ active: isCollected }">
                    <el-icon>
                      <Star />
                    </el-icon>
                    <span>{{ isCollected ? '已收藏' : '收藏' }}</span>
                  </div>
                  <div class="quick-action-item" @click="share">
                    <el-icon>
                      <Share />
                    </el-icon>
                    <span>分享</span>
                  </div>
                </div>
              </div>
            </div>
          </el-card>

          <!-- 标签页内容 -->
          <el-card class="content-tabs-card animated-fade-in" style="margin-top: 24px;">
            <el-tabs v-model="activeTab" class="enhanced-tabs" @tab-click="handleTabChange">
              <el-tab-pane label="商品详情" name="intro">
                <div class="intro-content-wrapper">
                  <div class="intro-header">
                    <h3>商品详情</h3>
                    <div class="intro-meta">
                      <span class="meta-item">
                        <el-icon>
                          <ChatDotSquare />
                        </el-icon>
                        评论 {{ commentData.length }}
                      </span>
                    </div>
                  </div>

                  <div class="intro-content">
                    <div class="description-section">
                      <h4>商品描述</h4>
                      <p class="description-text">
                        {{ detailData.description || '暂无商品描述信息，请联系客服了解详情。' }}
                      </p>
                    </div>

                    <div class="spec-section" v-if="detailData.specifications">
                      <h4>规格参数</h4>
                      <div class="spec-list">
                        <div class="spec-item" v-for="(spec, index) in detailData.specifications.split(',')"
                          :key="index">
                          <span class="spec-label">{{ spec.split(':')[0] }}</span>
                          <span class="spec-value">{{ spec.split(':')[1] || '--' }}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </el-tab-pane>

              <el-tab-pane label="用户评价" name="comment">
                <div class="comment-section-wrapper">
                  <!-- 评价概览 -->
                  <div class="comment-overview">
                    <div class="overview-stats">
                      <div class="stat-item" v-for="(stat, index) in ratingStats" :key="index">
                        <div class="stat-label">{{ stat.label }}</div>
                        <div class="stat-bar">
                          <div class="stat-progress" :style="{ width: stat.percentage + '%' }"></div>
                        </div>
                        <div class="stat-value">{{ stat.percentage }}%</div>
                      </div>
                    </div>
                  </div>

                  <!-- 发表评论 -->
                  <div class="comment-publish">
                    <div class="publish-header">
                      <el-avatar :size="44" :src="avatarSrc" class="user-avatar" />
                      <div class="user-info">
                        <span class="user-name">{{ userStore.user_name || '用户评价' }}</span>
                        <span class="user-hint">分享你的使用体验</span>
                      </div>
                    </div>
                    <div class="publish-content">
                      <el-rate v-model="userRating" class="rating-input" />
                      <el-input v-model="commentContent" type="textarea" :rows="3" placeholder="写下你的评价（建议10-500字）"
                        maxlength="500" show-word-limit ref="commentRef" class="comment-input" />
                      <div class="publish-actions">
                        <el-button type="primary" @click="sendComment" class="publish-btn" :loading="sendingComment"
                          :disabled="sendingComment">
                          <el-icon>
                            <Promotion />
                          </el-icon>
                          发表评价
                        </el-button>
                        <el-button @click="commentContent = ''">清空</el-button>
                      </div>
                    </div>
                  </div>

                  <!-- 评论排序 -->
                  <div class="comment-filter">
                    <div class="filter-stats">
                      <span class="stats-text">
                        共 <span class="stats-count">{{ commentData.length }}</span> 条评价
                      </span>
                    </div>
                    <div class="filter-sort">
                      <el-button :type="sortIndex === 0 ? 'primary' : 'text'" @click="sortCommentList('recent')"
                        class="sort-btn">
                        最新
                      </el-button>
                      <el-button :type="sortIndex === 1 ? 'primary' : 'text'" @click="sortCommentList('hot')"
                        class="sort-btn">
                        热门
                      </el-button>
                    </div>
                  </div>

                  <!-- 评论列表 -->
                  <div class="comments-list" v-if="commentData.length > 0">
                    <div v-for="(item, index) in commentData" :key="item.id" class="comment-item"
                      :style="{ 'animation-delay': `${index * 0.05}s` }">
                      <div class="comment-header">
                        <el-avatar :size="40" :src="avatarSrc" class="comment-avatar" />
                        <div class="comment-user">
                          <div class="user-name">{{ item.username || '匿名用户' }}</div>
                          <div class="comment-meta">
                            <div class="rating-display">
                              <el-rate :model-value="Number(item.rating) || 0" disabled size="small"
                                :colors="['#99A9BF', '#F7BA2A', '#FF9900']" :show-score="false" />
                              <span v-if="item.rating === null || item.rating === undefined || Number(item.rating) <= 0"
                                class="no-rating">暂无评分</span>
                            </div>
                            <span class="comment-time">{{ item.commentTime }}</span>
                          </div>
                        </div>
                        <div class="comment-actions">
                          <el-button link type="primary" @click="like(item.id)" class="like-btn"
                            :class="{ 'liked': item.isLiked }">
                            <el-icon>
                              <Top />
                            </el-icon>
                            推荐 ({{ item.likeCount || 0 }})
                          </el-button>
                        </div>
                      </div>
                      <div class="comment-content">
                        <p class="comment-text">{{ item.content }}</p>
                      </div>
                    </div>
                  </div>

                  <!-- 空状态 -->
                  <div v-else class="empty-comments">
                    <el-empty description="暂无评价" :image-size="100">
                      <template #image>
                        <el-icon :size="100">
                          <ChatLineSquare />
                        </el-icon>
                      </template>
                      <p>快来发表第一条评价吧！</p>
                    </el-empty>
                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>
          </el-card>
        </div>

        <!-- 右侧推荐区域 -->
        <div class="recommend-section">
          <!-- 你可能喜欢 -->
          <el-card class="recommend-card animated-fade-in">
            <template #header>
              <div class="card-title">
                <el-icon>
                  <TrendCharts />
                </el-icon>
                <span>热门推荐</span>
              </div>
            </template>

            <div class="recommend-list">
              <div v-for="(item, index) in recommendData" :key="item.id" class="recommend-item"
                @click="handleDetail(item)" :style="{ 'animation-delay': `${index * 0.1}s` }">
                <div class="item-image">
                  <el-image :src="item.cover" fit="cover" class="item-cover">
                    <template #placeholder>
                      <div class="image-placeholder"></div>
                    </template>
                  </el-image>
                  <div v-if="index < 2" class="item-tag hot">
                    HOT
                  </div>
                </div>
                <div class="item-info">
                  <h4 class="item-title">{{ item.title.length > 20 ? item.title.substring(0, 20) + '...' : item.title }}
                  </h4>
                  <div class="item-price">
                    <span class="price-symbol">¥</span>
                    <span class="price-value">{{ item.price }}</span>
                  </div>
                  <div class="item-actions">
                    <el-button size="small" @click.stop="handleDetail(item)" class="view-btn">
                      查看详情
                    </el-button>
                  </div>
                </div>
              </div>
            </div>
          </el-card>

          <!-- 服务保障 -->
          <el-card class="service-card animated-fade-in" style="margin-top: 24px;">
            <template #header>
              <div class="card-title">
                <el-icon>
                  <Lock />
                </el-icon>
                <span>服务保障</span>
              </div>
            </template>

            <div class="service-list">
              <div class="service-item">
                <el-icon>
                  <CircleCheck />
                </el-icon>
                <div class="service-content">
                  <div class="service-title">正品保障</div>
                  <div class="service-desc">官方正品，假一赔十</div>
                </div>
              </div>
              <div class="service-item">
                <el-icon>
                  <Van />
                </el-icon>
                <div class="service-content">
                  <div class="service-title">快速发货</div>
                  <div class="service-desc">24小时内发货</div>
                </div>
              </div>
              <div class="service-item">
                <el-icon>
                  <Refresh />
                </el-icon>
                <div class="service-content">
                  <div class="service-title">7天退换</div>
                  <div class="service-desc">无忧退换货服务</div>
                </div>
              </div>
              <!-- 已移除人工客服项 -->
            </div>
          </el-card>
        </div>
      </div>

      <!-- 回到顶部 -->
      <div v-show="showBackTop" class="back-to-top" @click="scrollToTop">
        <el-icon>
          <Top />
        </el-icon>
      </div>
      <!-- 购物车图标（固定右下角） -->
      <div class="cart-icon" @click="goToCart">
        <el-badge :value="cartItemCount" :max="99" :hidden="cartItemCount === 0">
          <el-icon class="cart-icon-svg">
            <ShoppingCart />
          </el-icon>
        </el-badge>
        <span class="cart-text">购物车</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, computed } from 'vue'
import { useCartStore } from '/@/store'
import { ElMessage } from 'element-plus'
import {
  ShoppingCart, Star, Share, Plus,
  Picture, Check, Close, PriceTag, Box, View,
  ChatDotSquare, Promotion, Top, ChatLineSquare,
  TrendCharts, Lock, CircleCheck, Van, Refresh
} from '@element-plus/icons-vue'
import AvatarIcon from '/@/assets/images/avatar.jpg'
import { userCollectListApi, collectApi, unCollectApi } from '/@/api/thingCollect'
import {
  detailApi,
  listApi as listThingList
} from '/@/api/thing'
import { listThingCommentsApi, createApi as createCommentApi, likeApi } from '/@/api/comment'
import { wishApi } from '/@/api/thingWish'
import { BASE_URL } from '/@/store/constants'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '/@/store'
import { getFormatTime } from '/@/utils'

// ====== 数据定义 ======
const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const avatarSrc = computed(() => userStore.user_avatar || AvatarIcon)
const cartStore = useCartStore()
const cartItemCount = computed(() => cartStore.totalCount)

const goToCart = () => {
  // 直接跳转到用户中心的购物车视图
  router.push({ name: 'wishThingView' })
}
// 收藏状态
const isCollected = ref(false)
const collecting = ref(false)
const thingId = ref('')
const detailData = ref({})
const activeTab = ref('intro')
const commentData = ref([])
const recommendData = ref([])
const sortIndex = ref(0)
const commentContent = ref('')
const userRating = ref(null)
const showBackTop = ref(false)
// 评分统计数据，用于评论概览（5星到1星）
const ratingStats = ref([
  { label: '5星', percentage: 0 },
  { label: '4星', percentage: 0 },
  { label: '3星', percentage: 0 },
  { label: '2星', percentage: 0 },
  { label: '1星', percentage: 0 }
])

const updateRatingStats = () => {
  const total = commentData.value.length || 0
  const counts = [0, 0, 0, 0, 0]
  commentData.value.forEach(c => {
    const r = (c.rating !== undefined && c.rating !== null) ? Number(c.rating) : null
    if (r !== null && !isNaN(r) && r >= 1 && r <= 5) {
      counts[Math.min(4, Math.max(0, 5 - Math.round(r)))] += 1
    }
  })
  if (total === 0) {
    ratingStats.value.forEach(s => s.percentage = 0)
    return
  }
  ratingStats.value.forEach((s, idx) => {
    const cnt = counts[idx] || 0
    s.percentage = Math.round((cnt / total) * 100)
  })
}


// ====== 生命周期 ======
onMounted(() => {
  const idQuery = route.query.id
  thingId.value = Array.isArray(idQuery) ? (idQuery[0]?.toString().trim() || '') : (idQuery?.toString().trim() || '')
  if (thingId.value) {
    getThingDetail()
    getCommentList()
    setupScrollListener()
    // 查询是否已收藏（若已登录）
    if (userStore.user_id) {
      userCollectListApi({ userId: userStore.user_id }).then(res => {
        try {
          const list = res.data || []
          const tid = String(thingId.value)
          isCollected.value = list.some(it => {
            try {
              return String(it.id) === tid || String(it.thingId) === tid || String(it.thing?.id) === tid || String(it.thing_id) === tid
            } catch (e) { return false }
          })
        } catch (e) { isCollected.value = false }
      }).catch(() => { isCollected.value = false })
    }
  } else {
    ElMessage.error('商品ID无效')
    router.back()
  }
})

// ====== 方法 ======
const getThingDetail = () => {
  detailApi({ id: thingId.value })
    .then((res) => {
      detailData.value = res.data
      if (detailData.value.cover) {
        detailData.value.cover = BASE_URL + '/api/staticfiles/image/' + detailData.value.cover
      }
      getRecommendThing()

      // 添加图片加载动画
      const img = new Image()
      img.src = detailData.value.cover
      img.onload = () => {
        document.querySelectorAll('.product-main-image').forEach(el => {
          el.classList.add('loaded')
        })
      }
    })
    .catch(() => ElMessage.error('获取商品详情失败'))
}

const getRecommendThing = () => {
  const params = {
    sort: 'recommend',
    category: detailData.value.classificationId || undefined,
  }

  listThingList(params).then((res) => {
    recommendData.value = (res.data || []).slice(0, 4).map(item => ({
      ...item,
      cover: item.cover ? BASE_URL + '/api/staticfiles/image/' + item.cover : ''
    }))
  })
}

const getCommentList = () => {
  listThingCommentsApi({ thingId: thingId.value, order: sortIndex.value === 0 ? 'recent' : 'hot' })
    .then(res => {
      commentData.value = (res.data || []).map(item => {
        // 优化昵称显示逻辑，兼容多种后端字段并剥离邮箱域名
        let displayName = '匿名用户';

        // 支持多种可能的昵称字段（兼容大小写/不同后端命名）
        const tryNames = (obj) => {
          if (!obj) return null;
          return obj.nickname || obj.nickName || obj.nick || obj.name || obj.username || obj.user_name || null;
        };

        // 优先从用户对象取昵称
        const userNameFromUser = tryNames(item.user);
        if (userNameFromUser) displayName = userNameFromUser;

        // 其次从评论项本身取
        if (!displayName || displayName === '匿名用户') {
          const nameFromItem = tryNames(item) || item.nickname || item.username || item.user_name;
          if (nameFromItem) displayName = nameFromItem;
        }

        // 如果是邮箱，取前缀作为显示名
        if (typeof displayName === 'string' && displayName.includes && displayName.includes('@')) {
          displayName = displayName.split('@')[0];
        }

        // 处理评分字段 - 兼容 rating/score，确保为有效数字或 null
        let ratingValue = null;
        const rawRating = (item.rating !== undefined && item.rating !== null) ? item.rating : ((item.score !== undefined && item.score !== null) ? item.score : null);
        if (rawRating !== null) {
          const n = Number(rawRating);
          if (!isNaN(n)) ratingValue = n;
        }

        // 确保评分在 0-5 范围内
        if (ratingValue !== null && (ratingValue < 0 || ratingValue > 5)) {
          ratingValue = null;
        }

        return {
          ...item,
          commentTime: getFormatTime(item.commentTime, true),
          isLiked: false,
          username: displayName,
          rating: ratingValue
        };
      });

      // 计算评分统计数据（如果需要）
      updateRatingStats();
    })
    .catch(err => {
      console.error('获取评论列表失败:', err);
      ElMessage.error('获取评论列表失败');
    });
};

const sortCommentList = (type) => {
  sortIndex.value = type === 'recent' ? 0 : 1
  getCommentList()
}

const sendingComment = ref(false)

const sendComment = async () => {
  const text = commentContent.value.trim();
  if (!text) {
    ElMessage.warning('请输入评价内容');
    return;
  }

  if (text.length < 10) {
    ElMessage.warning('评价内容至少10个字');
    return;
  }

  if (!userStore.user_id) {
    ElMessage.warning('请先登录');
    router.push({ name: 'login' });
    return;
  }
  console.log('发送评价:', userRating.value);
  // 评分验证 - 修改为更严格的验证
  if (userRating.value === null ||
    userRating.value === undefined ||
    userRating.value === 0 ||
    Number(userRating.value) <= 0) {
    ElMessage.warning('请选择评分');
    return; // 阻止后续执行
  }
  if (sendingComment.value) return;
  sendingComment.value = true;

  try {
    const fd = new FormData();
    fd.append('content', text);
    fd.append('thingId', String(thingId.value));
    fd.append('userId', String(userStore.user_id));


    // 提交评分时同时兼容 rating 与 score 字段，增加兼容性
    const r = String(userRating.value);
    fd.append('rating', r);

    await createCommentApi(fd);

    // 成功后清空
    commentContent.value = '';
    userRating.value = null;
    await getCommentList();
    ElMessage.success('评价发表成功！');
  } catch (err) {
    console.error('发表评论失败:', err);
    ElMessage.error('发表失败，请重试');
  } finally {
    sendingComment.value = false;
  }
};

const like = (commentId) => {
  likeApi({ commentId: commentId,userId: userStore.user_id}).then(() => {
    getCommentList()
    // ElMessage.success('推荐成功！')
  })
}

const handleOrder = (detail) => {
  if (detail.repertory <= 0) {
    ElMessage.warning('该商品暂时缺货')
    return
  }

  router.push({
    name: 'confirm',
    query: {
      id: detail.id,
      title: detail.title,
      cover: detail.cover,
      price: detail.price
    }
  })
}

const addToWish = () => {
  if (!userStore.user_id) {
    ElMessage.warning('请先登录')
    return
  }

  // 改为加入购物车
  cartStore.addItem({
    id: detailData.value.id,
    title: detailData.value.title,
    price: detailData.value.price,
    cover: detailData.value.cover,
    quantity: 1
  })

  ElMessage.success('已加入购物车')

  // 添加动画效果
  const wishBtn = document.querySelector('.wish-btn')
  if (wishBtn) {
    wishBtn.classList.add('animate-bounce')
    setTimeout(() => wishBtn.classList.remove('animate-bounce'), 300)
  }
}

const toggleCollect = async () => {
  if (!userStore.user_id) {
    ElMessage.warning('请先登录')
    router.push({ name: 'login' })
    return
  }

  if (collecting.value) return
  collecting.value = true

  try {
    if (isCollected.value) {
      // 先尝试从用户收藏列表中找到收藏记录的 id（后端可能要求传收藏记录id）
      let unRes = null
      try {
        const listRes = await userCollectListApi({ userId: userStore.user_id })
        const list = (listRes && listRes.data) || []
        const tid = String(thingId.value)
        const rec = list.find(it => {
          try {
            return String(it.thingId) === tid || String(it.thing?.id) === tid || String(it.thing_id) === tid || String(it.id) === tid
          } catch (e) { return false }
        })

        if (rec && rec.id) {
          unRes = await unCollectApi({ id: rec.id })
        } else {
          // 回退：传递 userId 和 thingId 给后端（如果后端支持）
          unRes = await unCollectApi({ userId: userStore.user_id, thingId: thingId.value })
        }
      } catch (err) {
        throw err
      }

      console.log('unCollect res:', unRes)
      isCollected.value = false
      detailData.value.collectCount = Math.max(0, (detailData.value.collectCount || 1) - 1)
      ElMessage.success((unRes && (unRes.msg || unRes.message)) ? (unRes.msg || unRes.message) : '已取消收藏')
    } else {
      const fd = new FormData()
      fd.append('userId', String(userStore.user_id))
      fd.append('thingId', String(thingId.value))
      const res = await collectApi(fd)
      console.log('collect res:', res)
      isCollected.value = true
      detailData.value.collectCount = (detailData.value.collectCount || 0) + 1
      ElMessage.success((res && (res.msg || res.message)) ? (res.msg || res.message) : '已收藏')
    }
  } catch (e) {
    console.error('collect error:', e)
    const msg = (e && (e.msg || e.message || e.msg)) ? (e.msg || e.message) : null
    ElMessage.error(msg || '操作失败，请重试')
  } finally {
    collecting.value = false
  }
}

// 收藏功能已移除

const share = () => {
  const content = '分享一个超赞的商品 ' + window.location.href
  window.open(`http://service.weibo.com/share/share.php?title=${encodeURIComponent(content)}`, '_blank')
  ElMessage.success('已打开分享页面')
}

const handleDetail = (item) => {
  const routeData = router.resolve({ name: 'detail', query: { id: item.id } })
  window.open(routeData.href, '_blank')
}

const handleTabChange = (tab) => {
  // 标签切换动画
  const tabContent = document.querySelector('.enhanced-tabs .el-tabs__content')
  if (tabContent) {
    tabContent.style.opacity = '0'
    setTimeout(() => {
      tabContent.style.opacity = '1'
    }, 50)
  }
}

const setupScrollListener = () => {
  window.addEventListener('scroll', () => {
    showBackTop.value = window.scrollY > 300
  })
}

const scrollToTop = () => {
  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  })
}
</script>

<style scoped lang="less">
.detail-page {
  min-height: 100vh;
  background: linear-gradient(180deg, #f5f7fa 0%, #ffffff 100%);
  animation: fadeIn 0.8s ease-out;
  position: relative;

  --safe-area-top: 80px;
  padding-top: var(--safe-area-top);

  .decoration-element {
    position: absolute;
    z-index: 0;

    &.top-left {
      top: calc(40px + var(--safe-area-top));
    }

    &.top-right {
      top: calc(60px + var(--safe-area-top));
    }

    &.bottom-left {
      bottom: 100px;
      left: 80px;
      width: 60px;
      height: 60px;
      opacity: 0.4;
    }

    svg {
      width: 100%;
      height: 100%;
    }
  }
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
  position: relative;
  z-index: 1;
}

/* 主要内容区域 */
.main-content {
  display: flex;
  gap: 24px;

  @media (max-width: 992px) {
    flex-direction: column;
  }
}

.product-detail-section {
  flex: 3;
}

.recommend-section {
  flex: 1;
  min-width: 280px;

  @media (max-width: 992px) {
    width: 100%;
  }
}

/* 商品展示卡片 */
.product-display-card {
  border: none;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
  transition: transform 0.3s ease, box-shadow 0.3s ease;

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.12);
  }

  .product-display {
    display: flex;
    gap: 24px;
    padding: 16px;

    @media (max-width: 768px) {
      flex-direction: column;
      gap: 20px;
    }
  }
}

.product-image-container {
  flex: 1;
  position: relative;
  min-height: 180px;
  /* 降低高度 */
  border-radius: 12px;
  overflow: hidden;

  .quick-actions {
    display: flex;
    gap: 12px;
    margin-top: 12px;

    .quick-action-item {
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
      color: #606266;
      font-size: 14px;

      &.active {
        color: #f56c6c;
      }
    }
  }

  background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);

  .product-main-image {
    width: 100%;
    height: 100%;
    object-fit: contain;
    transition: transform 0.6s ease;

    &.loaded {
      animation: zoomIn 0.8s ease-out;
    }

    &:hover {
      transform: scale(1.05);
    }
  }

  .image-skeleton {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;

    .skeleton-animation {
      width: 80%;
      height: 80%;
      background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
      background-size: 200% 100%;
      animation: loading 1.5s infinite;
      border-radius: 8px;
    }
  }

  .image-error {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #999;

    .el-icon {
      font-size: 48px;
      margin-bottom: 12px;
      color: #dcdfe6;
    }
  }

  .product-badge {
    position: absolute;
    top: 16px;
    right: 16px;
    padding: 6px 16px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    color: white;
    display: flex;
    align-items: center;
    gap: 4px;
    z-index: 2;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);

    &.in-stock {
      background: linear-gradient(135deg, #67c23a, #85ce61);
    }

    &.out-of-stock {
      background: linear-gradient(135deg, #f56c6c, #f78989);
    }
  }
}

.product-info-wrapper {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.product-header {
  .status-tag {
    font-size: 12px;
    padding: 4px 12px;
    margin-bottom: 12px;

    .el-icon {
      margin-right: 4px;
    }
  }

  .product-title {
    font-size: 28px;
    font-weight: 700;
    color: #1f2d3d;
    margin: 8px 0;
    line-height: 1.4;
  }

  .product-subtitle {
    font-size: 16px;
    color: #606266;
    line-height: 1.6;
  }
}

.price-section {
  background: linear-gradient(135deg, #fff9f9 0%, #f8f9ff 100%);
  padding: 20px;
  border-radius: 12px;
  border: 1px solid #e6f0ff;

  .current-price {
    display: flex;
    align-items: baseline;
    margin-bottom: 12px;

    .price-symbol {
      font-size: 24px;
      font-weight: 600;
      color: #f56c6c;
      margin-right: 4px;
    }

    .price-value {
      font-size: 48px;
      font-weight: 800;
      color: #f56c6c;
      margin-right: 8px;
    }

    .price-unit {
      font-size: 16px;
      color: #909399;
    }
  }

  .original-price {
    display: flex;
    align-items: center;
    gap: 8px;

    .original-text {
      font-size: 14px;
      color: #909399;
    }

    .original-value {
      font-size: 20px;
      color: #909399;
      text-decoration: line-through;
    }
  }
}

.product-attributes {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
  padding: 20px;
  background: #f8fafc;
  border-radius: 12px;

  .attribute-item {
    display: flex;
    align-items: center;
    gap: 8px;

    .el-icon {
      color: #4684e2;
      font-size: 18px;
    }

    .attribute-label {
      font-size: 14px;
      color: #606266;
    }

    .attribute-value {
      font-size: 14px;
      font-weight: 600;
      color: #152844;

      &.low-stock {
        color: #f56c6c;
      }
    }
  }
}

.action-buttons {
  display: flex;
  gap: 16px;
  margin-top: 12px;

  .buy-now-btn {
    flex: 2;
    height: 56px;
    font-size: 16px;
    font-weight: 600;
    background: linear-gradient(135deg, #4684e2, #0066b2);
    border: none;
    border-radius: 12px;
    transition: all 0.3s ease;

    &:hover:not(:disabled) {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(70, 132, 226, 0.4);
    }

    &:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    .el-icon {
      margin-right: 8px;
    }
  }

  .wish-btn {
    flex: 1;
    height: 56px;
    font-size: 16px;
    border-radius: 12px;
    border: 2px solid #4684e2;
    color: #4684e2;

    &:hover {
      background: #e6f0ff;
      transform: translateY(-2px);
    }
  }
}

.quick-actions {
  display: flex;
  gap: 24px;
  padding: 20px;
  background: #f8fafc;
  border-radius: 12px;
  margin-top: 12px;

  .quick-action-item {
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    color: #606266;

    &:hover {
      color: #4684e2;
      transform: translateY(-2px);
    }

    .el-icon {
      font-size: 20px;

      &.active {
        color: #f56c6c;
      }
    }

    .action-count {
      font-size: 12px;
      color: #999;
    }
  }
}

/* 标签页样式 */
.content-tabs-card {
  border: none;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);

  .enhanced-tabs {
    :deep(.el-tabs__header) {
      margin: 0;
      background: white;
      border-bottom: 1px solid #e6f0ff;
    }

    :deep(.el-tabs__nav-wrap) {
      padding: 0 24px;
    }

    :deep(.el-tabs__item) {
      font-size: 16px;
      font-weight: 500;
      padding: 20px 24px;
      transition: all 0.3s ease;

      &:hover {
        color: #4684e2;
      }

      &.is-active {
        color: #4684e2;
        font-weight: 600;
      }
    }

    :deep(.el-tabs__active-bar) {
      background: #4684e2;
      height: 3px;
    }
  }
}

.intro-content-wrapper {
  padding: 24px;
  animation: fadeIn 0.5s ease-out;

  .intro-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 24px;
    padding-bottom: 16px;
    border-bottom: 1px solid #e6f0ff;

    h3 {
      font-size: 20px;
      font-weight: 600;
      color: #152844;
    }

    .intro-meta {
      display: flex;
      gap: 20px;

      .meta-item {
        display: flex;
        align-items: center;
        gap: 6px;
        color: #606266;
        font-size: 14px;

        .el-icon {
          color: #4684e2;
        }
      }
    }
  }

  .description-section,
  .spec-section {
    margin-bottom: 32px;

    h4 {
      font-size: 18px;
      font-weight: 600;
      color: #152844;
      margin-bottom: 16px;
      padding-bottom: 8px;
      border-bottom: 2px solid #e6f0ff;
    }

    .description-text {
      line-height: 1.8;
      color: #606266;
      font-size: 15px;
    }
  }

  .spec-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 16px;

    .spec-item {
      display: flex;
      justify-content: space-between;
      padding: 12px 16px;
      background: #f8fafc;
      border-radius: 8px;
      border: 1px solid #e6f0ff;

      .spec-label {
        color: #606266;
        font-size: 14px;
      }

      .spec-value {
        color: #152844;
        font-weight: 500;
      }
    }
  }
}

/* 评论区域样式 */
.comment-section-wrapper {
  padding: 24px;
  animation: fadeIn 0.5s ease-out;
}

.comment-overview {
  display: block;
  padding: 24px;
  background: linear-gradient(135deg, #f8fafc 0%, #f0f7ff 100%);
  border-radius: 12px;
  margin-bottom: 32px;

  .overview-stats {
    /* 移除flex: 1; */
    width: 100%;

    .stat-item {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 16px;

      &:last-child {
        margin-bottom: 0;
      }

      .stat-label {
        width: 80px;
        font-size: 14px;
        color: #606266;
      }

      .stat-bar {
        flex: 1;
        height: 8px;
        background: #e6f0ff;
        border-radius: 4px;
        overflow: hidden;

        .stat-progress {
          height: 100%;
          background: linear-gradient(90deg, #4684e2, #0095d9);
          border-radius: 4px;
          transition: width 1s ease;
        }
      }

      .stat-value {
        width: 40px;
        font-size: 14px;
        font-weight: 600;
        color: #152844;
      }
    }
  }
}

.comment-publish {
  background: white;
  border-radius: 12px;
  padding: 24px;
  margin-bottom: 32px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);

  .publish-header {
    display: flex;
    align-items: center;
    gap: 16px;
    margin-bottom: 20px;

    .user-avatar {
      border: 2px solid #e6f0ff;
    }

    .user-info {
      .user-name {
        font-size: 16px;
        font-weight: 600;
        color: #152844;
        display: block;
      }

      .user-hint {
        font-size: 14px;
        color: #909399;
      }
    }
  }

  .publish-content {
    .rating-input {
      margin-bottom: 16px;
    }

    .comment-input {
      margin-bottom: 16px;

      :deep(.el-textarea__inner) {
        border-radius: 8px;
        border-color: #e6f0ff;
        transition: all 0.3s ease;

        &:focus {
          border-color: #4684e2;
          box-shadow: 0 0 0 2px rgba(70, 132, 226, 0.1);
        }
      }
    }

    .publish-actions {
      display: flex;
      justify-content: flex-end;
      gap: 12px;

      .publish-btn {
        background: linear-gradient(135deg, #4684e2, #0066b2);
        border: none;
        border-radius: 8px;
        padding: 10px 24px;

        &:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(70, 132, 226, 0.3);
        }
      }
    }
  }
}

.comment-filter {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 0;
  margin-bottom: 24px;
  border-bottom: 1px solid #e6f0ff;

  .filter-stats {
    .stats-text {
      font-size: 14px;
      color: #606266;

      .stats-count {
        color: #4684e2;
        font-weight: 600;
      }
    }
  }

  .filter-sort {
    display: flex;
    gap: 8px;

    .sort-btn {
      padding: 6px 16px;
      border-radius: 16px;
      font-size: 14px;
      transition: all 0.3s ease;

      &:hover {
        background: #e6f0ff;
      }
    }
  }
}

.rating-display {
  display: flex;
  align-items: center;
  gap: 8px;
}

.no-rating {
  font-size: 12px;
  color: #909399;
  margin-left: 4px;
}

.comments-list {
  .comment-item {
    padding: 24px;
    background: white;
    border-radius: 12px;
    margin-bottom: 16px;
    border: 1px solid #e6f0ff;
    transition: all 0.3s ease;
    animation: slideInRight 0.5s ease-out forwards;
    opacity: 0;

    &:hover {
      border-color: #4684e2;
      box-shadow: 0 4px 12px rgba(70, 132, 226, 0.1);
      transform: translateX(4px);
    }

    &:last-child {
      margin-bottom: 0;
    }

    .comment-header {
      display: flex;
      align-items: center;
      gap: 16px;
      margin-bottom: 16px;

      .comment-avatar {
        border: 2px solid #e6f0ff;
      }

      .comment-user {
        flex: 1;

        .user-name {
          font-weight: 600;
          color: #152844;
          margin-bottom: 4px;
        }

        .comment-meta {
          display: flex;
          align-items: center;
          gap: 12px;

          .comment-time {
            font-size: 12px;
            color: #909399;
          }
        }
      }

      .comment-actions {
        .like-btn {
          padding: 6px 12px;
          border-radius: 16px;
          font-size: 13px;
          transition: all 0.3s ease;

          &:hover,
          &.liked {
            background: #e6f0ff;
            color: #4684e2;
          }

          .el-icon {
            margin-right: 4px;
          }
        }
      }
    }

    .comment-content {
      .comment-text {
        line-height: 1.6;
        color: #606266;
        font-size: 14px;
        margin: 0;
        padding-left: 56px;
      }
    }
  }
}

.empty-comments {
  padding: 60px 0;
  text-align: center;

  .el-icon {
    color: #dcdfe6;
  }

  p {
    color: #909399;
    margin-top: 12px;
  }
}

/* 推荐卡片样式 */
.recommend-card,
.service-card {
  border: none;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
  transition: transform 0.3s ease;

  &:hover {
    transform: translateY(-4px);
  }

  :deep(.el-card__header) {
    border-bottom: 1px solid #e6f0ff;
    padding: 20px 24px;
    background: linear-gradient(135deg, #f8fafc 0%, #f0f7ff 100%);
  }

  .card-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 18px;
    font-weight: 600;
    color: #152844;

    .el-icon {
      color: #4684e2;
      font-size: 20px;
    }
  }
}

.recommend-list {
  padding: 12px;

  .recommend-item {
    display: flex;
    gap: 16px;
    padding: 16px;
    border-radius: 12px;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-bottom: 12px;
    animation: slideInLeft 0.5s ease-out forwards;
    opacity: 0;

    &:hover {
      background: #f8fafc;
      transform: translateX(8px);
    }

    &:last-child {
      margin-bottom: 0;
    }

    .item-image {
      position: relative;
      width: 80px;
      height: 80px;
      border-radius: 8px;
      overflow: hidden;
      flex-shrink: 0;

      .item-cover {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }

      .image-placeholder {
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
      }

      .item-tag {
        position: absolute;
        top: 6px;
        right: 6px;
        padding: 2px 8px;
        border-radius: 10px;
        font-size: 10px;
        font-weight: 700;
        color: white;

        &.hot {
          background: linear-gradient(45deg, #ff6b6b, #ff8e53);
        }
      }
    }

    .item-info {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: space-between;

      .item-title {
        font-size: 14px;
        font-weight: 600;
        color: #152844;
        margin: 0 0 8px 0;
        line-height: 1.4;
      }

      .item-price {
        .price-symbol {
          font-size: 12px;
          color: #f56c6c;
        }

        .price-value {
          font-size: 20px;
          font-weight: 700;
          color: #f56c6c;
        }
      }

      .item-actions {
        margin-top: 8px;

        .view-btn {
          padding: 4px 12px;
          font-size: 12px;
          border-radius: 12px;
          border-color: #4684e2;
          color: #4684e2;

          &:hover {
            background: #e6f0ff;
          }
        }
      }
    }
  }
}

.service-card {
  :deep(.el-card__body) {
    padding: 20px 24px;
  }

  .service-list {
    display: flex;
    flex-direction: column;
    gap: 16px;

    .service-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px;
      border-radius: 8px;
      transition: all 0.3s ease;

      &:hover {
        background: #f8fafc;
      }

      .el-icon {
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #e6f0ff;
        color: #4684e2;
        border-radius: 8px;
        font-size: 18px;
      }

      .service-content {
        .service-title {
          font-size: 14px;
          font-weight: 600;
          color: #152844;
          margin-bottom: 2px;
        }

        .service-desc {
          font-size: 12px;
          color: #909399;
        }
      }
    }
  }
}

/* 回到顶部按钮 */
.back-to-top {
  position: fixed;
  bottom: 40px;
  right: 40px;
  width: 56px;
  height: 56px;
  background: linear-gradient(135deg, #4684e2, #0066b2);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: white;
  box-shadow: 0 8px 20px rgba(70, 132, 226, 0.4);
  transition: all 0.3s ease;
  z-index: 1000;
  opacity: 0;
  transform: translateY(20px);
  animation: float 3s ease-in-out infinite;

  &.show {
    opacity: 1;
    transform: translateY(0);
  }

  &:hover {
    transform: translateY(-6px) scale(1.1);
    box-shadow: 0 12px 24px rgba(70, 132, 226, 0.5);
  }

  .el-icon {
    font-size: 24px;
  }
}

/* 动画关键帧 */
@keyframes fadeIn {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes slideInRight {
  from {
    opacity: 0;
    transform: translateX(30px);
  }

  to {
    opacity: 1;
    transform: translateX(0);
  }
}

@keyframes slideInLeft {
  from {
    opacity: 0;
    transform: translateX(-30px);
  }

  to {
    opacity: 1;
    transform: translateX(0);
  }
}

@keyframes zoomIn {
  from {
    opacity: 0;
    transform: scale(0.95);
  }

  to {
    opacity: 1;
    transform: scale(1);
  }
}

@keyframes loading {
  0% {
    background-position: 200% 0;
  }

  100% {
    background-position: -200% 0;
  }
}

@keyframes float {

  0%,
  100% {
    transform: translateY(0);
  }

  50% {
    transform: translateY(-15px);
  }
}

@keyframes bounce {

  0%,
  100% {
    transform: translateY(0);
  }

  50% {
    transform: translateY(-10px);
  }
}

.animated-fade-in {
  animation: fadeIn 0.6s ease-out;
}

.animated-pulse {
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0% {
    box-shadow: 0 0 0 0 rgba(70, 132, 226, 0.4);
  }

  70% {
    box-shadow: 0 0 0 10px rgba(70, 132, 226, 0);
  }

  100% {
    box-shadow: 0 0 0 0 rgba(70, 132, 226, 0);
  }
}

.animate-bounce {
  animation: bounce 0.3s ease;
}

/* 响应式调整 */
@media (max-width: 768px) {
  .container {
    padding: 12px;
  }

  .product-display {
    padding: 12px !important;
  }

  .product-image-container {
    min-height: 140px;
    /* 移动端进一步降低高度 */
  }

  .price-section {
    .current-price {
      .price-value {
        font-size: 36px;
      }
    }
  }

  .product-attributes {
    grid-template-columns: 1fr;
  }

  .action-buttons {
    flex-direction: column;
  }

  .decoration-element {
    display: none;
    /* 移动端隐藏装饰元素 */
  }

  .back-to-top {
    bottom: 20px;
    right: 20px;
    width: 48px;
    height: 48px;
  }
}

@media (max-width: 576px) {
  .intro-header {
    flex-direction: column;
    align-items: flex-start !important;
    gap: 12px;
  }

  .comment-overview {
    flex-direction: column;
    gap: 24px;
  }

  .spec-list {
    grid-template-columns: 1fr !important;
  }
}

/* 右下角购物车图标样式 */
.cart-icon {
  position: fixed;
  top: 50%;
  right: 20px;
  transform: translateY(-50%);
  width: 70px;
  height: 70px;
  background: linear-gradient(135deg, #4684e2, #0066b2);
  border-radius: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: white;
  box-shadow: 0 8px 20px rgba(70, 132, 226, 0.4);
  transition: all 0.3s;
  z-index: 1000;
}

.cart-icon:hover {
  transform: translateY(calc(-50% - 6px)) scale(1.05);
  box-shadow: 0 12px 24px rgba(70, 132, 226, 0.5);
}

.cart-icon-svg {
  font-size: 28px;
  margin-bottom: 2px;
}

.cart-text {
  font-size: 12px;
  font-weight: 500;
}
</style>

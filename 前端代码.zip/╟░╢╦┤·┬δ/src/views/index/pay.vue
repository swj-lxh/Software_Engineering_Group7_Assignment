<template>
  <div class="payment-container">
    <div class="payment-card">
      <!-- 成功状态 -->
      <div v-if="paymentStatus === 'success'" class="payment-success">
        <div class="success-icon">
          <svg viewBox="0 0 24 24">
            <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
          </svg>
        </div>
        <h1 class="success-title">支付成功！</h1>
        <p class="success-text">订单支付已完成，感谢您的购买</p>
        <div class="order-info">
          <div class="info-item">
            <span class="label">订单号：</span>
            <span class="value">{{ orderNumber }}</span>
          </div>
          <div class="info-item">
            <span class="label">支付金额：</span>
            <span class="value price">{{ formattedAmount }}</span>
          </div>
          <div class="info-item">
            <span class="label">支付时间：</span>
            <span class="value">{{ formatDate(new Date()) }}</span>
          </div>
        </div>
        <div class="action-buttons">
          <button class="btn-primary" @click="goToHome">返回首页</button>
          <button class="btn-secondary" @click="goToOrders">查看订单</button>
        </div>
      </div>

      <!-- 支付中状态 -->
      <div v-else class="payment-main">
        <!-- 头部 -->
        <div class="payment-header">
          <h1 class="title">订单支付</h1>
          <p class="subtitle">请完成支付以确认订单</p>
        </div>

        <!-- 金额展示 -->
        <div class="amount-section">
          <div class="amount-label">支付金额</div>
          <div class="amount-value">
            <span class="currency">¥</span>
            <span class="number">{{ formattedAmount }}</span>
          </div>
          <div class="order-info">
            订单号：{{ orderNumber }}
          </div>
        </div>

        <!-- 支付方式选择 -->
        <div class="payment-methods">
          <h3 class="methods-title">选择支付方式</h3>
          <div class="methods-grid">
            <div 
              v-for="method in paymentMethods" 
              :key="method.id"
              :class="['method-card', { 'active': selectedMethod === method.id }]"
              @click="selectMethod(method.id)"
            >
              <div class="method-icon">
                <img :src="method.icon" :alt="method.name" />
              </div>
              <div class="method-info">
                <span class="method-name">{{ method.name }}</span>
                <span class="method-desc">{{ method.description }}</span>
              </div>
              <div class="method-check">
                <div class="check-circle"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- 支付按钮 -->
        <div class="payment-actions">
          <button 
            class="pay-button"
            :class="{ 'loading': isPaying }"
            @click="handlePay"
            :disabled="isPaying"
          >
            <span v-if="!isPaying">确认支付 {{ formattedAmount }}</span>
            <span v-else class="loading-text">
              <span class="spinner"></span>
              支付处理中...
            </span>
          </button>
          <p class="payment-tips">
            <svg class="tip-icon" viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
            </svg>
            支付完成后，系统会自动处理订单
          </p>
        </div>
      </div>
    </div>

    <!-- 底部链接（已移除联系客服） -->
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { message } from 'ant-design-vue'
import { payOrderApi } from '/@/api/order'
import { useCartStore } from '/@/store'

// Icons
import WxPayIcon from '/@/assets/images/wx-pay-icon.svg'
import AliPayIcon from '/@/assets/images/ali-pay-icon.svg'

const router = useRouter()
const route = useRoute()
const cartStore = useCartStore()

// 响应式数据
const amount = ref(0)
const orderNumber = ref('')
const isPaying = ref(false)
const paymentStatus = ref('pending') // pending, success, failed
const selectedMethod = ref('wechat')

// 支付方式列表
const paymentMethods = ref([
  {
    id: 'wechat',
    name: '微信支付',
    description: '推荐微信用户使用',
    icon: WxPayIcon
  },
  {
    id: 'alipay',
    name: '支付宝',
    description: '推荐支付宝用户使用',
    icon: AliPayIcon
  }
])

onMounted(() => {
  amount.value = parseFloat(route.query.amount) || 0
  orderNumber.value = route.query.orderNum || ''
})

// 计算属性
const formattedAmount = computed(() => {
  return amount.value.toFixed(2)
})

// 方法
const selectMethod = (methodId) => {
  selectedMethod.value = methodId
}

const handlePay = async () => {
  if (isPaying.value) return
  
  isPaying.value = true
  
  try {
    const formData = new FormData()
    formData.append('orderNumber', orderNumber.value)
    
    await payOrderApi(formData)
    
    // 支付成功
    paymentStatus.value = 'success'
    
    // 如果是整体购物车结算，清空购物车
    if (route.query.cart === '1') {
      cartStore.clear()
      message.success({
        content: '支付成功！已清空购物车',
        duration: 2,
        style: {
          marginTop: '50px'
        }
      })
    } 
    // 如果是购物车单项结算，则只移除该项
    else if (route.query.cartSingle === '1' && route.query.cartItemId) {
      try {
        // 使用路由传递的 cartItemId 来移除商品
        const cartItemId = route.query.cartItemId
        
        // 先查找购物车中是否有对应商品
        const cartItem = cartStore.cartItems.find(item => 
          String(item.id) === String(cartItemId)
        )
        
        if (cartItem) {
          // 从购物车中移除该商品，使用找到的 cartItem.id 保证类型匹配
          cartStore.removeItem(cartItem.id)
          
          message.success({
            content: `支付成功！已从购物车移除 "${cartItem.title || '商品'}"`,
            duration: 2,
            style: {
              marginTop: '50px'
            }
          })
        } else {
          console.warn('未在购物车中找到对应商品，cartItemId:', cartItemId)
        }
      } catch (e) {
        console.warn('移除购物车单项失败', e)
        message.warning({
          content: '支付成功，但购物车商品移除失败',
          duration: 2,
          style: {
            marginTop: '50px'
          }
        })
      }
    } 
    // 如果是普通商品直接购买（非购物车商品）
    else {
      message.success({
        content: '支付成功！',
        duration: 2,
        style: {
          marginTop: '50px'
        }
      })
    }
    
  } catch (err) {
    paymentStatus.value = 'failed'
    message.error({
      content: err.msg || '支付失败，请重试',
      duration: 3,
      style: {
        marginTop: '50px'
      }
    })
        setTimeout(() => {
      paymentStatus.value = 'pending'
      isPaying.value = false
    }, 3000)
    
  } finally {
    if (paymentStatus.value === 'success') {
      isPaying.value = false
    }
  }
}

const goToHome = () => {
  router.push('/')
}

const goToOrders = () => {
  // 直接跳转到 order-view（使用路由名称）
  router.push({ name: 'orderView' })
}

const formatDate = (date) => {
  const d = new Date(date)
  return `${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, '0')}-${d.getDate().toString().padStart(2, '0')} ${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`
}
</script>

<style scoped lang="less">
.payment-container {
  min-height: 100vh;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 20px;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
}

.payment-card {
  background: white;
  border-radius: 20px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
  padding: 40px;
  width: 100%;
  max-width: 500px;
  animation: slideUp 0.6s ease-out;

  @keyframes slideUp {
    from {
      opacity: 0;
      transform: translateY(30px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
}

.payment-header {
  text-align: center;
  margin-bottom: 30px;

  .title {
    font-size: 28px;
    font-weight: 600;
      color: #1a1a1a;
      margin-bottom: 8px;
  }

  .subtitle {
    color: #666;
    font-size: 16px;
  }
}

.amount-section {
  text-align: center;
  margin: 30px 0;
  padding: 30px 20px;
  background: linear-gradient(135deg, #f8f9ff 0%, #eef2ff 100%);
  border-radius: 16px;
  border: 1px solid rgba(70, 132, 226, 0.1);

  .amount-label {
    font-size: 16px;
    color: #666;
    margin-bottom: 12px;
  }

  .amount-value {
    display: flex;
    align-items: baseline;
    justify-content: center;
    gap: 4px;
    margin-bottom: 16px;

    .currency {
      font-size: 24px;
      color: #ff6b35;
      font-weight: 500;
    }

    .number {
      font-size: 48px;
      font-weight: 700;
      color: #ff6b35;
      line-height: 1;
    }
  }

  .order-info {
    font-size: 14px;
    color: #888;
    background: rgba(255, 255, 255, 0.8);
    padding: 8px 16px;
    border-radius: 20px;
    display: inline-block;
  }
}

.payment-methods {
  margin: 40px 0;

  .methods-title {
    font-size: 18px;
    font-weight: 600;
    color: #1a1a1a;
    margin-bottom: 20px;
  }

  .methods-grid {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .method-card {
    display: flex;
    align-items: center;
    padding: 20px;
    border: 2px solid #e4e7ed;
    border-radius: 12px;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    background: white;
    position: relative;

    &:hover {
      border-color: #4684e2;
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(70, 132, 226, 0.15);
    }

    &.active {
      border-color: #4684e2;
      background: linear-gradient(135deg, rgba(70, 132, 226, 0.05) 0%, rgba(70, 132, 226, 0.02) 100%);
    }

    .method-icon {
      width: 48px;
      height: 48px;
      background: #f8f9ff;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-right: 16px;

      img {
        width: 28px;
        height: 28px;
      }
    }

    .method-info {
      flex: 1;
      display: flex;
      flex-direction: column;

      .method-name {
        font-weight: 600;
        color: #1a1a1a;
        font-size: 16px;
        margin-bottom: 4px;
      }

      .method-desc {
        font-size: 14px;
        color: #888;
      }
    }

    .method-check {
      .check-circle {
        width: 24px;
        height: 24px;
        border: 2px solid #e4e7ed;
        border-radius: 50%;
        transition: all 0.3s;
        position: relative;

        &::after {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%) scale(0);
          width: 12px;
          height: 12px;
          background: #4684e2;
          border-radius: 50%;
          transition: transform 0.3s;
        }
      }
    }

    &.active .check-circle {
      border-color: #4684e2;

      &::after {
        transform: translate(-50%, -50%) scale(1);
      }
    }
  }
}

.payment-actions {
  margin-top: 40px;

  .pay-button {
    width: 100%;
    padding: 18px;
    background: linear-gradient(45deg, #4684e2, #5c94f5);
    color: white;
    border: none;
    border-radius: 12px;
    font-size: 18px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    position: relative;
    overflow: hidden;

    &:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(70, 132, 226, 0.3);
    }

    &:active {
      transform: translateY(0);
    }

    &:disabled {
      opacity: 0.7;
      cursor: not-allowed;
    }

    &.loading {
      background: #4684e2;
    }

    .loading-text {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }

    .spinner {
      width: 20px;
      height: 20px;
      border: 2px solid rgba(255, 255, 255, 0.3);
      border-radius: 50%;
      border-top-color: white;
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }
  }

  .payment-tips {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin-top: 16px;
    color: #888;
    font-size: 14px;

    .tip-icon {
      width: 16px;
      height: 16px;
      fill: #888;
    }
  }
}

// 支付成功样式
.payment-success {
  text-align: center;
  animation: fadeIn 0.6s ease-out;

  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }

  .success-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #52c41a, #73d13d);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 24px;

    svg {
      width: 40px;
      height: 40px;
      fill: white;
    }
  }

  .success-title {
    font-size: 28px;
    font-weight: 600;
    color: #1a1a1a;
    margin-bottom: 12px;
  }

  .success-text {
    color: #666;
    font-size: 16px;
    margin-bottom: 40px;
  }

  .order-info {
    background: #f8f9ff;
    border-radius: 16px;
    padding: 24px;
    margin: 30px 0;
    text-align: left;

    .info-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 16px;
      padding-bottom: 16px;
      border-bottom: 1px solid #eee;

      &:last-child {
        margin-bottom: 0;
        padding-bottom: 0;
        border-bottom: none;
      }

      .label {
        color: #666;
        font-size: 14px;
      }

      .value {
        color: #1a1a1a;
        font-weight: 500;
        font-size: 14px;

        &.price {
          color: #ff6b35;
          font-weight: 600;
          font-size: 18px;
        }
      }
    }
  }

  .action-buttons {
    display: flex;
    gap: 16px;
    margin-top: 30px;

    button {
      flex: 1;
      padding: 16px;
      border-radius: 12px;
      font-size: 16px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.3s;
      border: none;

      &.btn-primary {
        background: linear-gradient(45deg, #4684e2, #5c94f5);
        color: white;

        &:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(70, 132, 226, 0.3);
        }
      }

      &.btn-secondary {
        background: #f0f2f5;
        color: #1a1a1a;

        &:hover {
          background: #e4e7ed;
          transform: translateY(-2px);
        }
      }
    }
  }
}

.payment-footer {
  margin-top: 30px;
  text-align: center;
  color: #666;
  font-size: 14px;

  .help-link {
    color: #4684e2;
    text-decoration: none;
    font-weight: 500;
    transition: color 0.3s;

    &:hover {
      color: #5c94f5;
      text-decoration: underline;
    }
  }
}

// 响应式设计
@media (max-width: 640px) {
  .payment-container {
    padding: 16px;
  }

  .payment-card {
    padding: 24px;
    border-radius: 16px;
  }

  .amount-section {
    padding: 24px 16px;

    .amount-value {
      .number {
        font-size: 40px;
      }
    }
  }

  .payment-methods {
    .method-card {
      padding: 16px;
    }
  }

  .payment-success {
    .action-buttons {
      flex-direction: column;
    }
  }
}
</style>
<template>
  <div class="login-container">
    <el-card class="login-card">
      <div class="logo">
        <img :src="LogoIcon" alt="logo" class="logo-icon" />
      </div>

      <div class="tab-header">
        <span class="tab-active">邮箱登录</span>
      </div>

      <el-form
        ref="loginFormRef"
        :model="pageData.loginForm"
        :rules="loginRules"
        @submit.prevent="handleLogin"
        size="large"
      >
        <el-form-item prop="username">
          <el-input
            v-model="pageData.loginForm.username"
            placeholder="请输入注册邮箱"
            prefix-icon="MailIcon"
          >
            <template #prefix>
              <img :src="MailIcon" class="input-icon" />
            </template>
          </el-input>
        </el-form-item>

        <el-form-item prop="password">
          <el-input
            v-model="pageData.loginForm.password"
            type="password"
            placeholder="请输入密码"
            show-password
            prefix-icon="PwdIcon"
          >
            <template #prefix>
              <img :src="PwdIcon" class="input-icon" />
            </template>
          </el-input>
        </el-form-item>

        <el-button
          type="primary"
          class="login-btn"
          @click="handleLogin"
          :loading="loading"
          round
        >
          登录
        </el-button>
      </el-form>

      <div class="operation-links">
        <el-link type="primary" @click="handleCreateUser">注册新帐号</el-link>
        <el-link type="primary">忘记密码？</el-link>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useUserStore } from '/@/store';
import { ElMessage } from 'element-plus';
import LogoIcon from '/@/assets/images/ouc.png';
import MailIcon from '/@/assets/images/mail-icon.svg';
import PwdIcon from '/@/assets/images/pwd-icon.svg';

const router = useRouter();
const userStore = useUserStore();
const loading = ref(false);

const pageData = reactive({
  loginForm: {
    username: '',
    password: '',
  },
});

// 表单校验规则
const loginRules = {
  username: [
    { required: true, message: '请输入邮箱', trigger: 'blur' },
    { type: 'email', message: '请输入正确的邮箱格式', trigger: 'blur' },
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, message: '密码至少6位', trigger: 'blur' },
  ],
};

const handleLogin = () => {
  loading.value = true;
  userStore
    .login({
      username: pageData.loginForm.username,
      password: pageData.loginForm.password,
    })
    .then(() => {
      ElMessage.success('登录成功！');
      router.push({ name: 'portal' });
    })
    .catch((err) => {
      ElMessage.warning(err.msg || '登录失败');
    })
    .finally(() => {
      loading.value = false;
    });
};

const handleCreateUser = () => {
  router.push({ name: 'register' });
};
</script>

<style scoped lang="less">
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-image: url('../images/login.png');
  background-size: cover;
}

.login-card {
  width: 400px;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.logo {
  text-align: center;
  margin-bottom: 24px;
}

.logo-icon {
  width: 48px;
  height: 48px;
}

.tab-header {
  text-align: center;
  margin-bottom: 24px;
}

.tab-active {
  font-weight: 600;
  color: #1e1e1e;
  position: relative;
}

.tab-active::after {
  content: '';
  display: block;
  width: 40px;
  height: 2px;
  background: #409eff; /* Element Plus 主色 */
  margin: 8px auto 0;
}

.input-icon {
  width: 16px;
  height: 16px;
  margin-right: 8px;
}

:deep(.el-input__prefix) {
  display: flex;
  align-items: center;
}

.login-btn {
  width: 100%;
  margin: 24px 0;
}

.operation-links {
  display: flex;
  justify-content: space-between;
  padding: 0 10px;
}
</style>
<template>
    <div class="order-view">
        <div class="order-header">
            <h2 class="page-title">我的订单</h2>
            <el-tabs v-model="activeTab" @tab-change="onTabChange">
                <el-tab-pane label="全部订单" name="0"></el-tab-pane>
                <el-tab-pane label="待付款" name="1"></el-tab-pane>
                <el-tab-pane label="已支付" name="2"></el-tab-pane>
                <el-tab-pane label="已取消" name="3"></el-tab-pane>
            </el-tabs>
        </div>

        <!-- 使用 grid 容器 -->
        <div class="order-grid">
            <el-card v-for="(item, index) in orderData" :key="index" class="order-card" shadow="hover">
                <div class="order-header-info">
                    <div class="order-meta">
                        <span class="order-number">订单号: {{ item.orderNumber }}</span>
                        <span class="order-time">{{ getFormatTime(item.orderTime, true) }}</span>
                    </div>
                    <div class="order-status" :class="'status-' + item.status">
                        {{ getStatusText(item.status) }}
                    </div>
                </div>

                <div class="product-info">
                    <el-image :src="item.cover" class="product-image" fit="cover" lazy />
                    <div class="product-details">
                        <div class="product-title">{{ item.title }}</div>
                        <div class="product-price">¥{{ item.price }}</div>
                        <div class="product-count">x{{ item.count }}</div>
                    </div>
                </div>

                <div class="order-summary">
                    <div><strong>收货人：</strong>{{ item.receiverName }} {{ item.receiverPhone }}</div>
                    <div><strong>地址：</strong>{{ item.receiverAddress }}</div>
                    <div v-if="item.remark"><strong>备注：</strong>{{ item.remark }}</div>
                </div>

                <div class="order-footer">
                    <div class="order-total">
                        共 {{ item.count }} 件，合计 <span class="total-amount">¥{{ item.price * item.count }}</span>
                    </div>
                    <div class="order-actions">
                        <el-button v-if="item.status === '1'" type="danger" plain size="small"
                            @click="handleCancel(item)">
                            取消订单
                        </el-button>
                        <el-button type="primary" plain size="small" @click="handleDetail(item.thingId)">
                            查看详情
                        </el-button>
                    </div>
                </div>
            </el-card>

            <el-empty v-if="orderData.length === 0" description="暂无订单数据" />
        </div>
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getFormatTime } from '/@/utils/'
import { userOrderListApi, cancelUserOrderApi } from '/@/api/order'
import { BASE_URL } from "/@/store/constants"
import { useUserStore } from "/@/store"

const router = useRouter()
const userStore = useUserStore()

const orderData = ref([])
const orderStatus = ref('')

// 改为：
const route = useRoute() // 👈 新增
const activeTab = ref(route.query.tab || '0')

onMounted(() => {
    // activeTab 已经从 query 初始化了
    orderStatus.value = activeTab.value === '0' ? null : activeTab.value
    getOrderList()
})

const onTabChange = (key) => {
    orderStatus.value = key === '0' ? null : key
    getOrderList()
}

const getOrderList = () => {
    const userId = userStore.user_id
    userOrderListApi({ userId, status: orderStatus.value }).then(res => {
        orderData.value = res.data.map(item => ({
            ...item,
            cover: item.cover ? `${BASE_URL}/api/staticfiles/image/${item.cover}` : ''
        }))
    }).catch(err => {
        console.error(err)
    })
}

const handleDetail = (thingId) => {
    const url = router.resolve({ name: 'detail', query: { id: thingId } })
    window.open(url.href, '_blank')
}

const handleCancel = (item) => {
    ElMessageBox.confirm('确定要取消这个订单吗？', '确认取消', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
    }).then(() => {
        cancelUserOrderApi({ id: item.id }).then(() => {
            ElMessage.success('取消成功')
            getOrderList()
        }).catch(err => {
            ElMessage.error(err.msg || '取消失败')
        })
    })
}

const getStatusText = (status) => {
    const map = { '1': '待支付', '2': '已支付' }
    return map[status] || '已取消'
}
</script>

<style scoped lang="less">
.order-view {
    padding: 20px;
    max-width: 1200px;
    margin: 0 auto;

    .order-header {
        background: #fff;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);

        .page-title {
            font-size: 20px;
            font-weight: 600;
            color: #152844;
            margin-bottom: 20px;
        }

        :deep(.el-tabs__nav-wrap::after) {
            height: 1px;
        }
    }

    .order-grid {
        display: grid;
        /* 使用grid布局，每列最小宽度为300px，自动填充 */
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 20px;
        /* 卡片之间的间距 */

        .order-card {
            border-radius: 12px;
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);

            &:hover {
                transform: translateY(-4px);
                box-shadow: 0 8px 12px rgba(0, 0, 0, 0.15);
            }

            .order-header-info {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 16px;
                padding-bottom: 12px;
                border-bottom: 1px solid #eee;

                .order-meta {
                    font-size: 13px;
                    color: #666;
                }

                .order-status {
                    padding: 4px 10px;
                    border-radius: 12px;
                    font-size: 12px;
                    font-weight: 500;

                    &.status-1 {
                        background: #fdf6ec;
                        color: #e6a23c;
                    }

                    &.status-2 {
                        background: #f0f9eb;
                        color: #67c23a;
                    }

                    &.status-3 {
                        background: #f4f4f5;
                        color: #999;
                    }
                }
            }

            .product-info {
                display: flex;
                gap: 12px;
                margin-bottom: 16px;

                .product-image {
                    width: 80px;
                    height: 80px;
                    border-radius: 6px;
                    object-fit: cover;
                }

                .product-details {
                    flex: 1;

                    .product-title {
                        font-weight: 500;
                        font-size: 15px;
                        margin-bottom: 4px;
                        word-break: break-word;
                    }

                    .product-price {
                        color: #f56c6c;
                        font-weight: 600;
                        font-size: 16px;
                    }

                    .product-count {
                        color: #999;
                        font-size: 14px;
                        margin-top: 4px;
                    }
                }
            }

            .order-summary {
                font-size: 13px;
                color: #666;
                line-height: 1.6;
                margin-bottom: 16px;

                div {
                    margin-bottom: 4px;
                }
            }

            .order-footer {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding-top: 12px;
                border-top: 1px solid #eee;

                .order-total {
                    font-size: 14px;
                    color: #666;

                    .total-amount {
                        color: #f56c6c;
                        font-weight: 600;
                        font-size: 16px;
                    }
                }

                .order-actions {
                    display: flex;
                    gap: 8px;
                }
            }
        }

        :deep(.el-empty) {
            grid-column: 1 / -1;
            padding: 50px 0;
        }
    }

    @media (max-width: 768px) {
        padding: 12px;

        .order-header {
            padding: 16px;
        }

        .order-grid {
            grid-template-columns: 1fr;
            gap: 16px;
        }
    }
}
</style>
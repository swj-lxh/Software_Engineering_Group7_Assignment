<template>
  <div class="content-list improved-cart">
    <div class="list-header-row">
      <div class="list-title">我的购物车</div>
      <div class="cart-summary compact">
        <div class="total-info">
          <div class="count">共 <strong>{{ cartItemCount }}</strong> 件</div>
          <div class="total-price">合计 <strong>¥{{ totalPrice }}</strong></div>
        </div>
        <el-button type="primary" @click="goToCheckout" :disabled="cartItemCount === 0">去结算</el-button>
      </div>
    </div>

    <div class="list-content">
      <transition-group name="list" tag="div" class="thing-list">
        <div class="thing-item" v-for="item in cartItems" :key="item.id" role="listitem" aria-label="购物车商品">
          <button class="remove" @click.prevent="handleRemove(item)" aria-label="移出商品">✕</button>

          <div class="card">
            <div class="img-view" @click="handleClickItem(item)" role="link" tabindex="0">
              <img :src="item.cover" :alt="item.title || '商品图片'" />
            </div>

            <div class="info-view">
              <h3 class="thing-name">{{ item.title }}</h3>

              <div class="meta-row">
                <div class="quantity-control">
                  <el-button size="small" @click.stop="decreaseQuantity(item)"
                    :disabled="(item.quantity || 0) <= 1">-</el-button>
                  <span class="quantity">{{ item.quantity }}</span>
                  <el-button size="small" @click.stop="increaseQuantity(item)">+</el-button>
                </div>

                <div class="item-actions">
                  <el-button size="small" type="primary" @click.stop="checkoutItem(item)">单独结算</el-button>
                </div>

                <div class="item-total">小计: <span>¥{{ (item.price || 0) * (item.quantity || 0) }}</span></div>
              </div>
            </div>
          </div>
        </div>
      </transition-group>

      <div v-if="cartItemCount === 0" class="empty-cart enhanced">
        <el-empty description="购物车还是空的">
          <el-button type="primary" @click="goToHome">去逛逛</el-button>
        </el-empty>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useCartStore } from '/@/store'

type Item = {
  id: string | number
  title?: string
  cover?: string
  price?: number
  quantity?: number
}

const router = useRouter()
const cartStore = useCartStore()

const cartItems = computed<Item[]>(() => cartStore.cartItems || [])
const cartItemCount = computed(() => cartStore.totalCount)
const totalPrice = computed(() => cartStore.totalAmount)

const handleClickItem = (record: Item) => {
  const url = router.resolve({ name: 'detail', query: { id: record.id } })
  window.open(url.href, '_blank')
}

const handleRemove = (item: Item) => {
  cartStore.removeItem(item.id)
  ElMessage.success('已移出购物车')
}

const increaseQuantity = (item: Item) => {
  const next = (item.quantity || 0) + 1
  cartStore.setQuantity(item.id, next)
}

const decreaseQuantity = (item: Item) => {
  const cur = item.quantity || 0
  if (cur > 1) cartStore.setQuantity(item.id, cur - 1)
}

const goToCheckout = () => {
  router.push({ name: 'confirm', query: { cart: '1' } })
}

const checkoutItem = (item: Item) => {
  // 单独结算某个购物车商品，标记为来自购物车的单项结算
  router.push({
    name: 'confirm',
    query: {
      id: String(item.id),
      title: item.title || '',
      cover: item.cover || '',
      price: String(item.price || 0),
      count: String(item.quantity || 1),
      cartSingle: '1', // 标记为购物车单项结算
      cartItemId: String(item.id), // 传递购物车商品ID
    }
  })
}

const goToHome = () => router.push({ name: 'portal' })
</script>

<style scoped lang="less">
.improved-cart {
  padding: 18px 12px;

  .list-header-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;

    .list-title {
      font-size: 20px;
      font-weight: 700;
      color: #152844;
    }
  }

  .cart-summary.compact {
    display: flex;
    align-items: center;
    gap: 12px;
    background: linear-gradient(90deg, #f7fbff, #ffffff);
    padding: 8px 12px;
    border-radius: 10px;
    box-shadow: 0 4px 12px rgba(21, 34, 56, 0.04);

    .total-info {
      text-align: right;

      .count {
        color: #606266;
      }

      .total-price {
        color: #f56c6c;
        font-weight: 700;
      }
    }
  }

  .list-content {
    margin-top: 8px;
  }

  .thing-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 16px;

    .thing-item {
      position: relative;
    }
  }

  .card {
    display: flex;
    gap: 12px;
    align-items: flex-start;
    background: #ffffff;
    border-radius: 12px;
    padding: 12px;
    box-shadow: 0 8px 22px rgba(21, 34, 56, 0.05);
    transition: transform 220ms cubic-bezier(.2, .9, .2, 1), box-shadow 220ms;

    &:hover {
      transform: translateY(-8px);
      box-shadow: 0 18px 40px rgba(21, 34, 56, 0.08);
    }
  }

  .img-view {
    position: relative;
    width: 110px;
    height: 110px;
    flex: 0 0 110px;
    border-radius: 8px;
    overflow: hidden;
    background: #f5f7fb;
    cursor: pointer;

    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 260ms ease;
    }


  }

  .card:hover .img-view img {
    transform: scale(1.06);
  }

  .remove {
    position: absolute;
    top: 10px;
    right: 10px;
    background: rgba(0, 0, 0, 0.55);
    color: #fff;
    border-radius: 50%;
    width: 30px;
    height: 30px;
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 5;
    transition: transform 180ms;
  }

  .remove:hover {
    transform: scale(1.06);
  }

  .info-view {
    flex: 1 1 auto;
    display: flex;
    flex-direction: column;
  }

  .thing-name {
    font-size: 15px;
    color: #162134;
    margin: 0 0 8px 0;
    line-height: 1.3;
    max-height: 2.6em;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .meta-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    margin-top: auto;
  }

  .quantity-control {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: #f5f8fb;
    padding: 6px 8px;
    border-radius: 8px;
  }

  .quantity {
    min-width: 36px;
    text-align: center;
    font-weight: 700;
  }

  .item-total span {
    color: #ff6b6b;
    font-weight: 800;
  }

  .empty-cart.enhanced {
    padding: 80px 0;
    text-align: center;
  }

  /* list transition */
  .list-enter-active,
  .list-leave-active {
    transition: all 260ms cubic-bezier(.2, .8, .2, 1);
  }

  .list-enter-from {
    opacity: 0;
    transform: translateY(8px) scale(0.995);
  }

  .list-leave-to {
    opacity: 0;
    transform: translateY(8px) scale(0.995);
  }
}
</style>
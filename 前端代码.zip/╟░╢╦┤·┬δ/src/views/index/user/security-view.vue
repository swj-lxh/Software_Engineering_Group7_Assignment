<template>
  <div class="content-list">
    <div class="list-title">帐号安全</div>
    <div class="list-content">
      <div class="safe-view">
        <!-- 安全概览卡片 -->
        <div class="safe-info-box card">
          <div class="item flex-view">
            <div class="label">
              <span class="label-text">账号安全等级</span>
              <span class="label-icon">🔒</span>
            </div>
            <div class="right-box flex-view">
              <div class="security-level">
                <div class="level-tag">
                  <span class="level-icon">⚠️</span>
                  <span class="level-text">低风险</span>
                </div>
                <div class="security-progress">
                  <div class="progress-bar">
                    <div class="progress-fill" :style="{ width: '66%' }"></div>
                    <div class="progress-dots">
                      <div class="progress-dot active"></div>
                      <div class="progress-dot active"></div>
                      <div class="progress-dot"></div>
                    </div>
                  </div>
                  <div class="progress-labels">
                    <span>低</span>
                    <span>中</span>
                    <span>高</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 修改密码卡片 -->
        <div class="edit-pwd-box card">
          <div class="card-header">
            <h3 class="card-title">
              <span class="title-icon">🔑</span>
              <span class="title-text">修改密码</span>
            </h3>
            <div class="card-subtitle">定期更换密码，保护账号安全</div>
          </div>

          <div class="pwd-edit">
            <div class="item flex-view">
              <div class="label">
                <span class="label-text">当前密码</span>
              </div>
              <div class="right-box">
                <div class="input-wrapper">
                  <a-input-password placeholder="请输入当前密码" v-model:value="password" class="password-input"
                    size="large" />
                  <div class="input-hint">请输入您当前正在使用的密码</div>
                </div>
              </div>
            </div>

            <div class="item flex-view">
              <div class="label">
                <span class="label-text">新密码</span>
              </div>
              <div class="right-box">
                <div class="input-wrapper">
                  <a-input-password placeholder="请输入新密码" v-model:value="newPassword1" class="password-input"
                    size="large" />
                  <div class="password-strength">
                    <div class="strength-bar" :class="getPasswordStrength(newPassword1)"></div>
                    <div class="strength-text">
                      密码强度: {{ getPasswordStrengthText(newPassword1) }}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="item flex-view">
              <div class="label">
                <span class="label-text">确认新密码</span>
              </div>
              <div class="right-box">
                <div class="input-wrapper">
                  <a-input-password placeholder="请再次输入新密码" v-model:value="newPassword2" class="password-input"
                    size="large" />
                  <div class="password-match"
                    :class="{ match: newPassword1 && newPassword2 && newPassword1 === newPassword2 }">
                    <span class="match-icon">
                      {{ newPassword1 && newPassword2 && newPassword1 === newPassword2 ? '✓' : '!' }}
                    </span>
                    <span class="match-text">
                      {{ newPassword1 && newPassword2 && newPassword1 === newPassword2 ? '密码匹配' : '密码不一致' }}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="item flex-view">
              <div class="label"></div>
              <div class="right-box">
                <div class="action-buttons">
                  <a-button type="primary" size="large" class="submit-btn" @click="handleUpdatePwd()"
                    :disabled="!isFormValid">
                    <template #icon>
                      <span class="btn-submit-icon">✓</span>
                    </template>
                    确认修改
                  </a-button>
                  <a-button size="large" class="cancel-btn" @click="resetForm">
                    重置
                  </a-button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { message } from "ant-design-vue";
import { updateUserPwdApi } from '/@/api/user'
import { useUserStore } from "/@/store";
import { computed, ref } from 'vue'

const router = useRouter();
const userStore = useUserStore();

let password = ref('')
let newPassword1 = ref('')
let newPassword2 = ref('')

const isFormValid = computed(() => {
  return password.value && newPassword1.value && newPassword2.value &&
    newPassword1.value === newPassword2.value &&
    getPasswordStrength(newPassword1.value) !== 'weak'
})

const getPasswordStrength = (password) => {
  if (!password) return 'empty'
  if (password.length < 6) return 'weak'
  if (password.length < 8) return 'medium'
  if (/[A-Z]/.test(password) && /[a-z]/.test(password) && /\d/.test(password) && /[^A-Za-z0-9]/.test(password)) {
    return 'strong'
  }
  return 'medium'
}

const getPasswordStrengthText = (password) => {
  const strength = getPasswordStrength(password)
  switch (strength) {
    case 'empty': return '请设置密码'
    case 'weak': return '弱'
    case 'medium': return '中'
    case 'strong': return '强'
    default: return ''
  }
}

const handleBindMobile = () => {
  message.info('功能开发中')
}

const handleUpdatePwd = () => {
  if (!password.value || !newPassword1.value || !newPassword2.value) {
    message.warn('请填写完整信息')
    return
  }
  if (newPassword1.value !== newPassword2.value) {
    message.warn('两次输入的密码不一致')
    return
  }

  if (getPasswordStrength(newPassword1.value) === 'weak') {
    message.warn('密码强度太弱，请设置更复杂的密码')
    return
  }

  let userId = userStore.user_id
  updateUserPwdApi({
    userId: userId,
    password: password.value,
    newPassword: newPassword1.value,
  }).then(res => {
    message.success('密码修改成功')
    resetForm()
  }).catch(err => {
    message.error(err.msg || '修改失败')
  })
}

const resetForm = () => {
  password.value = ''
  newPassword1.value = ''
  newPassword2.value = ''
}
</script>

<style scoped lang="less">
// 变量定义
@primary-color: #4684e2;
@primary-hover: #3a70c7;
@danger-color: #ff4d4f;
@warning-color: #faad14;
@success-color: #52c41a;
@text-primary: #152844;
@text-secondary: #5f77a9;
@text-tertiary: #8a94b8;
@border-color: #e6e9f0;
@bg-color: #f8fafb;
@bg-hover: #f0f4ff;
@card-bg: #ffffff;
@shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.06);
@shadow-md: 0 4px 12px rgba(0, 0, 0, 0.08);
@shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.1);
@radius-sm: 8px;
@radius-md: 12px;
@radius-lg: 16px;
@transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

// 重置样式
input,
textarea {
  border: none;
  outline: none;
  margin: 0;
  padding: 0;
  font-family: inherit;
  font-size: inherit;
  color: inherit;
  background: transparent;
  transition: @transition;

  &::placeholder {
    color: @text-tertiary;
    opacity: 0.6;
  }
}

.flex-view {
  display: flex;
  align-items: center;
}

// 主要内容区域
.content-list {
  flex: 1;
  animation: fadeIn 0.6s ease-out;

  .list-title {
    color: @text-primary;
    font-weight: 700;
    font-size: 24px;
    line-height: 1.2;
    margin-bottom: 32px;
    padding-bottom: 16px;
    position: relative;

    &::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 60px;
      height: 3px;
      background: linear-gradient(90deg, @primary-color, #8fa9ff);
      border-radius: 2px;
    }
  }
}

// 卡片样式
.card {
  background: @card-bg;
  border-radius: @radius-lg;
  padding: 32px;
  box-shadow: @shadow-sm;
  border: 1px solid @border-color;
  margin-bottom: 24px;
  transition: @transition;

  &:hover {
    box-shadow: @shadow-md;
    border-color: fade(@primary-color, 20%);
  }
}

// 卡片头部
.card-header {
  margin-bottom: 32px;

  .card-title {
    display: flex;
    align-items: center;
    gap: 12px;
    color: @text-primary;
    font-size: 20px;
    font-weight: 700;
    margin: 0 0 8px 0;

    .title-icon {
      font-size: 24px;
    }

    .title-text {
      position: relative;

      &::after {
        content: '';
        position: absolute;
        bottom: -4px;
        left: 0;
        width: 40px;
        height: 2px;
        background: @primary-color;
        border-radius: 1px;
      }
    }
  }

  .card-subtitle {
    color: @text-secondary;
    font-size: 14px;
    margin: 0;
  }
}

// 表单项目
.item {
  padding: 24px 0;
  border-bottom: 1px solid @border-color;

  &:last-child {
    border-bottom: none;
    padding-bottom: 0;
  }

  &:first-child {
    padding-top: 0;
  }

  .label {
    width: 160px;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 8px;

    .label-text {
      color: @text-primary;
      font-weight: 600;
      font-size: 15px;
    }

    .label-icon {
      font-size: 18px;
      opacity: 0.8;
    }
  }

  .right-box {
    flex: 1;
    min-width: 0;
  }
}

// 安全等级显示
.security-level {
  display: flex;
  align-items: center;
  gap: 32px;
  width: 100%;

  .level-tag {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 16px;
    background: fade(@warning-color, 10%);
    border: 1px solid fade(@warning-color, 20%);
    border-radius: @radius-md;

    .level-icon {
      font-size: 20px;
    }

    .level-text {
      color: @warning-color;
      font-weight: 600;
      font-size: 16px;
    }
  }
}

// 安全进度条
.security-progress {
  flex: 1;

  .progress-bar {
    position: relative;
    height: 8px;
    background: @bg-color;
    border-radius: 4px;
    overflow: hidden;
    margin-bottom: 8px;

    .progress-fill {
      height: 100%;
      background: linear-gradient(90deg, @warning-color, #ffd666);
      border-radius: 4px;
      transition: @transition;
    }

    .progress-dots {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 2px;

      .progress-dot {
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: white;
        border: 2px solid @border-color;

        &.active {
          border-color: @warning-color;
          background: @warning-color;
        }
      }
    }
  }

  .progress-labels {
    display: flex;
    justify-content: space-between;
    font-size: 12px;
    color: @text-tertiary;
  }
}

// 手机输入框
.mobile-input-wrapper {
  display: flex;
  align-items: center;
  background: @bg-color;
  border-radius: @radius-sm;
  border: 2px solid transparent;
  transition: @transition;
  overflow: hidden;

  &:hover {
    background: @bg-hover;
    border-color: fade(@primary-color, 20%);
  }

  &:focus-within {
    background: white;
    border-color: @primary-color;
    box-shadow: 0 0 0 3px fade(@primary-color, 10%);
  }

  .mobile-prefix {
    padding: 0 16px;
    color: @text-secondary;
    font-weight: 500;
    border-right: 1px solid @border-color;
    height: 48px;
    display: flex;
    align-items: center;
    background: white;
  }

  .input-dom {
    flex: 1;
    height: 48px;
    padding: 0 16px;
    font-size: 15px;
    color: @text-primary;
    min-width: 0;
  }
}

// 绑定按钮
.bind-btn {
  margin-left: 16px;
  padding: 12px 20px;
  height: 48px;
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 500;
  border-radius: @radius-sm;
  transition: @transition;

  &:hover {
    background: fade(@primary-color, 8%);
    transform: translateY(-1px);

    .btn-icon {
      transform: rotate(180deg);
    }
  }

  .btn-text {
    color: @primary-color;
  }

  .btn-icon {
    font-size: 16px;
    transition: transform 0.6s ease;
  }
}

// 密码输入框容器
.input-wrapper {
  position: relative;

  .password-input {
    border-radius: @radius-sm;
    border: 2px solid @border-color;
    transition: @transition;

    &:hover {
      border-color: fade(@primary-color, 40%);
    }

    &:focus {
      border-color: @primary-color;
      box-shadow: 0 0 0 3px fade(@primary-color, 10%);
    }
  }

  .input-hint {
    font-size: 12px;
    color: @text-tertiary;
    margin-top: 8px;
  }
}

// 密码强度指示器
.password-strength {
  margin-top: 12px;

  .strength-bar {
    height: 4px;
    border-radius: 2px;
    margin-bottom: 4px;
    transition: @transition;

    &.empty {
      width: 0;
      background: @border-color;
    }

    &.weak {
      width: 33%;
      background: @danger-color;
    }

    &.medium {
      width: 66%;
      background: @warning-color;
    }

    &.strong {
      width: 100%;
      background: @success-color;
    }
  }

  .strength-text {
    font-size: 12px;
    color: @text-secondary;
  }
}

// 密码匹配提示
.password-match {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 8px;
  font-size: 12px;

  &.match {
    color: @success-color;
  }

  &:not(.match) {
    color: @danger-color;
  }

  .match-icon {
    width: 16px;
    height: 16px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 10px;
    font-weight: bold;
  }

  &.match .match-icon {
    background: @success-color;
    color: white;
  }

  &:not(.match) .match-icon {
    background: @danger-color;
    color: white;
  }
}

// 操作按钮
.action-buttons {
  display: flex;
  gap: 16px;
  margin-top: 24px;

  .submit-btn {
    padding: 0 32px;
    height: 48px;
    font-weight: 600;
    border-radius: @radius-md;
    background: linear-gradient(135deg, @primary-color, #5d95ff);
    border: none;
    box-shadow: @shadow-sm;
    transition: @transition;

    &:hover:not(:disabled) {
      transform: translateY(-2px);
      box-shadow: @shadow-md;
    }

    &:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .btn-submit-icon {
      font-size: 16px;
    }
  }

  .cancel-btn {
    padding: 0 32px;
    height: 48px;
    font-weight: 500;
    border-radius: @radius-md;
    border: 2px solid @border-color;

    &:hover {
      border-color: @primary-color;
      color: @primary-color;
    }
  }
}

// 响应式设计
@media (max-width: 768px) {
  .content-list {
    .list-title {
      font-size: 20px;
      margin-bottom: 24px;
    }
  }

  .card {
    padding: 20px;
  }

  .item {
    flex-direction: column;
    align-items: flex-start;
    gap: 16px;

    .label {
      width: 100%;
    }
  }

  .security-level {
    flex-direction: column;
    align-items: flex-start;
    gap: 16px;
  }

  .mobile-input-wrapper {
    width: 100%;
    margin-bottom: 12px;
  }

  .bind-btn {
    width: 100%;
    justify-content: center;
    margin-left: 0;
  }

  .action-buttons {
    flex-direction: column;
    width: 100%;

    button {
      width: 100%;
    }
  }
}
</style>
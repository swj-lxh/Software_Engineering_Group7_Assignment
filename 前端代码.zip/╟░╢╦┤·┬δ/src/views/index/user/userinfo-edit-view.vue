<template>
  <div class="content-list">
    <div class="list-title">设置</div>
    <a-spin :spinning="loading" style="min-height: 200px;">
      <div class="list-content">
        <div class="edit-view">
          <!-- 头像设置 -->
          <div class="item flex-view">
            <div class="label">头像</div>
            <div class="right-box avatar-box flex-view">
              <div class="avatar-wrapper">
                <img 
                  v-if="tData.form && tData.form.avatar" 
                  :src="tData.form.avatar" 
                  class="avatar"
                >
                <img v-else :src="avatarSrc" class="avatar">
              </div>
              <div class="change-tips flex-view">
                <a-upload
                  name="file"
                  accept="image/*"
                  :multiple="false"
                  :before-upload="beforeUpload"
                >
                  <label class="upload-label">点击更换头像</label>
                </a-upload>
                <p class="tip">支持 GIF、PNG、JPEG 格式，尺寸不小于 200 PX，小于 4 MB</p>
              </div>
            </div>
          </div>
          
          <!-- 昵称 -->
          <div class="item flex-view">
            <div class="label">昵称</div>
            <div class="right-box">
              <div class="input-wrapper">
                <input 
                  type="text" 
                  v-model="tData.form.nickname" 
                  placeholder="请输入昵称" 
                  maxlength="20" 
                  class="input-dom"
                >
                <span class="char-count">{{ tData.form.nickname?.length || 0 }}/20</span>
              </div>
              <p class="tip">支持中英文，长度不能超过 20 个字符</p>
            </div>
          </div>
          
          <!-- 手机号 -->
          <div class="item flex-view">
            <div class="label">手机号</div>
            <div class="right-box">
              <input 
                type="text" 
                v-model="tData.form.mobile" 
                placeholder="请输入手机号" 
                maxlength="11" 
                class="input-dom"
              >
            </div>
          </div>
          
          <!-- 邮箱 -->
          <div class="item flex-view">
            <div class="label">邮箱</div>
            <div class="right-box">
              <input 
                type="email" 
                v-model="tData.form.email" 
                placeholder="请输入邮箱" 
                maxlength="100" 
                class="input-dom"
              >
            </div>
          </div>
          
          <!-- 个人简介 -->
          <div class="item flex-view">
            <div class="label">个人简介</div>
            <div class="right-box">
              <div class="textarea-wrapper">
                <textarea 
                  v-model="tData.form.description" 
                  placeholder="请输入简介" 
                  maxlength="200" 
                  class="intro"
                ></textarea>
                <span class="char-count">{{ tData.form.description?.length || 0 }}/200</span>
              </div>
              <p class="tip">限制200字以内</p>
            </div>
          </div>
          
          <!-- 保存按钮 -->
          <div class="save-wrapper">
            <button class="save-btn" @click="submit()">
              <span class="btn-text">保存设置</span>
              <span class="btn-icon">→</span>
            </button>
          </div>
        </div>
      </div>
    </a-spin>
  </div>
</template>

<script setup>
import { message } from 'ant-design-vue'
import { detailApi, updateUserInfoApi } from '/@/api/user'
import { BASE_URL } from '/@/store/constants'
import AvatarIcon from '/@/assets/images/avatar.jpg'
import { useUserStore } from '/@/store'
import { ref, reactive, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const userStore = useUserStore()
const avatarSrc = computed(() => userStore.user_avatar || AvatarIcon)

let loading = ref(false)
let tData = reactive({
  form:{
    avatar: undefined,
    avatarFile: undefined,
    nickname: undefined,
    email: undefined,
    mobile: undefined,
    description: undefined,
  }
})

onMounted(()=>{
  getUserInfo()
})

const beforeUpload =(file)=> {
  // 改文件名
  const fileName = new Date().getTime().toString() + '.' + file.type.substring(6)
  const copyFile = new File([file], fileName)
  console.log(copyFile)
  tData.form.avatarFile = copyFile
  return false
}

const getUserInfo =()=> {
  loading.value = true
  let userId = userStore.user_id
  detailApi({userId: userId}).then(res => {
    tData.form = res.data
    if (tData.form.avatar) {
        tData.form.avatar = BASE_URL + '/api/staticfiles/avatar/' + tData.form.avatar
        // 更新全局用户头像，方便其他组件使用
      userStore.$patch({ user_avatar: tData.form.avatar })
      localStorage.setItem('user_avatar', tData.form.avatar)
    }
    loading.value = false
  }).catch(err => {
    console.log(err)
    loading.value = false
  })
}
const submit =()=> {
  let formData = new FormData()
  let userId = userStore.user_id
  formData.append('id', userId)
  if (tData.form.avatarFile) {
    formData.append('avatarFile', tData.form.avatarFile)
  }
  if (tData.form.nickname) {
    formData.append('nickname', tData.form.nickname)
  }
  if (tData.form.email) {
    formData.append('email', tData.form.email)
  }
  if (tData.form.mobile) {
    formData.append('mobile', tData.form.mobile)
  }
  if (tData.form.description) {
    formData.append('description', tData.form.description)
  }
  updateUserInfoApi(formData).then(res => {
    message.success('保存成功')
    // 更新全局昵称并持久化
    if (tData.form.nickname) {
      userStore.$patch({ user_name: tData.form.nickname })
      localStorage.setItem('user_name', tData.form.nickname)
    }
    getUserInfo()
  }).catch(err => {
    console.log(err)
  })
}

</script>

<style scoped lang="less">
// 变量定义
@primary-color: #4684e2;
@primary-hover: #3a70c7;
@text-primary: #152844;
@text-secondary: #5f77a9;
@text-tertiary: #8a94b8;
@border-color: #e6e9f0;
@bg-color: #f8fafb;
@bg-hover: #f0f4ff;
@success-color: #52c41a;
@radius-sm: 8px;
@radius-md: 12px;
@radius-lg: 16px;
@shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.08);
@shadow-md: 0 4px 12px rgba(0, 0, 0, 0.1);
@shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.12);
@transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

// 重置样式
input, textarea {
  border: none;
  outline: none;
  margin: 0;
  padding: 0;
  font-family: inherit;
  font-size: inherit;
  color: inherit;
  background: transparent;
  transition: @transition;
  
  &::placeholder {
    color: @text-tertiary;
    opacity: 0.6;
  }
  
  &:focus {
    &::placeholder {
      opacity: 0.4;
    }
  }
}

// 布局工具类
.flex-view {
  display: flex;
  align-items: flex-start;
}

// 主要内容区域
.content-list {
  flex: 1;
  animation: fadeIn 0.6s ease-out;
  
  .list-title {
    color: @text-primary;
    font-weight: 700;
    font-size: 24px;
    line-height: 1.2;
    margin-bottom: 32px;
    padding-bottom: 16px;
    position: relative;
    
    &::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 60px;
      height: 3px;
      background: linear-gradient(90deg, @primary-color, #8fa9ff);
      border-radius: 2px;
    }
  }

  .edit-view {
    background: white;
    border-radius: @radius-lg;
    padding: 40px;
    box-shadow: @shadow-sm;
    border: 1px solid @border-color;
    
    .item {
      padding: 28px 0;
      border-bottom: 1px solid #f0f2f5;
      align-items: flex-start;
      
      &:last-of-type {
        border-bottom: none;
        padding-bottom: 0;
      }
      
      &:first-of-type {
        padding-top: 0;
      }
      
      .label {
        width: 120px;
        flex-shrink: 0;
        color: @text-primary;
        font-weight: 600;
        font-size: 15px;
        padding-top: 12px;
        position: relative;
        
        &::before {
          content: '';
          position: absolute;
          left: -16px;
          top: 16px;
          width: 4px;
          height: 16px;
          background: @primary-color;
          border-radius: 2px;
          opacity: 0;
          transition: @transition;
        }
      }
      
      &:hover .label::before {
        opacity: 1;
      }
      
      .right-box {
        flex: 1;
        min-width: 0;
      }
    }
  }
}

// 头像区域
.avatar-box {
  gap: 32px;
  
  .avatar-wrapper {
    position: relative;
    width: 96px;
    height: 96px;
    flex-shrink: 0;
    
    &:hover {
      .avatar-overlay {
        opacity: 1;
        transform: translateY(0);
      }
      
      .avatar {
        transform: scale(1.05);
      }
    }
    
    .avatar {
      width: 100%;
      height: 100%;
      border-radius: 50%;
      object-fit: cover;
      border: 4px solid white;
      box-shadow: @shadow-md;
      transition: @transition;
    }
    
    .avatar-overlay {
      position: absolute;
      inset: 0;
      background: rgba(0, 0, 0, 0.6);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0;
      transform: translateY(10px);
      transition: @transition;
      cursor: pointer;
      
      span {
        color: white;
        font-size: 14px;
        font-weight: 500;
      }
    }
  }
  
  .change-tips {
    flex-direction: column;
    gap: 8px;
    
    .upload-label {
      color: @primary-color;
      font-size: 15px;
      font-weight: 500;
      cursor: pointer;
      padding: 8px 0;
      transition: @transition;
      
      &:hover {
        color: @primary-hover;
        transform: translateX(4px);
      }
    }
    
    .tip {
      color: @text-secondary;
      font-size: 13px;
      line-height: 1.6;
      margin: 0;
      max-width: 400px;
    }
  }
}

// 输入框样式
.input-wrapper, .textarea-wrapper {
  position: relative;
  
  .input-dom {
    width: 100%;
    max-width: 480px;
    background: @bg-color;
    border-radius: @radius-sm;
    height: 48px;
    line-height: 48px;
    font-size: 15px;
    color: @text-primary;
    padding: 0 16px;
    border: 2px solid transparent;
    
    &:hover {
      background: @bg-hover;
      border-color: fade(@primary-color, 20%);
    }
    
    &:focus {
      background: white;
      border-color: @primary-color;
      box-shadow: 0 0 0 3px fade(@primary-color, 10%);
    }
  }
  
  .char-count {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 12px;
    color: @text-tertiary;
    background: white;
    padding: 2px 8px;
    border-radius: 10px;
  }
}

// 文本域样式
.textarea-wrapper {
  .char-count {
    top: 24px;
    transform: none;
  }
  
  .intro {
    width: 100%;
    max-width: 480px;
    background: @bg-color;
    border-radius: @radius-sm;
    min-height: 120px;
    font-size: 15px;
    line-height: 1.6;
    color: @text-primary;
    padding: 16px;
    resize: vertical;
    border: 2px solid transparent;
    transition: @transition;
    
    &:hover {
      background: @bg-hover;
      border-color: fade(@primary-color, 20%);
    }
    
    &:focus {
      background: white;
      border-color: @primary-color;
      box-shadow: 0 0 0 3px fade(@primary-color, 10%);
    }
  }
}

// 提示文本
.tip {
  font-size: 13px;
  line-height: 1.5;
  color: @text-secondary;
  margin-top: 8px;
  margin-bottom: 0;
}

// 保存按钮
.save-wrapper {
  margin-top: 48px;
  padding-top: 32px;
  border-top: 1px solid @border-color;
  text-align: center;
  
  .save-btn {
    background: linear-gradient(135deg, @primary-color, #5d95ff);
    border-radius: @radius-md;
    padding: 0 32px;
    height: 48px;
    border: none;
    outline: none;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    transition: @transition;
    box-shadow: @shadow-sm;
    position: relative;
    overflow: hidden;
    
    &:hover {
      transform: translateY(-2px);
      box-shadow: @shadow-md;
      
      .btn-icon {
        transform: translateX(4px);
      }
      
      &::before {
        transform: translateX(100%);
      }
    }
    
    &:active {
      transform: translateY(0);
      box-shadow: @shadow-sm;
    }
    
    &::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
      transition: transform 0.6s ease;
    }
    
    .btn-text {
      color: white;
      font-size: 15px;
      font-weight: 600;
      position: relative;
      z-index: 1;
    }
    
    .btn-icon {
      color: white;
      font-size: 18px;
      font-weight: 300;
      position: relative;
      z-index: 1;
      transition: transform 0.3s ease;
    }
  }
}

// 加载动画
:deep(.ant-spin) {
  .ant-spin-dot-item {
    background: @primary-color;
  }
}

// 响应式设计
@media (max-width: 768px) {
  .content-list {
    .list-title {
      font-size: 20px;
      margin-bottom: 24px;
    }
    
    .edit-view {
      padding: 24px;
      
      .item {
        flex-direction: column;
        gap: 16px;
        padding: 24px 0;
        
        .label {
          width: 100%;
          padding-top: 0;
          
          &::before {
            display: none;
          }
        }
      }
    }
  }
  
  .avatar-box {
    flex-direction: column;
    gap: 24px;
    
    .avatar-wrapper {
      width: 80px;
      height: 80px;
    }
  }
  
  .input-wrapper,
  .textarea-wrapper {
    .input-dom,
    .intro {
      max-width: 100%;
    }
  }
  
  .save-wrapper {
    margin-top: 32px;
    padding-top: 24px;
  }
}

</style>
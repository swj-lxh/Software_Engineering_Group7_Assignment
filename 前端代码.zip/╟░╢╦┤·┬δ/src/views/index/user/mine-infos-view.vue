<template>
  <el-card class="mine-infos-view" :body-style="{ padding: '0' }">
    <div class="info-box">
      <div class="left">
        <el-avatar :src="avatarSrc" :size="64" class="avatar-img" />
        <div class="status-badge">在线</div>
      </div>
      <div class="right">
        <h2 class="nick">{{ userStore.user_name || '访客' }}</h2>
        <div class="sub">活跃 1 天 • 等级 LV.3</div>
      </div>
    </div>

    <div class="counts-view">
      <div class="counts">
        <div class="count-item" @click="clickMenu('wishThingView')">
          <div class="label">购物车</div>
          <div class="value">{{ cartCount }}</div>
        </div>
        <div class="count-item" @click="clickMenu('collectThingView')">
          <div class="label">收藏</div>
          <div class="value">{{ collectCount }}</div>
        </div>
        <!-- 原来是 @click="clickMenu('orderView')" -->
        <div class="count-item" @click="goToPendingOrders">
          <div class="label">待处理</div>
          <div class="value">{{ orderPending }}</div>
        </div>
      </div>
    </div>

    <div class="section">
      <div class="section-title">订单中心</div>
      <div class="section-list">
        <div class="mine-item" @click="clickMenu('orderView')">
          <el-image :src="MyOrderImg" class="icon-img" />
          <div class="text">我的订单</div>
        </div>
        <div class="mine-item" @click="clickMenu('commentView')">
          <el-image :src="CommentIconImg" class="icon-img" />
          <div class="text">我的评论</div>
        </div>
        <div class="mine-item" @click="clickMenu('addressView')">
          <el-image :src="AddressIconImage" class="icon-img" />
          <div class="text">地址管理</div>
        </div>
        <!-- 
        <div class="mine-item" @click="clickMenu('scoreView')">
          <el-image :src="PointIconImage" class="icon-img" />
          <div class="text">我的积分</div>
        </div>
          -->
      </div>
    </div>

    <div class="section">
      <div class="section-title">个人设置</div>
      <div class="section-list">
        <div class="mine-item" @click="clickMenu('userInfoEditView')">
          <el-image :src="SettingIconImage" class="icon-img" />
          <div class="text">编辑资料</div>
        </div>
        <div class="mine-item" @click="clickMenu('securityView')">
          <el-image :src="SafeIconImage" class="icon-img" />
          <div class="text">账号安全</div>
        </div>
        <div class="mine-item" @click="clickMenu('pushView')">
          <el-image :src="PushIconImage" class="icon-img" />
          <div class="text">推送设置</div>
        </div>
        <!-- 
        <div class="mine-item" @click="clickMenu('messageView')">
          <el-image :src="MessageIconImage" class="icon-img" />
          <div class="text">消息管理</div>
        </div>
          -->
      </div>
    </div>
  </el-card>
</template>

<script setup lang="ts">
import AvatarImg from '/@/assets/images/avatar.jpg'
import MyOrderImg from '/@/assets/images/order-icon.svg'
import CommentIconImg from '/@/assets/images/order-thing-icon.svg'
import AddressIconImage from '/@/assets/images/order-address-icon.svg'
import PointIconImage from '/@/assets/images/order-point-icon.svg'
import SettingIconImage from '/@/assets/images/setting-icon.svg'
import SafeIconImage from '/@/assets/images/setting-safe-icon.svg'
import PushIconImage from '/@/assets/images/setting-push-icon.svg'
import MessageIconImage from '/@/assets/images/setting-msg-icon.svg'


import { userCollectListApi } from '/@/api/thingCollect'
import { userWishListApi } from '/@/api/thingWish'
import { useUserStore, useCartStore } from '/@/store'
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { fetchPendingOrderCount } from '/@/utils/order-pending'

const userStore = useUserStore()
const router = useRouter()
const avatarSrc = computed(() => userStore.user_avatar || AvatarImg)

const collectCount = ref(0)
const wishCount = ref(0)
const cartStore = useCartStore()
const cartCount = computed(() => cartStore.totalCount)


const orderPending = ref(0)


onMounted(async () => {
  getCollectThingList()
  getWishThingList()
  // 动态获取待处理订单数量
  orderPending.value = await fetchPendingOrderCount()
})

const clickMenu = (name: string) => {
  router.push({ name: name })
}
const goToPendingOrders = () => {
  router.push({ name: 'orderView', query: { tab: '1' } })
}

const getCollectThingList = () => {
  const userId = userStore.user_id
  if (!userId) return
  userCollectListApi({ userId: userId }).then(res => {
    collectCount.value = res.data.length
  }).catch(() => {
    collectCount.value = 0
  })
}

const getWishThingList = () => {
  const userId = userStore.user_id
  if (!userId) return
  userWishListApi({ userId: userId }).then(res => {
    wishCount.value = res.data.length
  }).catch(() => {
    wishCount.value = 0
  })
}
</script>

<style scoped lang="less">
.mine-infos-view {
  width: 280px;
  margin-right: 20px;
  background: linear-gradient(180deg, #ffffff, #fbfdff);
  border-radius: 14px;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(21, 40, 68, 0.06);
  border: 1px solid rgba(220, 230, 242, 0.7);
  transition: transform 0.18s ease, box-shadow 0.2s ease;

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 20px 50px rgba(21, 40, 68, 0.09);
  }

  .info-box {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 18px;
    background: linear-gradient(90deg, rgba(70, 132, 226, 0.06), rgba(13, 110, 253, 0.02));

    .left {
      position: relative;
    }

    .avatar-img {
      border-radius: 50%;
      box-shadow: 0 6px 18px rgba(21, 40, 68, 0.08);
      transition: transform 0.25s ease;
    }

    .avatar-img:hover {
      transform: scale(1.06);
    }

    .status-badge {
      position: absolute;
      right: -6px;
      bottom: -6px;
      background: linear-gradient(135deg, #36d1dc, #5b86e5);
      color: #fff;
      font-size: 11px;
      padding: 4px 8px;
      border-radius: 999px;
      box-shadow: 0 6px 12px rgba(70, 132, 226, 0.12);
    }

    .nick {
      margin: 0;
      font-size: 18px;
      color: #0f2640;
      font-weight: 700;
    }

    .sub {
      color: #7a8693;
      font-size: 12px;
      margin-top: 6px;
    }
  }

  .counts-view {
    padding: 12px;
  }

  .counts {
    display: flex;
    gap: 10px;
    background: #f6fbff;
    padding: 10px;
    border-radius: 10px;
    align-items: center;
    justify-content: space-between;

    .count-item {
      flex: 1;
      text-align: center;
      cursor: pointer;
      padding: 8px 6px;
      border-radius: 8px;
      transition: transform 0.18s ease, background 0.18s ease;
    }

    .count-item:hover {
      transform: translateY(-6px);
      background: rgba(70, 132, 226, 0.04);
    }

    .label {
      color: #6f6f6f;
      font-size: 12px;
    }

    .value {
      color: #0f2640;
      font-weight: 700;
      font-size: 16px;
      margin-top: 6px;
    }
  }

  .section {
    padding: 12px;
    border-top: 1px solid rgba(220, 230, 242, 0.7);
  }

  .section-title {
    font-weight: 700;
    color: #0f2640;
    font-size: 13px;
    margin-bottom: 8px;
  }

  .section-list {
    display: grid;
    gap: 8px;
  }

  .mine-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px;
    border-radius: 10px;
    cursor: pointer;
    transition: transform 0.16s ease, background 0.16s ease;
  }

  .mine-item:hover {
    transform: translateX(6px);
    background: rgba(21, 40, 68, 0.02);
  }

  .icon-img {
    width: 24px;
    height: 24px;
  }

  .text {
    color: #152844;
    font-size: 14px;
  }
}
</style>
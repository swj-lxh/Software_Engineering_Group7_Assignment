<template>
  <div class="content-list">
    <!--    <div class="list-title">我的地址</div>-->
    <div class="list-title">
      <span>地址管理</span>
      <span class="add-new-btn" @click="handleAdd">新建地址</span>
    </div>
    <div class="list-content">
      <div class="address-item flex-view" v-for="item in pageData.addressData">
        <div class="infos">
          <div class="name-box">
            <span class="name">{{item.name}}</span>
            <span class="tel">{{item.mobile}}</span>
          </div>
          <p class="address-box">{{item.description}}</p>
        </div>
        <div class="do-box">
          <div class="btns">
            <span class="edit" @click="handleEdit(item)">编辑</span>
            <a-popconfirm
              title="确定删除？"
              ok-text="是"
              cancel-text="否"
              @confirm="handleDelete(item)"
            >
              <span class="delete">删除</span>
            </a-popconfirm>
          </div>
          <div class="default-box" v-if="item.def==='1'">
            <img :src="AddressIcon">
            <span>默认地址</span>
          </div>
        </div>
      </div>
      <div v-if="pageData.addressData.length === 0" class="no-data">暂无地址，点击“新建地址”添加</div>
    </div>
  </div>
  <!--弹窗区域-->
  <div>
    <a-modal
        :visible="modal.visile"
        :forceRender="true"
        :title="modal.title"
        ok-text="确认"
        cancel-text="取消"
        @cancel="handleCancel"
        @ok="handleOk"
    >
      <div>
        <a-form ref="myform" :label-col="{ style: { width: '80px' } }" :model="modal.form" :rules="modal.rules">
          <a-row :gutter="24">
            <a-col span="24">
              <a-form-item label="姓名" name="name">
                <a-input placeholder="请输入" v-model:value="modal.form.name"></a-input>
              </a-form-item>
            </a-col>
          </a-row>
          <a-row :gutter="24">
            <a-col span="24">
              <a-form-item label="电话号码" name="mobile">
                <a-input placeholder="请输入" v-model:value="modal.form.mobile"></a-input>
              </a-form-item>
            </a-col>
          </a-row>
          <a-row :gutter="24">
            <a-col span="24">
              <a-form-item label="送货地址" name="description">
                <a-input placeholder="请输入" v-model:value="modal.form.description"></a-input>
              </a-form-item>
            </a-col>
          </a-row>
          <a-row :gutter="24">
            <a-col span="24">
              <a-form-item label="默认地址">
                <a-switch v-model:checked="modal.form.default"></a-switch>
              </a-form-item>
            </a-col>
          </a-row>
        </a-form>
      </div>
    </a-modal>
  </div>
</template>

<script setup lang="ts">
import {FormInstance, message} from 'ant-design-vue';
import {listApi, deleteApi} from '/@/api/address'
import {createApi, updateApi} from "/@/api/address";
import {useUserStore} from "/@/store";
import AddressIcon from '/@/assets/images/address-right-icon.svg';

const userStore = useUserStore();

// 类型定义，避免空数组和对象被推断为 `never`
type Address = {
  id?: string | number;
  name?: string;
  mobile?: string;
  description?: string;
  def?: string; // 后端里可能使用 'def' 字段表示默认地址 '1'/'0'
  image?: string;
}

type ModalForm = Record<string, any> & {
  id?: string | number;
  name?: string;
  mobile?: string;
  description?: string;
  default?: boolean;
  image?: any;
}

// 页面数据
const pageData = reactive({
  addressData: [] as Address[]
})

// 弹窗数据源
const modal = reactive<{ visile: boolean; editFlag: boolean; title: string; form: ModalForm; rules: any }>({
  visile: false,
  editFlag: false,
  title: '',
  form: {
    id: undefined,
    name: undefined,
    mobile: undefined,
    description: undefined,
    default: false,
    image: undefined,
  },
  rules: {
    link: [{required: true, message: '请输入', trigger: 'change'}],
  },
});

const myform = ref<FormInstance>();

onMounted(()=> {
  listAddressData()
})

const listAddressData = ()=> {
  let userId = userStore.user_id
  listApi({userId: userId}).then(res => {
    pageData.addressData = res.data
  }).catch(err => {
    console.log(err)
  })
}

const handleDelete =(item)=> {
  deleteApi({ids: item.id}).then(res => {
    listAddressData()
  }).catch(err => {
    console.log(err)
  })
};

const handleAdd = () => {
  resetModal();
  modal.visile = true;
  modal.editFlag = false;
  modal.title = '新增';
  // 重置
  for (const key in modal.form) {
    modal.form[key] = undefined;
  }
  modal.form.image = undefined
};
const handleEdit = (record: any) => {
  resetModal();
  modal.visile = true;
  modal.editFlag = true;
  modal.title = '编辑';
  // 重置
  for (const key in modal.form) {
    modal.form[key] = undefined;
  }
  for (const key in record) {
    modal.form[key] = record[key];
  }
  modal.form.image = undefined
};

const handleOk = () => {
  myform.value?.validate()
      .then(() => {
        const formData = new FormData()
        formData.append('userId', String(userStore.user_id))
        formData.append('def', modal.form.default ? '1' : '0')
        if (modal.form.id != null) {
          formData.append('id', String(modal.form.id))
        }
        if (modal.form.name != null) {
          formData.append('name', String(modal.form.name))
        }
        if (modal.form.mobile != null) {
          formData.append('mobile', String(modal.form.mobile))
        }
        if (modal.form.description != null) {
          formData.append('description', String(modal.form.description))
        }

        if (modal.editFlag) {
          updateApi(formData)
              .then((res) => {
                hideModal();
                listAddressData()
              })
              .catch((err) => {
                console.log(err);
              });
        } else {
          createApi(formData)
              .then((res) => {
                hideModal();
                listAddressData()
              })
              .catch((err) => {
                console.log(err);
              });
        }
      })
      .catch((err) => {
        console.log('不能为空');
      });
};

const handleCancel = () => {
  hideModal();
};

// 恢复表单初始状态
const resetModal = () => {
  myform.value?.resetFields();
};

// 关闭弹窗
const hideModal = () => {
  modal.visile = false;
};

</script>
<style scoped lang="less">
progress {
  vertical-align: baseline;
}

.flex-view {
  display: flex;
}

input, textarea {
  outline: none;
  border-style: none;
}

button {
  padding: 0;
}

.content-list {
  flex: 1;

  .list-title {
    color: #152844;
    font-weight: 600;
    font-size: 18px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 12px;
    margin-bottom: 12px;
    border-bottom: 1px solid #cedce4;
  }
  .add-new-btn {
    color: #4684e2;
    font-size: 14px;
    font-weight: 400;
    cursor: pointer;
    padding: 6px 12px;
    border-radius: 6px;
    background: rgba(70,132,226,0.06);
  }
}

.no-data {
  padding: 28px 16px;
  text-align: center;
  color: #909399;
  background: #fff;
  border: 1px dashed #e6eef8;
  border-radius: 8px;
  margin-top: 8px;
}

.address-item {
  background: #f7f9fb;
  border-radius: 4px;
  margin-bottom: 12px;
  -webkit-box-pack: justify;
  -ms-flex-pack: justify;
  justify-content: space-between;
  padding: 16px;
  position: relative;

    .infos {
      flex: 1;
      min-width: 0;/* allow truncation inside flex item */
      padding-right: 140px; /* 留出右侧按钮区域，防止文字覆盖 */
    }

  .name-box {
    color: #152844;
    font-weight: 500;
    font-size: 14px;
    line-height: 22px;
    height: 22px;
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .name {
    margin-right: 16px;
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .tel {
    flex-shrink: 0;
    color: #606266;
    font-size: 13px;
    white-space: nowrap;
  }

  .address-box {
    color: #484848;
    font-size: 14px;
    line-height: 22px;
    height: 22px;
    margin-top: 4px;
  }

  .btns {
    font-size: 14px;
    cursor: pointer;
    height: 22px;
    line-height: 22px;
    display: flex;
    gap: 8px;
    align-items: center;
  }

  .edit {
    color: #4684e2;
    margin-right: 0;
  }

  .delete {
    color: #f62a2a;
  }

  .default-box {
    margin-top: 4px;
    display: flex;
    align-items: center;
    gap: 6px;

    img {
      width: 16px;
      height: 16px;
      display: inline-block;
    }

    span {
      color: #6f6f6f;
      font-size: 14px;
      vertical-align: middle;
    }
  }

  .do-box {
    position: absolute;
    top: 12px;
    right: 12px;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 6px;
  }
}
</style>

<template>
  <div class="content-list">
    <div class="list-title">推送设置</div>
    <div class="list-content">
      <div class="push-view">
        <!-- 设置卡片 -->
        <div class="settings-card">
          <div class="settings-header">
            <div class="header-icon">📬</div>
            <div class="header-content">
              <h3 class="header-title">邮件通知设置</h3>
              <p class="header-subtitle">自定义您的邮件推送偏好设置</p>
            </div>
          </div>
          
          <!-- 表单内容 -->
          <div class="settings-form">
            <!-- 推送邮箱 -->
            <div class="form-item">
              <div class="form-label">
                <span class="label-icon">✉️</span>
                <span class="label-text">推送邮箱</span>
                <span class="label-hint">（接收通知的邮箱地址）</span>
              </div>
              <div class="form-control">
                <div class="email-input-wrapper">
                  <div class="input-prefix">
                    <span class="prefix-icon">📧</span>
                  </div>
                  <input 
                    type="email" 
                    class="input-dom" 
                    placeholder="请输入有效的邮箱地址" 
                    v-model="pushEmail"
                    :class="{ 'input-error': showEmailError }"
                  >
                  <div class="input-suffix" v-if="pushEmail">
                    <span class="valid-icon" :class="{ valid: isEmailValid }">
                      {{ isEmailValid ? '✓' : '!' }}
                    </span>
                  </div>
                </div>
                <div class="input-hint" v-if="showEmailError">
                  <span class="hint-icon">⚠️</span>
                  <span class="hint-text">请输入正确的邮箱格式</span>
                </div>
                <div class="input-tip" v-else>
                  我们将发送重要通知和提醒到此邮箱
                </div>
              </div>
            </div>
            
            <!-- 开关设置 -->
            <div class="form-item">
              <div class="form-label">
                <span class="label-icon">🔔</span>
                <span class="label-text">接受邮件消息</span>
              </div>
              <div class="form-control">
                <div class="switch-container">
                  <div class="switch-label-group">
                    <div class="switch-description">
                      开启后，您将收到系统通知、更新提醒等邮件
                    </div>
                    <div class="switch-status" :class="{ active: pushSwitch }">
                      {{ pushSwitch ? '已开启' : '已关闭' }}
                    </div>
                  </div>
                  <div class="switch-wrapper">
                    <a-switch 
                      v-model:checked="pushSwitch"
                      :checkedValue="true"
                      :unCheckedValue="false"
                      class="custom-switch"
                      :class="{ checked: pushSwitch }"
                    />
                    <div class="switch-label" @click="pushSwitch = !pushSwitch">
                      {{ pushSwitch ? 'ON' : 'OFF' }}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- 通知类型示例 -->
            <div class="notification-types" v-if="pushSwitch">
              <div class="types-title">您将接收的通知类型：</div>
              <div class="types-grid">
                <div class="type-item">
                  <div class="type-icon">📊</div>
                  <div class="type-content">
                    <div class="type-title">系统通知</div>
                    <div class="type-desc">系统维护、功能更新</div>
                  </div>
                </div>
                <div class="type-item">
                  <div class="type-icon">🔐</div>
                  <div class="type-content">
                    <div class="type-title">安全提醒</div>
                    <div class="type-desc">账号安全相关通知</div>
                  </div>
                </div>
                <div class="type-item">
                  <div class="type-icon">📱</div>
                  <div class="type-content">
                    <div class="type-title">产品更新</div>
                    <div class="type-desc">新功能上线通知</div>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- 保存按钮 -->
            <div class="form-actions">
              <button 
                class="save-btn" 
                @click="handleSave()"
                :disabled="!isFormValid"
                :class="{ 'btn-loading': saving }"
              >
                <span class="btn-content">
                  <span class="btn-icon" v-if="!saving">💾</span>
                  <span class="btn-icon loading" v-else>⏳</span>
                  <span class="btn-text">{{ saving ? '保存中...' : '保存设置' }}</span>
                </span>
              </button>
              <div class="save-hint" v-if="lastSaveTime">
                上次保存时间：{{ lastSaveTime }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { message } from "ant-design-vue";
import { detailApi, updateUserInfoApi } from '/@/api/user'
import { useUserStore } from "/@/store";
import { ref, onMounted, computed } from 'vue'

const router = useRouter();
const userStore = useUserStore();

let pushEmail = ref('')
let pushSwitch = ref(false)
let saving = ref(false)
let lastSaveTime = ref('')
let showEmailError = ref(false)

const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9_]+\@[a-zA-Z0-9]+\.[a-zA-Z]{2,5}(\.[a-zA-Z]{2,5})*$/i

const isEmailValid = computed(() => {
  return pushEmail.value && emailRegex.test(pushEmail.value)
})

const isFormValid = computed(() => {
  return isEmailValid.value
})

onMounted(() => {
  getUserInfo()
})

const getUserInfo = () => {
  let userId = userStore.user_id

  detailApi({ userId: userId }).then(res => {
    if (res.data) {
      pushEmail.value = res.data.pushEmail
      if (res.data.pushSwitch === '1') {
        pushSwitch.value = true
      }
    }
  }).catch(err => {
    console.log(err)
  })
}

const handleSave = () => {
  showEmailError.value = false
  
  if (!pushEmail.value.match(emailRegex)) {
    message.warn('请输入正确的邮箱格式')
    showEmailError.value = true
    return
  }

  saving.value = true
  let userId = userStore.user_id
  const formData = new FormData()
  formData.append("id", userId)
  
  if (pushEmail.value) {
    formData.append('pushEmail', pushEmail.value)
  }
  
  formData.append('pushSwitch', pushSwitch.value ? '1' : '0')
  
  updateUserInfoApi(formData).then(res => {
    getUserInfo()
    message.success('设置保存成功！')
    
    // 更新最后保存时间
    const now = new Date()
    lastSaveTime.value = now.toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    })
    
    // 显示保存成功动画
    setTimeout(() => {
      saving.value = false
    }, 500)
    
  }).catch(err => {
    console.log(err)
    saving.value = false
    message.error('保存失败，请重试')
  })
}
</script>

<style scoped lang="less">
// 变量定义
@primary-color: #4684e2;
@primary-hover: #3a70c7;
@success-color: #52c41a;
@warning-color: #faad14;
@error-color: #ff4d4f;
@text-primary: #152844;
@text-secondary: #5f77a9;
@text-tertiary: #8a94b8;
@border-color: #e6e9f0;
@bg-color: #f8fafb;
@bg-hover: #f0f4ff;
@card-bg: #ffffff;
@switch-on: #52c41a;
@switch-off: #dcdfe6;
@shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.06);
@shadow-md: 0 4px 12px rgba(0, 0, 0, 0.08);
@shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.1);
@radius-sm: 8px;
@radius-md: 12px;
@radius-lg: 16px;
@radius-xl: 24px;
@transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

// 重置样式
input, button {
  border: none;
  outline: none;
  font-family: inherit;
  transition: @transition;
}

.flex-view {
  display: flex;
}

// 主要内容区域
.content-list {
  flex: 1;
  
  .list-title {
    color: @text-primary;
    font-weight: 700;
    font-size: 24px;
    line-height: 1.2;
    margin-bottom: 32px;
    padding-bottom: 16px;
    position: relative;
    
    &::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 60px;
      height: 3px;
      background: linear-gradient(90deg, @primary-color, #8fa9ff);
      border-radius: 2px;
    }
  }
}

// 设置卡片
.settings-card {
  background: @card-bg;
  border-radius: @radius-lg;
  padding: 40px;
  box-shadow: @shadow-sm;
  border: 1px solid @border-color;
  max-width: 800px;
  margin: 0 auto;
}

// 卡片头部
.settings-header {
  display: flex;
  align-items: center;
  gap: 20px;
  margin-bottom: 40px;
  padding-bottom: 24px;
  border-bottom: 1px solid @border-color;
  
  .header-icon {
    font-size: 48px;
    background: linear-gradient(135deg, @primary-color, #8fa9ff);
    width: 80px;
    height: 80px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    box-shadow: @shadow-md;
  }
  
  .header-content {
    flex: 1;
    
    .header-title {
      color: @text-primary;
      font-size: 28px;
      font-weight: 700;
      margin: 0 0 8px 0;
      background: linear-gradient(135deg, @primary-color, #764ba2);
      -webkit-text-fill-color: transparent;
    }
    
    .header-subtitle {
      color: @text-secondary;
      font-size: 15px;
      margin: 0;
    }
  }
}

// 表单项目
.settings-form {
  .form-item {
    margin-bottom: 40px;
    padding: 24px;
    background: @bg-color;
    border-radius: @radius-md;
    border: 2px solid transparent;
    transition: @transition;
    
    &:hover {
      border-color: fade(@primary-color, 20%);
      background: @bg-hover;
    }
    
    &:last-child {
      margin-bottom: 0;
    }
  }
  
  .form-label {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 20px;
    
    .label-icon {
      font-size: 24px;
    }
    
    .label-text {
      color: @text-primary;
      font-size: 18px;
      font-weight: 600;
    }
    
    .label-hint {
      color: @text-tertiary;
      font-size: 14px;
    }
  }
  
  .form-control {
    margin-left: 36px;
  }
}

// 邮箱输入框
.email-input-wrapper {
  position: relative;
  display: flex;
  align-items: center;
  background: white;
  border-radius: @radius-sm;
  border: 2px solid @border-color;
  transition: @transition;
  overflow: hidden;
  
  &:hover {
    border-color: fade(@primary-color, 40%);
  }
  
  &:focus-within {
    border-color: @primary-color;
    box-shadow: 0 0 0 3px fade(@primary-color, 10%);
  }
  
  &.input-error {
    border-color: @error-color;
    
    &:focus-within {
      box-shadow: 0 0 0 3px fade(@error-color, 10%);
    }
  }
  
  .input-prefix {
    padding: 0 16px;
    border-right: 1px solid @border-color;
    height: 56px;
    display: flex;
    align-items: center;
    
    .prefix-icon {
      font-size: 20px;
      color: @text-secondary;
    }
  }
  
  .input-dom {
    flex: 1;
    height: 56px;
    padding: 0 16px;
    font-size: 16px;
    color: @text-primary;
    background: transparent;
    
    &::placeholder {
      color: @text-tertiary;
      opacity: 0.6;
    }
  }
  
  .input-suffix {
    padding: 0 16px;
    
    .valid-icon {
      width: 24px;
      height: 24px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      font-weight: bold;
      color: white;
      
      &.valid {
        background: @success-color;
      }
      
      &:not(.valid) {
        background: @error-color;
      }
    }
  }
}

// 输入提示
.input-hint {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 12px;
  color: @error-color;
  font-size: 14px;
  
  .hint-icon {
    font-size: 16px;
  }
}

.input-tip {
  margin-top: 12px;
  color: @text-tertiary;
  font-size: 13px;
}

// 开关设置
.switch-container {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  
  .switch-label-group {
    flex: 1;
    
    .switch-description {
      color: @text-secondary;
      font-size: 14px;
      line-height: 1.5;
      margin-bottom: 8px;
    }
    
    .switch-status {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 500;
      background: fade(@switch-off, 20%);
      color: @text-tertiary;
      
      &.active {
        background: fade(@success-color, 10%);
        color: @success-color;
      }
    }
  }
  
  .switch-wrapper {
    display: flex;
    align-items: center;
    gap: 12px;
    
    .custom-switch {
      &.ant-switch {
        min-width: 52px;
        height: 28px;
        background: @switch-off;
        
        &.ant-switch-checked {
          background: @switch-on;
        }
        
        .ant-switch-handle {
          top: 2px;
          left: 2px;
          width: 24px;
          height: 24px;
          
          &::before {
            border-radius: 50%;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
          }
        }
        
        &.ant-switch-checked .ant-switch-handle {
          left: calc(100% - 24px - 2px);
        }
      }
    }
    
    .switch-label {
      font-size: 14px;
      font-weight: 600;
      color: @text-secondary;
      cursor: pointer;
      transition: @transition;
      min-width: 32px;
      
      &:hover {
        color: @primary-color;
      }
    }
  }
}

// 通知类型
.notification-types {
  margin-top: 32px;
  padding: 24px;
  background: fade(@primary-color, 5%);
  border-radius: @radius-md;
  border: 1px solid fade(@primary-color, 10%);
  
  .types-title {
    color: @text-primary;
    font-weight: 600;
    font-size: 16px;
    margin-bottom: 20px;
  }
  
  .types-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    
    .type-item {
      display: flex;
      align-items: center;
      gap: 16px;
      padding: 16px;
      background: white;
      border-radius: @radius-sm;
      border: 1px solid @border-color;
      transition: @transition;
      
      &:hover {
        transform: translateY(-2px);
        box-shadow: @shadow-sm;
        border-color: fade(@primary-color, 30%);
      }
      
      .type-icon {
        font-size: 32px;
        width: 56px;
        height: 56px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: fade(@primary-color, 10%);
        color: @primary-color;
      }
      
      .type-content {
        flex: 1;
        
        .type-title {
          color: @text-primary;
          font-weight: 600;
          font-size: 15px;
          margin-bottom: 4px;
        }
        
        .type-desc {
          color: @text-tertiary;
          font-size: 13px;
        }
      }
    }
  }
}

// 保存按钮区域
.form-actions {
  margin-top: 48px;
  padding-top: 32px;
  border-top: 1px solid @border-color;
  text-align: center;
  
  .save-btn {
    background: linear-gradient(135deg, @primary-color, #5d95ff);
    border-radius: @radius-md;
    padding: 0 40px;
    height: 56px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    color: white;
    font-size: 16px;
    font-weight: 600;
    border: none;
    cursor: pointer;
    box-shadow: @shadow-sm;
    position: relative;
    overflow: hidden;
    transition: @transition;
    
    &:hover:not(:disabled) {
      transform: translateY(-2px);
      box-shadow: @shadow-md;
      
      .btn-icon {
        transform: scale(1.1);
      }
    }
    
    &:active:not(:disabled) {
      transform: translateY(0);
      box-shadow: @shadow-sm;
    }
    
    &:disabled {
      opacity: 0.6;
      cursor: not-allowed;
      transform: none !important;
    }
    
    &.btn-loading {
      .btn-icon.loading {
        animation: spin 1s linear infinite;
      }
    }
    
    &::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
      transition: transform 0.6s ease;
    }
    
    &:hover::before {
      transform: translateX(200%);
    }
    
    .btn-content {
      display: flex;
      align-items: center;
      gap: 8px;
      position: relative;
      z-index: 1;
    }
    
    .btn-icon {
      font-size: 20px;
      transition: transform 0.3s ease;
    }
  }
  
  .save-hint {
    margin-top: 16px;
    color: @text-tertiary;
    font-size: 13px;
  }
}

// 动画 - 只保留必要的加载动画
@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

// 响应式设计
@media (max-width: 768px) {
  .content-list {
    .list-title {
      font-size: 20px;
      margin-bottom: 24px;
    }
  }
  
  .settings-card {
    padding: 24px;
  }
  
  .settings-header {
    flex-direction: column;
    text-align: center;
    gap: 16px;
    
    .header-icon {
      width: 64px;
      height: 64px;
      font-size: 32px;
    }
    
    .header-title {
      font-size: 24px;
    }
  }
  
  .form-item {
    padding: 16px !important;
  }
  
  .form-label {
    flex-direction: column;
    align-items: flex-start !important;
    gap: 8px !important;
  }
  
  .form-control {
    margin-left: 0 !important;
  }
  
  .switch-container {
    flex-direction: column;
    align-items: stretch;
    gap: 16px;
  }
  
  .types-grid {
    grid-template-columns: 1fr !important;
  }
  
  .save-btn {
    width: 100%;
  }
}
</style>
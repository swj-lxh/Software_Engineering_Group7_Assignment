<template>
  <div class="message-view">
    <h2 class="page-title">我的消息</h2>
    <el-skeleton :loading="loading" animated :rows="5" style="min-height: 200px;">
      <div class="message-list" v-if="msgData.length > 0">
        <div class="message-item" v-for="item in msgData" :key="item.id">
          <el-avatar :size="32" :src="avatarUrl" />
          <div class="message-content">
            <div class="message-header">
              <span class="message-title">{{ item.title }}</span>
              <span class="message-time">{{ formatDate(item.create_time) }}</span>
            </div>
            <div class="message-body">
              <p>{{ item.content }}</p>
            </div>
          </div>
        </div>
      </div>
      <el-empty v-else description="暂无消息" />
    </el-skeleton>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { listApi } from '/@/api/notice'

const loading = ref(false)
const msgData = ref([])
const avatarUrl = 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'

onMounted(() => {
  getMessageList()
})

const getMessageList = () => {
  loading.value = true
  listApi().then(res => {
    msgData.value = res.data
    loading.value = false
  }).catch(err => {
    console.log(err)
    loading.value = false
  })
}

const formatDate = (dateString) => {
  if (!dateString) return ''
  const date = new Date(dateString)
  return date.toLocaleDateString() + ' ' + date.toLocaleTimeString()
}
</script>

<style scoped lang="less">
.message-view {
  padding: 24px;
  background: #f5f7fb;
  min-height: 260px;

  .page-title {
    color: #152844;
    font-weight: 700;
    font-size: 20px;
    margin-bottom: 16px;
  }

  .message-list {
    background: #ffffff;
    border-radius: 12px;
    padding: 12px;
    box-shadow: 0 6px 18px rgba(18,52,86,0.06);
    transition: box-shadow 0.2s ease;

    .message-item {
      display: flex;
      gap: 16px;
      padding: 14px 12px;
      border-radius: 10px;
      align-items: flex-start;
      transition: transform 0.18s ease, box-shadow 0.18s ease;

      &:not(:last-child) {
        margin-bottom: 10px;
      }

      &:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 20px rgba(18,52,86,0.08);
      }

      .el-avatar {
        border-radius: 8px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.06);
        flex-shrink: 0;
      }

      .message-content {
        flex: 1;

        .message-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 8px;

          .message-title {
            color: #1f3a63;
            font-weight: 600;
            font-size: 15px;
            line-height: 1.2;
            max-width: 75%;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }

          .message-time {
            color: #98a4b8;
            font-size: 12px;
            white-space: nowrap;
          }
        }

        .message-body {
          p {
            margin: 0;
            color: #475569;
            font-size: 14px;
            line-height: 1.6;
            max-height: 3.6em;
            overflow: hidden;
            text-overflow: ellipsis;
          }
        }
      }
    }

    /* 空状态居中 */
    :deep(.el-empty) {
      padding: 36px 0;
    }
  }
}
</style>
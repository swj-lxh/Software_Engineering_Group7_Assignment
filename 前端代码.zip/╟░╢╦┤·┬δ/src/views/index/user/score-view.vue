<template>
  <div class="score-view">
    <div class="score-header">
      <h2 class="page-title">我的积分</h2>
    </div>

    <div class="score-content">
      <el-card class="score-card" shadow="hover">
        <div class="score-info">
          <div class="score-icon">
            <i class="el-icon-coin"></i>
          </div>
          <div class="score-balance">
            <div class="balance-title">积分余额：</div>
            <div class="balance-amount">{{ score }}</div>
          </div>
        </div>
        <div class="view-details">
          <el-button type="text" @click="goToScoreDetails">查看积分明细</el-button>
        </div>
      </el-card>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '/@/store'
import { detailApi } from '/@/api/user'

const router = useRouter()
const userStore = useUserStore()

let score = ref(0)

onMounted(() => {
  getUserInfo()
})

const getUserInfo = () => {
  const userId = userStore.user_id
  detailApi({ userId }).then(res => {
    if (res.data) {
      score.value = res.data.score
    }
  }).catch(err => {
    console.error(err)
  })
}

const goToScoreDetails = () => {
  router.push({ name: 'scoreDetails' }) // 假设存在一个名为 'scoreDetails' 的路由
}
</script>

<style scoped lang="less">
.score-view {
  padding: 20px;
  max-width: 500px;
  margin: 0 auto;

  .score-header {
    background: #fff;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);

    .page-title {
      color: #152844;
      font-weight: 600;
      font-size: 20px;
      margin: 0;
    }
  }

  .score-content {
    .score-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: space-between;
      padding: 20px;
      border-radius: 8px;
      border: none;
      box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);

      .score-info {
        display: flex;
        align-items: center;
        gap: 16px;

        .score-icon {
          font-size: 36px;
          color: #409eff;
        }

        .score-balance {
          display: flex;
          flex-direction: column;
          gap: 4px;

          .balance-title {
            font-size: 16px;
            color: #606266;
          }

          .balance-amount {
            font-size: 24px;
            font-weight: bold;
            color: #303133;
          }
        }
      }

      .view-details {
        margin-top: 20px;

        .el-button {
          font-size: 14px;
          color: #409eff;
          text-decoration: underline;
          &:hover {
            color: #66b1ff;
          }
        }
      }
    }
  }
}
</style>
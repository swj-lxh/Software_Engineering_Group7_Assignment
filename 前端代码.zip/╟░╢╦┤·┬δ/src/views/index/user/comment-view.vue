<template>
  <div class="comment-view">
    <div class="comment-header">
      <h2 class="page-title">我的评论</h2>
    </div>

    <div class="comment-list">
      <el-card
        class="comment-card"
        v-for="(item, index) in commentData"
        :key="index"
        shadow="hover"
      >
        <div class="comment-header-info">
          <div class="comment-meta">
            <span class="thing-title" @click="handleClickTitle(item)" title="点击查看原文">
              《{{ item.title }}》
            </span>
            <span class="comment-time">{{ getFormatTime(item.commentTime, true) }}</span>
          </div>
        </div>

        <div class="comment-content">
          <div class="product-preview">
            <el-image
              :src="item.cover"
              class="cover-image"
              fit="cover"
              lazy
            />
            <div class="comment-text">
              {{ item.content }}
            </div>
          </div>
        </div>
      </el-card>

      <el-empty v-if="commentData.length === 0 && !loading" description="暂无评论" />
    </div>

    <a-spin :spinning="loading" style="display: none;" />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { useRouter } from 'vue-router'
import { useUserStore } from '/@/store'
import { listUserCommentsApi } from '/@/api/comment'
import { BASE_URL } from '/@/store/constants'
import { getFormatTime } from '/@/utils'

const router = useRouter()
const userStore = useUserStore()

const loading = ref(false)
const commentData = ref([])

onMounted(() => {
  getCommentList()
})

const handleClickTitle = (record) => {
  const resolved = router.resolve({ name: 'detail', query: { id: record.thingId } })
  window.open(resolved.href, '_blank')
}

const getCommentList = () => {
  loading.value = true
  const userId = userStore.user_id

  listUserCommentsApi({ userId })
    .then((res) => {
      commentData.value = res.data.map((item) => ({
        ...item,
        cover: item.cover ? `${BASE_URL}/api/staticfiles/image/${item.cover}` : ''
      }))
      loading.value = false
    })
    .catch((err) => {
      ElMessage.error(err.msg || '获取评论失败')
      loading.value = false
    })
}
</script>

<style scoped lang="less">
.comment-view {
  padding: 20px;
  max-width: 1100px;
  margin: 0 auto;

  .comment-header {
    background: #fff;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);

    .page-title {
      color: #152844;
      font-weight: 600;
      font-size: 20px;
      margin: 0;
    }
  }

  .comment-list {
    /* 👇 改为 grid 布局，支持自动换行 */
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(400px, 1fr)); /* 每列最小 400px */
    gap: 20px;

    .comment-card {
      /* 👇 移除固定 width 和 flex 属性 */
      width: 100%; /* 让卡片自适应网格单元格 */
      border-radius: 8px;
      border: 1px solid #ebeef5;
      margin-bottom: 0;

      .comment-header-info {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-bottom: 12px;
        margin-bottom: 12px;
        border-bottom: 1px solid #ebeef5;

        .comment-meta {
          display: flex;
          flex-direction: column;
          gap: 4px;

          .thing-title {
            font-weight: 500;
            color: #1890ff;
            cursor: pointer;
            transition: color 0.2s;
            font-size: 15px;

            &:hover {
              color: #40a9ff;
              text-decoration: underline;
            }
          }

          .comment-time {
            color: #909399;
            font-size: 13px;
          }
        }
      }

      .comment-content {
        .product-preview {
          display: flex;
          gap: 15px;

          .cover-image {
            width: 70px;
            height: 70px;
            border-radius: 4px;
            background-color: #f5f7fa;
            flex-shrink: 0;
          }

          .comment-text {
            flex: 1;
            font-size: 14px;
            line-height: 1.5;
            color: #303133;
            word-break: break-word;
            white-space: pre-wrap;
          }
        }
      }
    }

    :deep(.el-empty) {
      grid-column: 1 / -1; /* 占满整行 */
      padding: 40px 0;
      text-align: center;
    }
  }
}

@media (max-width: 768px) {
  .comment-view {
    padding: 10px;

    .comment-header {
      padding: 15px;
    }

    .comment-list {
      display: block;

      .comment-card {
        width: 100% !important;
        margin-bottom: 20px;

        .comment-header-info {
          flex-direction: column;
          align-items: flex-start;
          gap: 8px;
        }

        .comment-content {
          .product-preview {
            flex-direction: column;
            gap: 12px;

            .cover-image {
              width: 100%;
              height: 120px;
            }
          }
        }
      }
    }
  }
}
</style>
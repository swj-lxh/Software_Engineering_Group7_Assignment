<template>
  <div class="content-list">
    <div class="list-title">关于我们</div>
    <div class="doc-content">
        <div class="doc-card">
          <div class="card-header">
            <div class="header-icon">🏢</div>
            <div class="header-text">
              <div class="header-title">关于平台</div>
              <div class="header-sub">打造友好的联想商城</div>
            </div>
          </div>

          <div class="card-body">
            <div class="doc-section intro">
              <p>本项目用于2025秋软件工程7组项目大作业，由所有人共同完成</p>
            </div>

            <div class="doc-section">
              <h4 class="section-title">开发团队</h4>
              <ul class="team-list">
                <li v-for="member in teamMembers" :key="member.id" class="team-member">
                  <div class="member-info">
                    <div class="member-name">{{ member.name }}</div>
                    <div class="member-role">{{ member.role }}</div>
                  </div>
                </li>
              </ul>
            </div>

            <div class="doc-section">
              <h4 class="section-title">联系方式</h4>
              <div class="contact-info">
                <div class="contact-item">
                  <span class="contact-label">邮箱：</span>
                  <span class="contact-value">shiweijie@stu.ouc.edu.cn</span>
                </div>
                <div class="contact-item">
                  <span class="contact-label">电话：</span>
                  <span class="contact-value">15854232279</span>
                </div>
                <div class="contact-item">
                  <span class="contact-label">地址：</span>
                  <span class="contact-value">山东省青岛市西海岸新区三沙路1299号</span>
                </div>
              </div>
            </div>

            <div class="doc-section">
              <h4 class="section-title">版权信息</h4>
              <p class="copyright">© 2025 本平台保留所有权利 | 京ICP备12345678号</p>
            </div>
          </div>
        </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

// 团队成员数据
const teamMembers = ref([
  { id: 1, name: '时伟杰', role: '前端技术负责人' },
  { id: 2, name: '郭长挺', role: '后端技术负责人' },
  { id: 3, name: '向潇强', role: '后端与前端对接' },
  { id: 4, name: '崔文军', role: '数据库设计与修改' },
  { id: 5, name: '郑大川', role: '负责项目进度管理、联系开发方、需求方' },
  { id: 6, name: '王硕冉', role: '负责系统测试' },
])
</script>

<style scoped lang="less">
.content-list {
  flex: 1;
  padding: 20px;

  .list-title {
    color: #152844;
    font-weight: 600;
    font-size: 18px;
    height: 48px;
    margin-bottom: 20px;
    border-bottom: 1px solid #cedce4;
  }
}

.doc-content {
  color: #484848;
  line-height: 1.8;

  .doc-card {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 8px 20px rgba(21,40,68,0.08);
    overflow: hidden;
    animation: fadeInUp .45s ease both;
  }

  .card-header {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 18px 22px;
    background: linear-gradient(90deg, #1565c0 0%, #1e88e5 100%);
    color: #fff;
  }

  .header-icon{
    width:48px;
    height:48px;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:22px;
    background: rgba(255,255,255,0.12);
    border-radius:8px;
  }

  .header-title{ font-weight:700; font-size:16px }
  .header-sub{ font-size:12px; opacity:.95 }

  .card-body{ padding:18px 22px }

  .doc-section{ margin-bottom:20px }
  .doc-section.intro{ margin-top:6px }

  .section-title{
    color:#152844; font-size:15px; font-weight:700; margin-bottom:10px
  }

  .team-list{
    display:grid;
    grid-template-columns:repeat(auto-fit, minmax(180px, 1fr));
    gap:12px;
    list-style:none;
    padding:0;
    margin:0;
  }

  .team-member{
    background:#f3f8ff;
    border-radius:8px;
    padding:14px;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    
    &:hover{
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(21,101,192,0.1);
    }
  }

  .member-name{
    font-weight:700;
    color:#1565c0;
    margin-bottom:4px;
    font-size:14px;
  }

  .member-role{
    font-size:13px;
    color:#5f77a6;
  }

  .contact-info{
    display:flex;
    flex-direction:column;
    gap:8px;
  }

  .contact-item{
    display:flex;
    align-items:center;
    gap:8px;
  }

  .contact-label{
    min-width:50px;
    color:#152844;
    font-weight:600;
    font-size:14px;
  }

  .contact-value{
    color:#495057;
    font-size:14px;
  }

  .copyright{
    color:#666;
    font-size:13px;
    margin:6px 0;
  }

  p{ margin:6px 0; color:#495057 }

  @keyframes fadeInUp{ 
    from{ opacity:0; transform:translateY(8px) } 
    to{ opacity:1; transform:none } 
  }

  @media (max-width:720px){
    .team-list{ grid-template-columns:1fr }
    .card-body{ padding:14px }
    .contact-item{ flex-direction:column; align-items:flex-start; gap:2px }
  }
}
</style>
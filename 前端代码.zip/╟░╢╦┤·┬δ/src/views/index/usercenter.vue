<template>
  <div class="user">
    <div class="user-content">
      <div class="user-content-left">
        <MineInfosView />
      </div>
      <div class="user-content-right">
        <router-view />
      </div>
    </div>
  </div>
</template>

<script setup>
import MineInfosView from '/@/views/index/user/mine-infos-view.vue'
</script>

<style scoped lang="less">
.user {
  display: block;
  width: 76%;
  margin: 0 auto;
  padding-top: 80px;

}

.user-content {
  display: flex;
  flex-direction: row;
  max-width: 1200px;
  min-width: 800px;
  margin: 0 auto; // 建议加上居中
  gap: 24px; // 添加间距

  .user-content-left {
    flex: 0 0 260px; // 固定左侧宽度为 260px
  }

  .user-content-right {
    flex: 1; // 右侧占满剩余空间
    min-width: 0; // 防止 flex 子项溢出（关键！）
  }
}
</style>
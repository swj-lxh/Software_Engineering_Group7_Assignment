<template>
  <el-container class="main-layout">
    <Header />
    <el-main class="content-wrapper"> 
      <router-view />
    </el-main>
    <Footer  class="footer-wrapper" />
  </el-container>
</template>

<script setup>
import Header from '/@/views/index/components/header.vue'
import Footer from '/@/views/index/components/footer.vue'
</script>

<style scoped>
.main-layout {
  /* min-height: 80vh; */
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.content-wrapper {
   padding: 0;
}  


</style>


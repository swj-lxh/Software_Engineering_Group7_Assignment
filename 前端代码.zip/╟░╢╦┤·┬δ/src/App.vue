<template>
  <a-config-provider :locale="zhCN">
      <router-view />
  </a-config-provider>
</template>

<script setup lang="ts">
import zhCN from 'ant-design-vue/es/locale/zh_CN';
</script>

<style>
  .root {
  --primary-color: #ff7b31; /* 主色调（橙色） */
  --primary-light: #fff2e8; /* 浅色背景 */
  --text-primary: #152844; /* 主要文字色 */
  --text-secondary: #6b7280; /* 次要文字色 */
  --border-radius: 8px; /* 统一圆角 */
  }
.dark {
  --primary-color: #ff9551; /* 深色模式下主色更亮 */
  --text-primary: #f3f4f6; /* 文字反白 */
  --text-secondary: #9ca3af;
  background-color: #111827; /* 深色背景 */
}

/* 深色模式下的商品卡片 */
.dark .thing-item {
  background-color: #1f2937;
}

/* 深色模式下的文字 */
.dark .thing-name,
.dark .no-data {
  color: var(--text-primary);
}

/* 深色模式下的按钮 */
.dark .el-button {
  background-color: #374151;
  color: #fff;
  border-color: #4b5563;
}
</style>
import { defineStore } from 'pinia';

export type CartItem = {
  id: string | number;
  title?: string;
  price?: number;
  cover?: string;
  quantity: number;
  [key: string]: any;
}

export const useCartStore = defineStore('cart', {
  state: () => ({
    cartItems: [] as CartItem[],
  }),
  getters: {
    totalCount: (state) => state.cartItems.reduce((t, i) => t + (i.quantity || 0), 0),
    totalAmount: (state) => state.cartItems.reduce((t, i) => t + ((i.price || 0) * (i.quantity || 0)), 0),
  },
  actions: {
    addItem(item: Partial<CartItem> & { id: string | number; quantity?: number }) {
      const exist = this.cartItems.find(i => i.id === item.id);
      if (exist) {
        exist.quantity = (exist.quantity || 0) + (item.quantity || 1);
      } else {
        this.cartItems.push({ ...(item as CartItem), quantity: item.quantity || 1 });
      }
    },
    removeItem(id: string | number) {
      this.cartItems = this.cartItems.filter(i => i.id !== id);
    },
    setQuantity(id: string | number, qty: number) {
      const it = this.cartItems.find(i => i.id === id);
      if (it) it.quantity = qty;
    },
    clear() {
      this.cartItems = [];
    }
  },
  persist: true,
});

export default useCartStore;
